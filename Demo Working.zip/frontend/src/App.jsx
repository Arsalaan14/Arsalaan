import React, { lazy, Suspense } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import AppLayout from './components/layout/AppLayout';
import { ToastProvider } from './components/common/Toast';
import Spinner from './components/common/Spinner';
import ProtectedRoute from './components/ProtectedRoute';

// Lazy-load pages for code splitting
const LoginPage = lazy(() => import('./pages/Login/LoginPage'));
const DashboardPage = lazy(() => import('./pages/Dashboard/DashboardPage'));
const PatientDirectory = lazy(() => import('./pages/PatientDirectory/PatientDirectory'));
const PatientDetails = lazy(() => import('./pages/PatientDetails/PatientDetails'));
const MedicalInquiry = lazy(() => import('./pages/MedicalInquiry/MedicalInquiry'));
const SystemHealthPage = lazy(() => import('./pages/SystemHealth/SystemHealthPage'));
const SettingsPage = lazy(() => import('./pages/Settings/SettingsPage'));
const AuditLogsPage = lazy(() => import('./pages/AuditLogs/AuditLogsPage'));

/**
 * Page loading fallback.
 */
function PageLoader() {
  return (
    <div className="flex items-center justify-center h-64">
      <div className="flex flex-col items-center gap-3">
        <Spinner size="lg" />
        <p className="text-sm text-text-muted">Loading...</p>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <ToastProvider>
        <Suspense fallback={<PageLoader />}>
          <Routes>
            <Route path="login" element={<LoginPage />} />
            <Route element={<ProtectedRoute />}>
              <Route element={<AppLayout />}>
              <Route index element={<DashboardPage />} />
              <Route path="patients" element={<PatientDirectory />} />
              <Route path="patients/:id" element={<PatientDetails />} />
              <Route path="inquiry" element={<MedicalInquiry />} />
              <Route path="system" element={<SystemHealthPage />} />
              <Route path="settings" element={<SettingsPage />} />
              <Route path="audit-logs" element={<AuditLogsPage />} />
              </Route>
            </Route>
          </Routes>
        </Suspense>
      </ToastProvider>
    </BrowserRouter>
  );
}

import React, { useState } from 'react';
import { HeartPulse, Lock, UserRound, ShieldCheck } from 'lucide-react';
import { login } from '../../utils/api';

const DEMO_ACCOUNTS = [
  ['provider', 'Provider@123', 'Provider'],
  ['patient9', 'Patient@123', 'Patient'],
  ['insurer', 'Insurer@123', 'Insurer'],
  ['admin', 'Admin@123', 'Administrator'],
];

export default function LoginPage() {
  const [username, setUsername] = useState('provider');
  const [password, setPassword] = useState('Provider@123');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault(); setBusy(true); setError('');
    try {
      const result = await login(username, password);
      localStorage.setItem('access-token', result.access_token);
      localStorage.setItem('user', JSON.stringify(result.user));
      window.location.href = '/';
    } catch (err) {
      setError(err.message || 'Login failed');
    } finally { setBusy(false); }
  }

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-7">
          <div className="mx-auto w-14 h-14 rounded-2xl bg-blue-600 flex items-center justify-center shadow-lg shadow-blue-900/30">
            <HeartPulse className="w-8 h-8 text-white" />
          </div>
          <h1 className="mt-4 text-2xl font-bold text-white">MediQueryNow</h1>
          <p className="mt-1 text-sm text-slate-400">Clinical information retrieval platform</p>
        </div>
        <form onSubmit={submit} className="bg-white rounded-2xl p-6 shadow-2xl">
          <div className="flex items-center gap-2 text-sm font-semibold text-slate-800 mb-5">
            <ShieldCheck className="w-4 h-4 text-blue-600" /> Secure sign in
          </div>
          {error && <div className="mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-sm text-red-700">{error}</div>}
          <label className="block text-xs font-semibold text-slate-600 mb-1">Username</label>
          <div className="relative mb-4">
            <UserRound className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400"/>
            <input value={username} onChange={e=>setUsername(e.target.value)} className="w-full pl-9 pr-3 py-2.5 border border-slate-200 rounded-lg" autoComplete="username"/>
          </div>
          <label className="block text-xs font-semibold text-slate-600 mb-1">Password</label>
          <div className="relative mb-5">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400"/>
            <input type="password" value={password} onChange={e=>setPassword(e.target.value)} className="w-full pl-9 pr-3 py-2.5 border border-slate-200 rounded-lg" autoComplete="current-password"/>
          </div>
          <button disabled={busy} className="w-full py-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold disabled:opacity-60">{busy ? 'Signing in…' : 'Sign in'}</button>
          <div className="mt-5 pt-4 border-t border-slate-100">
            <p className="text-[11px] text-slate-400 mb-2">Academic demo accounts</p>
            <div className="grid grid-cols-2 gap-2">
              {DEMO_ACCOUNTS.map(([u,p,label]) => <button type="button" key={u} onClick={()=>{setUsername(u);setPassword(p)}} className="text-left px-2.5 py-2 rounded-lg bg-slate-50 hover:bg-blue-50 border border-slate-100 text-[11px]"><b>{label}</b><br/><span className="text-slate-400">{u}</span></button>)}
            </div>
          </div>
        </form>
        <p className="text-center text-[11px] text-slate-500 mt-4">For academic demonstration only. Not a diagnostic or treatment system.</p>
      </div>
    </div>
  );
}

import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  ArrowLeft, User, Phone, Mail, MapPin, Heart, ShieldAlert,
  Pill, TestTube, Calendar, FileText, Droplet
} from 'lucide-react';
import usePatientDetails from '../../hooks/usePatientDetails';
import SectionCard from '../../components/common/SectionCard';
import Badge from '../../components/common/Badge';
import Timeline from '../../components/common/Timeline';
import ErrorState from '../../components/common/ErrorState';
import EmptyState from '../../components/common/EmptyState';

export default function PatientDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { patient, loading, error, refetch } = usePatientDetails(id);

  if (loading) {
    return (
      <div className="space-y-3">
        <div className="skeleton h-6 w-32" />
        <div className="skeleton h-36 rounded-lg" />
        <div className="grid grid-cols-2 gap-3"><div className="skeleton h-28 rounded-lg" /><div className="skeleton h-28 rounded-lg" /></div>
        <div className="skeleton h-40 rounded-lg" />
      </div>
    );
  }
  if (error) return <ErrorState title="Failed to load patient" message={error} onRetry={refetch} />;
  if (!patient) return <EmptyState icon={User} title="Patient not found" description={`No record for ID: ${id}`} actionLabel="Back to Directory" onAction={() => navigate('/patients')} />;

  const visitTimeline = (patient.visits || []).map(v => ({
    title: v.reason, description: `Attending: ${v.doctor}`, timestamp: v.date, badge: v.doctor, color: 'medical', icon: Calendar,
  }));

  return (
    <div className="space-y-3">
      {/* Back */}
      <button onClick={() => navigate('/patients')} className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-blue-600 transition-all">
        <ArrowLeft className="h-3.5 w-3.5" /> Patient Directory
      </button>

      {/* Patient Header */}
      <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-card">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="h-14 w-14 rounded-lg bg-slate-700 flex items-center justify-center text-lg font-bold text-white shrink-0">
            {patient.name?.split(' ').map(w => w[0]).join('').slice(0, 2) || '?'}
          </div>
          <div className="flex-1">
            <div className="flex flex-wrap items-start justify-between gap-2">
              <div>
                <h1 className="text-lg font-bold text-slate-900">{patient.name}</h1>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="font-mono text-[11px] text-slate-400 bg-slate-100 px-1.5 py-px rounded">{patient.patient_id}</span>
                  <Badge variant="info" size="xs">{patient.gender}</Badge>
                  <Badge variant="default" size="xs">{patient.blood_group}</Badge>
                </div>
              </div>
              <Badge variant="success" size="sm">Active</Badge>
            </div>

            {/* Quick Info Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-3 pt-3 border-t border-slate-100">
              {[
                { icon: User, label: 'Age', value: `${patient.age} yrs` },
                { icon: Phone, label: 'Phone', value: patient.contact?.phone || '' },
                { icon: Mail, label: 'Email', value: patient.contact?.email || '' },
                { icon: MapPin, label: 'Address', value: patient.address || '' },
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-2">
                  <item.icon className="h-3.5 w-3.5 text-slate-400 shrink-0" />
                  <div className="min-w-0">
                    <p className="text-[10px] text-slate-400 uppercase font-semibold tracking-wider">{item.label}</p>
                    <p className="text-xs font-medium text-slate-800 truncate">{item.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Clinical Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        <SectionCard title="Active Conditions" icon={Heart} collapsible defaultOpen>
          {patient.conditions?.length > 0 ? (
            <div className="flex flex-wrap gap-1.5">{patient.conditions.map((c, i) => <Badge key={i} variant="default" size="sm">{c}</Badge>)}</div>
          ) : <p className="text-xs text-slate-400 italic">None recorded</p>}
        </SectionCard>

        <SectionCard title="Allergies" icon={ShieldAlert} collapsible defaultOpen>
          {patient.allergies?.length > 0 && !(patient.allergies.length === 1 && patient.allergies[0] === 'None') ? (
            <div className="flex flex-wrap gap-1.5">{patient.allergies.map((a, i) => <Badge key={i} variant="critical" size="sm">{a}</Badge>)}</div>
          ) : <p className="text-xs text-slate-400 italic">No known allergies</p>}
        </SectionCard>
      </div>

      {/* Medications */}
      <SectionCard title="Current Medications" icon={Pill} collapsible defaultOpen>
        {patient.medications?.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-[13px] border-collapse">
              <thead><tr className="border-b border-slate-200 text-[11px] text-slate-400 uppercase tracking-wider">
                <th className="py-2 px-2 font-semibold">Medication</th><th className="py-2 px-2 font-semibold">Dosage</th><th className="py-2 px-2 font-semibold">Frequency</th>
              </tr></thead>
              <tbody className="divide-y divide-slate-100">
                {patient.medications.map((m, i) => (
                  <tr key={i} className="hover:bg-slate-50 transition-all">
                    <td className="py-2 px-2 font-medium text-slate-800">{m.name}</td>
                    <td className="py-2 px-2 font-mono text-xs text-slate-600">{m.dosage}</td>
                    <td className="py-2 px-2 text-slate-500">{m.frequency}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : <p className="text-xs text-slate-400 italic">None active</p>}
      </SectionCard>

      {/* Lab Reports */}
      <SectionCard title="Lab Reports" icon={TestTube} collapsible defaultOpen>
        {patient.lab_reports?.length > 0 ? (
          <div className="space-y-1.5">
            {patient.lab_reports.map((r, i) => (
              <div key={i} className="flex items-center justify-between py-2 px-3 bg-slate-50 rounded border border-slate-100">
                <div>
                  <p className="text-[13px] font-medium text-slate-800">{r.test_name}</p>
                  <p className="text-[11px] text-slate-400 font-mono">{r.date}</p>
                </div>
                <span className="font-mono text-xs font-semibold text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded">{r.value}</span>
              </div>
            ))}
          </div>
        ) : <p className="text-xs text-slate-400 italic">No reports on file</p>}
      </SectionCard>

      {/* Placeholders */}
      <SectionCard title="Vital Signs" icon={Droplet} collapsible defaultOpen={false}>
        <p className="text-xs text-slate-400 italic">Not available</p>
      </SectionCard>
      <SectionCard title="Clinical Notes" icon={FileText} collapsible defaultOpen={false}>
        <p className="text-xs text-slate-400 italic">Not available</p>
      </SectionCard>

      {/* Visit Timeline */}
      <SectionCard title="Visit History" icon={Calendar} collapsible defaultOpen>
        {visitTimeline.length > 0 ? <Timeline items={visitTimeline} /> : <p className="text-xs text-slate-400 italic">No visits recorded</p>}
      </SectionCard>
    </div>
  );
}

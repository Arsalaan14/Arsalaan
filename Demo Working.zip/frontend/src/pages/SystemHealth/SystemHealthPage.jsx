import React, { useState } from 'react';
import {
  Database, Server, Cpu, RefreshCw, AlertTriangle,
  HardDrive, MemoryStick, Gauge, Clock, Wifi
} from 'lucide-react';
import useSystemHealth from '../../hooks/useSystemHealth';
import { rebuildEmbeddings } from '../../utils/api';
import { systemMetrics } from '../../utils/mockData';
import InfoCard from '../../components/common/InfoCard';
import StatusChip from '../../components/common/StatusChip';
import LoadingSkeleton from '../../components/common/LoadingSkeleton';
import ErrorState from '../../components/common/ErrorState';

export default function SystemHealthPage() {
  const { health, loading, error, refetch } = useSystemHealth();
  const [rebuilding, setRebuilding] = useState(false);
  const [rebuildMsg, setRebuildMsg] = useState(null);

  const handleRebuild = async () => {
    if (rebuilding) return;
    setRebuilding(true); setRebuildMsg(null);
    try {
      const data = await rebuildEmbeddings();
      setRebuildMsg({ type: 'success', text: data.message || 'Embeddings rebuilt successfully.' });
      refetch();
    } catch (err) {
      setRebuildMsg({ type: 'error', text: err.message || 'Rebuild failed.' });
    } finally { setRebuilding(false); }
  };

  const ProgressBar = ({ used, total, unit }) => {
    const pct = Math.round((used / total) * 100);
    const color = pct > 80 ? 'bg-red-500' : pct > 60 ? 'bg-amber-500' : 'bg-blue-500';
    return (
      <div>
        <div className="flex justify-between text-[11px] mb-1">
          <span className="text-slate-400">{used}{unit} / {total}{unit}</span>
          <span className="font-semibold text-slate-600">{pct}%</span>
        </div>
        <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
          <div className={`h-full rounded-full transition-all duration-500 ${color}`} style={{ width: `${pct}%` }} />
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-slate-900 tracking-tight">System Health</h1>
          <p className="text-xs text-slate-500">Backend services, database, and model status</p>
        </div>
        <button onClick={refetch} disabled={loading} className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 bg-white border border-slate-200 rounded-md hover:bg-slate-50 transition-all disabled:opacity-50">
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} /> Refresh
        </button>
      </div>

      {error && <ErrorState message={error} onRetry={refetch} />}

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3"><LoadingSkeleton type="card" count={3} /></div>
      ) : health ? (
        <>
          {/* Service Status */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {[
              { icon: Database, iconColor: 'text-blue-600 bg-blue-50', label: 'Vector Index', sub: 'ChromaDB', ok: health.database?.exists, path: health.database?.path, okLabel: 'Ready', failLabel: 'Missing' },
              { icon: Server, iconColor: 'text-emerald-600 bg-emerald-50', label: 'Patient Records', sub: 'JSON Dataset', ok: health.dataset?.exists, path: health.dataset?.path, okLabel: 'Loaded', failLabel: 'Missing' },
              { icon: Cpu, iconColor: 'text-purple-600 bg-purple-50', label: 'LLM Server', sub: 'LM Studio', ok: health.llm?.connected, path: health.llm?.url, okLabel: 'Connected', failLabel: 'Offline' },
            ].map((svc, i) => (
              <div key={i} className="bg-white border border-slate-200 rounded-lg p-3.5 shadow-card">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    <div className={`p-1.5 rounded ${svc.iconColor}`}><svc.icon className="h-4 w-4" /></div>
                    <div>
                      <p className="text-[13px] font-semibold text-slate-800">{svc.label}</p>
                      <p className="text-[11px] text-slate-400">{svc.sub}</p>
                    </div>
                  </div>
                  <StatusChip status={svc.ok ? 'online' : 'offline'} label={svc.ok ? svc.okLabel : svc.failLabel} />
                </div>
                <p className="text-[11px] text-slate-400 font-mono bg-slate-50 rounded px-2 py-1.5 break-all">{svc.path || 'N/A'}</p>
                {i === 2 && !health.llm?.connected && (
                  <div className="mt-2 bg-amber-50 border border-amber-200 rounded px-2.5 py-2 flex items-start gap-2">
                    <AlertTriangle className="h-3.5 w-3.5 text-amber-500 shrink-0 mt-0.5" />
                    <p className="text-[11px] text-amber-800">Start LM Studio and load model <code className="bg-white rounded px-1 font-mono text-[10px]">{health.llm?.model}</code></p>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Metrics */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {[
              { icon: HardDrive, label: 'Storage', bar: { used: systemMetrics.storage.used, total: systemMetrics.storage.total, unit: systemMetrics.storage.unit } },
              { icon: MemoryStick, label: 'Memory', bar: { used: systemMetrics.memory.used, total: systemMetrics.memory.total, unit: systemMetrics.memory.unit } },
              { icon: Gauge, label: 'GPU', bar: { used: systemMetrics.gpu.used, total: systemMetrics.gpu.total, unit: systemMetrics.gpu.unit } },
            ].map((m, i) => (
              <div key={i} className="bg-white border border-slate-200 rounded-lg p-3.5 shadow-card">
                <div className="flex items-center gap-2 mb-2.5">
                  <m.icon className="h-3.5 w-3.5 text-slate-500" />
                  <span className="text-xs font-semibold text-slate-700">{m.label}</span>
                </div>
                <ProgressBar {...m.bar} />
              </div>
            ))}
            <div className="bg-white border border-slate-200 rounded-lg p-3.5 shadow-card">
              <div className="flex items-center gap-2 mb-2.5">
                <Clock className="h-3.5 w-3.5 text-slate-500" />
                <span className="text-xs font-semibold text-slate-700">Avg Response</span>
              </div>
              <p className="text-xl font-bold text-slate-900">{systemMetrics.responseTime.avg}s</p>
              <p className="text-[11px] text-slate-400">Query response time</p>
            </div>
          </div>

          {/* Overall */}
          <div className="flex items-center gap-2 px-3 py-2 bg-white border border-slate-200 rounded-lg">
            <Wifi className="h-3.5 w-3.5 text-slate-400" />
            <span className="text-xs text-slate-500">Overall:</span>
            <StatusChip status={health.status === 'healthy' ? 'online' : 'degraded'} label={health.status === 'healthy' ? 'All Systems Operational' : 'Services Degraded'} />
          </div>
        </>
      ) : null}

      {/* Rebuild */}
      <InfoCard title="Database Operations" icon={Database}>
        {rebuildMsg && (
          <div className={`mb-3 p-2.5 rounded text-xs font-medium border ${rebuildMsg.type === 'success' ? 'bg-emerald-50 border-emerald-200 text-emerald-800' : 'bg-red-50 border-red-200 text-red-800'}`}>
            {rebuildMsg.text}
          </div>
        )}
        <button onClick={handleRebuild} disabled={rebuilding || loading || !!error}
          className="flex items-center gap-1.5 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-medium rounded-md transition-all disabled:opacity-50 disabled:cursor-not-allowed">
          <RefreshCw className={`h-3.5 w-3.5 ${rebuilding ? 'animate-spin' : ''}`} />
          {rebuilding ? 'Rebuilding...' : 'Rebuild ChromaDB Embeddings'}
        </button>
        <p className="text-[11px] text-slate-400 mt-1.5">Regenerate vector embeddings from source patient data.</p>
      </InfoCard>
    </div>
  );
}

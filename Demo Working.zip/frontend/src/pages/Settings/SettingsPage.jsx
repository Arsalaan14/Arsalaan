import React, { useState } from 'react';
import {
  Settings, Palette, Bell, Globe, Accessibility, Info,
  Monitor, Volume2, Moon, Sun, Server
} from 'lucide-react';
import SectionCard from '../../components/common/SectionCard';
import { API_BASE_URL } from '../../utils/api';

export default function SettingsPage() {
  const [notifications, setNotifications] = useState({ systemAlerts: true, queryResults: true, patientUpdates: false, maintenance: true });
  const [accessibility, setAccessibility] = useState({ highContrast: false, largeText: false, reducedMotion: false });
  const [language, setLanguage] = useState('en');

  const Toggle = ({ checked, onChange, label }) => (
    <div className="flex items-center justify-between py-2">
      <span className="text-[13px] text-slate-700">{label}</span>
      <button
        onClick={() => onChange(!checked)}
        className={`relative w-8 h-4.5 rounded-full transition-all ${checked ? 'bg-blue-600' : 'bg-slate-300'}`}
        role="switch" aria-checked={checked} aria-label={label}
      >
        <span className={`absolute top-0.5 left-0.5 w-3.5 h-3.5 bg-white rounded-full shadow-sm transition-transform duration-200 ${checked ? 'translate-x-[14px]' : ''}`} />
      </button>
    </div>
  );

  return (
    <div className="space-y-3 max-w-2xl">
      <div>
        <h1 className="text-lg font-bold text-slate-900 tracking-tight">Settings</h1>
        <p className="text-xs text-slate-500">Application preferences and configuration</p>
      </div>

      <SectionCard title="Appearance" icon={Palette} collapsible defaultOpen>
        <div className="flex items-center justify-between py-1">
          <div>
            <p className="text-[13px] font-medium text-slate-700">Theme</p>
            <p className="text-[11px] text-slate-400">Application color theme</p>
          </div>
          <div className="flex items-center gap-1 bg-slate-100 rounded p-1">
            <button className="flex items-center gap-1.5 px-2.5 py-1 bg-white shadow-sm rounded text-[11px] font-medium text-slate-700">
              <Sun className="h-3 w-3" /> Light
            </button>
            <button className="flex items-center gap-1.5 px-2.5 py-1 rounded text-[11px] font-medium text-slate-400 cursor-not-allowed">
              <Moon className="h-3 w-3" /> Dark
            </button>
          </div>
        </div>
      </SectionCard>

      <SectionCard title="Notifications" icon={Bell} collapsible defaultOpen>
        <div className="divide-y divide-slate-100">
          <Toggle label="System Alerts" checked={notifications.systemAlerts} onChange={(v) => setNotifications(p => ({ ...p, systemAlerts: v }))} />
          <Toggle label="Query Results" checked={notifications.queryResults} onChange={(v) => setNotifications(p => ({ ...p, queryResults: v }))} />
          <Toggle label="Patient Record Updates" checked={notifications.patientUpdates} onChange={(v) => setNotifications(p => ({ ...p, patientUpdates: v }))} />
          <Toggle label="Maintenance" checked={notifications.maintenance} onChange={(v) => setNotifications(p => ({ ...p, maintenance: v }))} />
        </div>
      </SectionCard>

      <SectionCard title="API Configuration" icon={Server} collapsible defaultOpen>
        <div className="space-y-3">
          <div>
            <label className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">Backend Endpoint</label>
            <input type="text" value={API_BASE_URL} readOnly className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded text-xs font-mono text-slate-600 cursor-not-allowed" />
          </div>
          <p className="text-[11px] text-slate-500 italic">API config is managed server-side. Contact system admin to modify.</p>
        </div>
      </SectionCard>

      <SectionCard title="Language" icon={Globe} collapsible defaultOpen>
        <div>
          <label className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">Interface Language</label>
          <select value={language} onChange={(e) => setLanguage(e.target.value)} className="w-full sm:w-48 px-3 py-1.5 bg-white border border-slate-200 rounded text-xs text-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500">
            <option value="en">English (US)</option>
            <option value="en-gb">English (UK)</option>
            <option value="es">Español</option>
          </select>
        </div>
      </SectionCard>

      <SectionCard title="Accessibility" icon={Accessibility} collapsible defaultOpen>
        <div className="divide-y divide-slate-100">
          <Toggle label="High Contrast Mode" checked={accessibility.highContrast} onChange={(v) => setAccessibility(p => ({ ...p, highContrast: v }))} />
          <Toggle label="Large Text" checked={accessibility.largeText} onChange={(v) => setAccessibility(p => ({ ...p, largeText: v }))} />
          <Toggle label="Reduced Motion" checked={accessibility.reducedMotion} onChange={(v) => setAccessibility(p => ({ ...p, reducedMotion: v }))} />
        </div>
      </SectionCard>

      <SectionCard title="About" icon={Info} collapsible defaultOpen>
        <div className="space-y-2">
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div><p className="text-[10px] text-slate-400 uppercase font-semibold">Version</p><p className="font-medium text-slate-700">1.0.0</p></div>
            <div><p className="text-[10px] text-slate-400 uppercase font-semibold">Build</p><p className="font-mono font-medium text-slate-700">2026.07.03</p></div>
            <div><p className="text-[10px] text-slate-400 uppercase font-semibold">Framework</p><p className="font-medium text-slate-700">React 19 + Vite</p></div>
            <div><p className="text-[10px] text-slate-400 uppercase font-semibold">Backend</p><p className="font-medium text-slate-700">Flask + RAG</p></div>
          </div>
          <div className="pt-2 border-t border-slate-100"><p className="text-[11px] text-slate-500">PHRA — Secure clinical information retrieval system.</p></div>
        </div>
      </SectionCard>
    </div>
  );
}

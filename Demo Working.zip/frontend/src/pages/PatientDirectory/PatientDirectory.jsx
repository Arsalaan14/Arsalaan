import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, ArrowUpDown, Eye } from 'lucide-react';
import SearchBar from '../../components/common/SearchBar';
import FilterPanel from '../../components/common/FilterPanel';
import Pagination from '../../components/common/Pagination';
import Badge from '../../components/common/Badge';
import EmptyState from '../../components/common/EmptyState';
import ErrorState from '../../components/common/ErrorState';
import usePatients from '../../hooks/usePatients';

const ITEMS_PER_PAGE = 12;

export default function PatientDirectory() {
  const navigate = useNavigate();
  const { patients, loading, error, refetch } = usePatients();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCondition, setSelectedCondition] = useState('');
  const [sortField, setSortField] = useState('patient_id');
  const [sortDirection, setSortDirection] = useState('asc');
  const [currentPage, setCurrentPage] = useState(1);

  useEffect(() => { setCurrentPage(1); }, [searchTerm, selectedCondition]);

  const conditionOptions = useMemo(() => {
    const counts = {};
    patients.forEach(p => p.conditions?.forEach(c => { counts[c] = (counts[c] || 0) + 1; }));
    return Object.entries(counts).sort((a, b) => b[1] - a[1]).map(([value, count]) => ({ value, label: `${value} (${count})` }));
  }, [patients]);

  const filteredPatients = useMemo(() => {
    return patients.filter(p => {
      const matchSearch = !searchTerm || p.name.toLowerCase().includes(searchTerm.toLowerCase()) || p.patient_id.toLowerCase().includes(searchTerm.toLowerCase());
      const matchCondition = !selectedCondition || p.conditions?.some(c => c.toLowerCase() === selectedCondition.toLowerCase());
      return matchSearch && matchCondition;
    });
  }, [patients, searchTerm, selectedCondition]);

  const sortedPatients = useMemo(() => {
    return [...filteredPatients].sort((a, b) => {
      if (sortField === 'patient_id') {
        const aNum = parseInt(a.patient_id?.replace('P', '') || '0');
        const bNum = parseInt(b.patient_id?.replace('P', '') || '0');
        return sortDirection === 'asc' ? aNum - bNum : bNum - aNum;
      }
      let aVal = a[sortField], bVal = b[sortField];
      if (typeof aVal === 'string') aVal = aVal.toLowerCase();
      if (typeof bVal === 'string') bVal = bVal.toLowerCase();
      if (aVal < bVal) return sortDirection === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  }, [filteredPatients, sortField, sortDirection]);

  const totalPages = Math.ceil(sortedPatients.length / ITEMS_PER_PAGE);
  const paginatedPatients = sortedPatients.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE);

  const handleSort = (field) => {
    if (sortField === field) setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    else { setSortField(field); setSortDirection('asc'); }
  };

  const SortHeader = ({ field, children, className = '' }) => (
    <th className={`py-2.5 px-3 text-left cursor-pointer hover:bg-slate-100 transition-all select-none ${className}`} onClick={() => handleSort(field)}>
      <div className="flex items-center gap-1">
        <span>{children}</span>
        <ArrowUpDown className={`h-3 w-3 ${sortField === field ? 'text-blue-600' : 'text-slate-300'}`} />
      </div>
    </th>
  );

  return (
    <div className="space-y-3">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
        <div>
          <h1 className="text-lg font-bold text-slate-900 tracking-tight">Patient Directory</h1>
          <p className="text-xs text-slate-500">{loading ? 'Loading...' : `${filteredPatients.length} records`}</p>
        </div>
      </div>

      {error && <ErrorState title="Connection Error" message={error} onRetry={refetch} />}

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-2">
        <SearchBar placeholder="Search name or ID..." value={searchTerm} onChange={setSearchTerm} className="sm:w-72" />
        <FilterPanel label="All Conditions" value={selectedCondition} options={conditionOptions} onChange={setSelectedCondition} className="sm:w-48" />
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-card">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse" aria-label="Patient directory">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                <SortHeader field="patient_id">ID</SortHeader>
                <SortHeader field="name">Name</SortHeader>
                <SortHeader field="age" className="hidden sm:table-cell">Age</SortHeader>
                <SortHeader field="gender" className="hidden md:table-cell">Gender</SortHeader>
                <th className="py-2.5 px-3 text-left">Conditions</th>
                <th className="py-2.5 px-3 text-left hidden lg:table-cell">Blood</th>
                <th className="py-2.5 px-3 text-left w-20"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-[13px]">
              {loading ? (
                [...Array(6)].map((_, i) => (
                  <tr key={i}>
                    <td className="py-2.5 px-3"><div className="skeleton h-3.5 w-12" /></td>
                    <td className="py-2.5 px-3"><div className="skeleton h-3.5 w-24" /></td>
                    <td className="py-2.5 px-3 hidden sm:table-cell"><div className="skeleton h-3.5 w-8" /></td>
                    <td className="py-2.5 px-3 hidden md:table-cell"><div className="skeleton h-3.5 w-12" /></td>
                    <td className="py-2.5 px-3"><div className="skeleton h-4 w-20 rounded" /></td>
                    <td className="py-2.5 px-3 hidden lg:table-cell"><div className="skeleton h-4 w-8 rounded" /></td>
                    <td className="py-2.5 px-3"><div className="skeleton h-6 w-14 rounded" /></td>
                  </tr>
                ))
              ) : paginatedPatients.length > 0 ? (
                paginatedPatients.map((p) => (
                  <tr key={p.patient_id} onClick={() => navigate(`/patients/${p.patient_id}`)} className="hover:bg-slate-50 cursor-pointer transition-all">
                    <td className="py-2.5 px-3 font-mono font-semibold text-blue-600 text-xs">{p.patient_id}</td>
                    <td className="py-2.5 px-3 font-medium text-slate-900">{p.name}</td>
                    <td className="py-2.5 px-3 text-slate-500 hidden sm:table-cell">{p.age}</td>
                    <td className="py-2.5 px-3 text-slate-500 hidden md:table-cell">{p.gender}</td>
                    <td className="py-2.5 px-3">
                      <div className="flex flex-wrap gap-1">
                        {p.conditions?.map((c, i) => <Badge key={i} variant="neutral" size="xs">{c}</Badge>)}
                      </div>
                    </td>
                    <td className="py-2.5 px-3 hidden lg:table-cell"><Badge variant="info" size="xs">{p.blood_group}</Badge></td>
                    <td className="py-2.5 px-3">
                      <button
                        onClick={(e) => { e.stopPropagation(); navigate(`/patients/${p.patient_id}`); }}
                        className="flex items-center gap-1 px-2 py-1 text-[11px] font-medium text-blue-600 hover:bg-blue-50 rounded transition-all"
                        aria-label={`View ${p.name}`}
                      >
                        <Eye className="h-3 w-3" /> View
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr><td colSpan="7">
                  <EmptyState icon={Users} title="No patients found" description="Adjust search or filter criteria." actionLabel="Clear" onAction={() => { setSearchTerm(''); setSelectedCondition(''); }} />
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
        {!loading && paginatedPatients.length > 0 && (
          <div className="px-3 border-t border-slate-100">
            <Pagination currentPage={currentPage} totalPages={totalPages} totalItems={sortedPatients.length} itemsPerPage={ITEMS_PER_PAGE} onPageChange={setCurrentPage} />
          </div>
        )}
      </div>
    </div>
  );
}

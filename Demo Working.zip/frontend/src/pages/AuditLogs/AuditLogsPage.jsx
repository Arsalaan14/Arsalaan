import React, { useState, useEffect } from 'react';
import { ShieldCheck, RefreshCw, Search, FileText, AlertOctagon, HelpCircle } from 'lucide-react';
import { fetchAuditLogs } from '../../utils/api';
import StatusChip from '../../components/common/StatusChip';
import Spinner from '../../components/common/Spinner';

export default function AuditLogsPage() {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // Search and filter parameters
  const [query, setQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  const loadLogs = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchAuditLogs();
      // Reverse to show newest transactions first
      setLogs([...data].reverse());
    } catch (err) {
      setError(err.message || 'Failed to retrieve system audit trail logs.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadLogs();
  }, []);

  // Filter computation
  const filtered = logs.filter((log) => {
    const textFields = [
      log.user, 
      log.action, 
      log.details, 
      ...(log.patients_accessed || [])
    ].map(s => (s || '').toLowerCase());
    
    const matchesSearch = query === '' || textFields.some(field => field.includes(query.toLowerCase()));
    const matchesRole = roleFilter === 'all' || log.role?.toLowerCase() === roleFilter.toLowerCase();
    const matchesStatus = statusFilter === 'all' || log.status?.toLowerCase() === statusFilter.toLowerCase();
    
    return matchesSearch && matchesRole && matchesStatus;
  });

  const getStatusColor = (status) => {
    const s = (status || '').toUpperCase();
    if (s === 'SUCCESS') return 'bg-emerald-50 border-emerald-200 text-emerald-700';
    if (s === 'UNAUTHORIZED') return 'bg-rose-50 border-rose-200 text-rose-700';
    return 'bg-amber-50 border-amber-200 text-amber-700';
  };

  const getRoleBadge = (role) => {
    const r = (role || '').toLowerCase();
    const map = {
      provider: 'bg-blue-50 text-blue-700 border-blue-200',
      patient: 'bg-purple-50 text-purple-700 border-purple-200',
      insurer: 'bg-amber-50 text-amber-700 border-amber-200',
      admin: 'bg-slate-700 text-white border-slate-700'
    };
    return map[r] || 'bg-slate-50 text-slate-600 border-slate-200';
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-1.5">
            <ShieldCheck className="h-5.5 w-5.5 text-blue-600" />
            Audit Logging & Governance
          </h1>
          <p className="text-xs text-slate-500">Immutable trace logs for access controls, RAG retrievals, and data masking policies</p>
        </div>
        <button
          onClick={loadLogs}
          disabled={loading}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-600 bg-white border border-slate-200 rounded-md hover:bg-slate-50 transition-all disabled:opacity-50"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} /> Refresh Logs
        </button>
      </div>

      {error ? (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-lg flex items-start gap-3">
          <AlertOctagon className="h-5 w-5 text-rose-500 shrink-0 mt-0.5" />
          <div>
            <h3 className="text-sm font-semibold text-rose-800">Governance Clearance Denied</h3>
            <p className="text-xs text-rose-700 mt-1">{error}</p>
            <p className="text-xs text-rose-600 mt-2 font-medium">Please verify you have switched your active header persona to System Admin mode to unlock audit details.</p>
          </div>
        </div>
      ) : (
        <>
          {/* Filters Bar */}
          <div className="bg-white border border-slate-200 rounded-lg p-3 shadow-sm flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-slate-400" />
              <input
                type="text"
                placeholder="Search logs by user, action, details, patient id..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-md focus:outline-none focus:ring-1 focus:ring-slate-400"
              />
            </div>
            <div className="flex items-center gap-2">
              <select
                value={roleFilter}
                onChange={(e) => setRoleFilter(e.target.value)}
                className="text-xs bg-slate-50 border border-slate-200 rounded-md px-2 py-1.5 text-slate-700 font-medium focus:outline-none"
              >
                <option value="all">All Roles</option>
                <option value="provider">Provider</option>
                <option value="patient">Patient</option>
                <option value="insurer">Insurer</option>
                <option value="admin">Admin</option>
              </select>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="text-xs bg-slate-50 border border-slate-200 rounded-md px-2 py-1.5 text-slate-700 font-medium focus:outline-none"
              >
                <option value="all">All Statuses</option>
                <option value="success">Success</option>
                <option value="unauthorized">Unauthorized</option>
                <option value="error">Error</option>
              </select>
            </div>
          </div>

          {/* Logs Grid */}
          <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-sm">
            {loading ? (
              <div className="flex flex-col items-center justify-center py-16 gap-3">
                <Spinner size="lg" />
                <p className="text-xs text-slate-500">Loading audit trail entries...</p>
              </div>
            ) : filtered.length === 0 ? (
              <div className="text-center py-16">
                <HelpCircle className="h-8 w-8 text-slate-300 mx-auto mb-2" />
                <p className="text-sm font-medium text-slate-700">No matching audit logs found</p>
                <p className="text-xs text-slate-400 mt-1">Try broadening your search query or reset filters.</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-[11px] text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-semibold uppercase tracking-wider">
                      <th className="px-4 py-2.5">UTC Timestamp</th>
                      <th className="px-4 py-2.5">User Context</th>
                      <th className="px-4 py-2.5">Role</th>
                      <th className="px-4 py-2.5">Audited Action</th>
                      <th className="px-4 py-2.5">Access Log Details</th>
                      <th className="px-4 py-2.5 text-center">Status</th>
                      <th className="px-4 py-2.5">Data Scope</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                    {filtered.map((log, index) => {
                      const date = new Date(log.timestamp);
                      return (
                        <tr key={index} className="hover:bg-slate-50/50 transition-colors">
                          <td className="px-4 py-3 text-slate-400 whitespace-nowrap">
                            {date.toLocaleDateString()} {date.toLocaleTimeString()}
                          </td>
                          <td className="px-4 py-3 font-semibold text-slate-800">{log.user}</td>
                          <td className="px-4 py-3">
                            <span className={`px-1.5 py-0.5 rounded text-[10px] uppercase font-bold border ${getRoleBadge(log.role)}`}>
                              {log.role}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            <span className="font-mono bg-slate-100 rounded px-1.5 py-0.5 text-slate-600 font-semibold">
                              {log.action}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-slate-500 break-all max-w-[280px]">
                            {log.details}
                          </td>
                          <td className="px-4 py-3 text-center whitespace-nowrap">
                            <span className={`px-1.5 py-0.5 rounded-full text-[9px] font-bold border ${getStatusColor(log.status)}`}>
                              {(log.status || 'SUCCESS').toUpperCase()}
                            </span>
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            {log.patients_accessed && log.patients_accessed.length > 0 ? (
                              <div className="flex flex-wrap gap-1">
                                {log.patients_accessed.map((pid, idx) => (
                                  <span key={idx} className="bg-slate-100 hover:bg-slate-200 text-slate-600 px-1 py-0.5 rounded text-[10px] transition-colors">
                                    {pid}
                                  </span>
                                ))}
                              </div>
                            ) : (
                              <span className="text-slate-400 font-normal">None</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
            <div className="bg-slate-50 px-4 py-2.5 border-t border-slate-200 flex justify-between items-center text-slate-400 select-none">
              <span>Showing {filtered.length} entries</span>
              <span>Total Indexed: {logs.length} transactions</span>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

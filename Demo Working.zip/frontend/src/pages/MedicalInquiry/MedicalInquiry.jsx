import React, { useState, useRef } from 'react';
import {
  Search, X, Clock, FileText, ArrowRight, ChevronDown, ChevronUp,
  User, Pill, TestTube, Heart, ShieldAlert, Calendar, Stethoscope,
  Database, Zap, Hash, AlertTriangle, CheckCircle, ExternalLink,
  History, Trash2, Filter
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { sendQuery } from '../../utils/api';
import Badge from '../../components/common/Badge';

/**
 * Medical Inquiry — Clinical Information Retrieval Interface.
 * Search-based workflow replacing chat UI.
 * Preserves exact API contract with POST /api/query.
 */

const EXAMPLE_QUERIES = [
  { text: 'Patients with HbA1c above 7%', category: 'Lab Results' },
  { text: 'Cardiac patients on medication', category: 'Conditions' },
  { text: 'Summarize Patient P009', category: 'Patient Summary' },
  { text: 'Medications for Patient 5', category: 'Medications' },
  { text: 'Patients with hypertension', category: 'Conditions' },
  { text: 'Patients allergic to Penicillin', category: 'Allergies' },
];

// Parse the AI response into structured sections
function parseResponseSections(text) {
  if (!text) return { summary: '', sections: [] };

  const lines = text.split('\n');
  const sections = [];
  let currentSection = null;
  let summaryLines = [];
  let inSection = false;

  for (const line of lines) {
    if (line.startsWith('## ') || line.startsWith('### ') || line.startsWith('# ')) {
      if (currentSection) sections.push(currentSection);
      const title = line.replace(/^#+\s*/, '');
      currentSection = { title, content: [] };
      inSection = true;
    } else if (currentSection) {
      if (line.trim()) currentSection.content.push(line);
    } else {
      if (line.trim()) summaryLines.push(line);
    }
  }
  if (currentSection) sections.push(currentSection);

  return { summary: summaryLines.join('\n'), sections };
}

// Render formatted text (bold, lists, citations)
function renderFormattedText(text) {
  if (!text) return null;
  return text.split('\n').map((line, i) => {
    if (line.startsWith('* ') || line.startsWith('- ')) {
      return (
        <li key={i} className="flex items-start gap-1.5 text-[13px] text-slate-700 leading-snug py-0.5">
          <span className="text-slate-400 mt-px">•</span>
          <span>{renderCitations(line.substring(2))}</span>
        </li>
      );
    }
    if (!line.trim()) return null;
    return <p key={i} className="text-[13px] text-slate-700 leading-snug py-0.5">{renderCitations(line)}</p>;
  });
}

function renderCitations(text) {
  if (!text) return text;
  
  // Regex matches bracketed paths starting with patients, e.g. [patients[0].name]
  const parts = text.split(/(\[patients[^\]]*\])/g);
  return parts.map((part, idx) => {
    if (part.startsWith('[') && part.endsWith(']')) {
      const pathStr = part.slice(1, -1);
      return (
        <span
          key={idx}
          className="inline-flex items-center mx-0.5 px-1 py-0.25 text-[9px] font-mono leading-none bg-blue-50 border border-blue-200 text-blue-600 rounded select-all cursor-help transition-all hover:bg-blue-100 hover:text-blue-700 font-bold"
          title={`Provenanced Path: ${pathStr}`}
        >
          {pathStr}
        </span>
      );
    }
    return renderBold(part);
  });
}

function renderBold(text) {
  const parts = text.split(/(\*\*.*?\*\*)/g);
  return parts.map((part, idx) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return <strong key={idx} className="font-semibold text-slate-900">{part.slice(2, -2)}</strong>;
    }
    return part;
  });
}

// Map section titles to icons
function getSectionIcon(title) {
  const t = title.toLowerCase();
  if (t.includes('medication') || t.includes('drug') || t.includes('prescription')) return Pill;
  if (t.includes('diagnosis') || t.includes('condition') || t.includes('disease')) return Heart;
  if (t.includes('lab') || t.includes('test') || t.includes('result')) return TestTube;
  if (t.includes('allerg')) return ShieldAlert;
  if (t.includes('visit') || t.includes('history') || t.includes('timeline')) return Calendar;
  if (t.includes('patient') || t.includes('demographic')) return User;
  if (t.includes('interpretation') || t.includes('assessment') || t.includes('clinical')) return Stethoscope;
  return FileText;
}

export default function MedicalInquiry() {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [loadingStage, setLoadingStage] = useState(0);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [searchHistory, setSearchHistory] = useState([]);
  const [showHistory, setShowHistory] = useState(false);
  const [expandedSections, setExpandedSections] = useState({});
  const inputRef = useRef(null);

  const handleSubmit = async (e, text = null) => {
    if (e) e.preventDefault();
    const queryText = text || query;
    if (!queryText.trim() || loading) return;

    setLoading(true);
    setError(null);
    setResult(null);
    setLoadingStage(0);

    // Simulate retrieval stages
    const stageTimer1 = setTimeout(() => setLoadingStage(1), 400);
    const stageTimer2 = setTimeout(() => setLoadingStage(2), 900);
    const stageTimer3 = setTimeout(() => setLoadingStage(3), 1400);

    try {
      const data = await sendQuery(queryText);

      const parsed = parseResponseSections(data.answer);
      const searchResult = {
        query: queryText,
        answer: data.answer,
        parsed,
        retrievedDocs: data.retrieved_docs,
        docIds: data.doc_ids || [],
        retrievalTime: data.retrieval_time,
        generationTime: data.generation_time,
        totalTime: (data.retrieval_time || 0) + (data.generation_time || 0),
        timestamp: new Date().toISOString(),
        searchId: `SRH-${Date.now().toString(36).toUpperCase()}`,
      };

      setResult(searchResult);
      setSearchHistory(prev => [searchResult, ...prev].slice(0, 20));
      if (!text) setQuery('');
      setExpandedSections({});
    } catch (err) {
      console.error(err);
      setError('Failed to connect to the backend server. Verify the MediQueryNow backend is running and the configured LLM provider is available.');
    } finally {
      clearTimeout(stageTimer1);
      clearTimeout(stageTimer2);
      clearTimeout(stageTimer3);
      setLoading(false);
      setLoadingStage(0);
    }
  };

  const clearResult = () => {
    setResult(null);
    setError(null);
    inputRef.current?.focus();
  };

  const toggleSection = (idx) => {
    setExpandedSections(prev => ({ ...prev, [idx]: !prev[idx] }));
  };

  const loadingStages = [
    'Searching patient records...',
    'Retrieving relevant documents...',
    'Analyzing clinical context...',
    'Preparing structured response...',
  ];

  const formatTimestamp = (iso) => {
    try {
      const d = new Date(iso);
      return d.toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    } catch { return ''; }
  };

  return (
    <div className="space-y-4">
      {/* Page Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold text-slate-900 tracking-tight">Clinical Information Retrieval</h1>
          <p className="text-xs text-slate-500 mt-0.5">Search patient records, diagnoses, medications, laboratory reports, and clinical notes</p>
        </div>
        {searchHistory.length > 0 && (
          <button
            onClick={() => setShowHistory(!showHistory)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 bg-white border border-slate-200 rounded-md hover:bg-slate-50 transition-all"
          >
            <History className="h-3.5 w-3.5" />
            Recent ({searchHistory.length})
          </button>
        )}
      </div>

      {/* Search Section */}
      <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-sm">
        <form onSubmit={handleSubmit} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              disabled={loading}
              placeholder="Search patient records, diagnoses, medications, laboratory reports, allergies..."
              className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-md text-sm text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 disabled:opacity-50 transition-all"
              aria-label="Clinical search query"
            />
          </div>
          <button
            type="submit"
            disabled={loading || !query.trim()}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-md transition-all disabled:bg-slate-200 disabled:text-slate-400 disabled:cursor-not-allowed flex items-center gap-1.5"
          >
            <Search className="h-3.5 w-3.5" />
            Search
          </button>
          {(result || error) && (
            <button
              type="button"
              onClick={clearResult}
              className="px-3 py-2 text-slate-500 hover:text-slate-700 border border-slate-200 rounded-md hover:bg-slate-50 transition-all text-sm"
              title="Clear results"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </form>

        {/* Example Queries (shown when no result) */}
        {!result && !loading && !error && (
          <div className="mt-3 pt-3 border-t border-slate-100">
            <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Example queries</span>
            <div className="flex flex-wrap gap-1.5 mt-2">
              {EXAMPLE_QUERIES.map((ex, i) => (
                <button
                  key={i}
                  onClick={(e) => { setQuery(ex.text); handleSubmit(e, ex.text); }}
                  className="flex items-center gap-1 text-xs text-slate-600 bg-slate-50 border border-slate-200 px-2.5 py-1 rounded hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700 transition-all"
                >
                  <span>{ex.text}</span>
                  <ArrowRight className="h-3 w-3 opacity-40" />
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Recent Search History */}
      {showHistory && searchHistory.length > 0 && (
        <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-sm">
          <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Recent Searches</span>
            <button onClick={() => { setSearchHistory([]); setShowHistory(false); }} className="text-[11px] text-slate-400 hover:text-red-500 transition-colors">
              Clear all
            </button>
          </div>
          <div className="divide-y divide-slate-100 max-h-48 overflow-y-auto">
            {searchHistory.map((item, i) => (
              <button
                key={i}
                onClick={(e) => { setQuery(item.query); handleSubmit(e, item.query); setShowHistory(false); }}
                className="w-full text-left px-4 py-2 hover:bg-slate-50 transition-all flex items-center justify-between gap-4 group"
              >
                <div className="flex items-center gap-2 min-w-0">
                  <Search className="h-3 w-3 text-slate-400 shrink-0" />
                  <span className="text-sm text-slate-700 truncate">{item.query}</span>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  <span className="text-[11px] text-slate-400">{item.retrievedDocs} docs</span>
                  <span className="text-[11px] text-slate-400">{formatTimestamp(item.timestamp)}</span>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Loading State */}
      {loading && (
        <div className="bg-white border border-slate-200 rounded-lg p-6 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className="h-5 w-5 border-2 border-blue-200 border-t-blue-600 rounded-full animate-spin" />
            <span className="text-sm font-medium text-slate-700">Searching clinical database...</span>
          </div>
          <div className="space-y-2">
            {loadingStages.map((stage, i) => (
              <div key={i} className={`flex items-center gap-2 text-xs transition-all duration-300 ${i <= loadingStage ? 'text-slate-700' : 'text-slate-300'}`}>
                {i < loadingStage ? (
                  <CheckCircle className="h-3.5 w-3.5 text-green-500" />
                ) : i === loadingStage ? (
                  <div className="h-3.5 w-3.5 border border-blue-400 border-t-transparent rounded-full animate-spin" />
                ) : (
                  <div className="h-3.5 w-3.5 rounded-full border border-slate-200" />
                )}
                {stage}
              </div>
            ))}
          </div>
          <div className="mt-4 h-1 bg-slate-100 rounded-full overflow-hidden">
            <div className="h-full bg-blue-500 rounded-full transition-all duration-500" style={{ width: `${((loadingStage + 1) / loadingStages.length) * 100}%` }} />
          </div>
        </div>
      )}

      {/* Error State */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
          <AlertTriangle className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-medium text-red-800">Retrieval Failed</p>
            <p className="text-xs text-red-700 mt-0.5">{error}</p>
          </div>
        </div>
      )}

      {/* Results */}
      {result && (
        <div className="space-y-3 animate-fade-in">
          {/* Query Summary Bar */}
          <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-sm">
            <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-3.5 w-3.5 text-green-500" />
                <span className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Query Results</span>
              </div>
              <span className="text-[11px] text-slate-400 font-mono">{result.searchId}</span>
            </div>
            <div className="px-4 py-3 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs">
              <div className="flex items-center gap-1.5 text-slate-600">
                <Search className="h-3 w-3 text-slate-400" />
                <span className="font-medium text-slate-800 max-w-[300px] truncate">"{result.query}"</span>
              </div>
              <div className="flex items-center gap-1.5 text-slate-500">
                <Database className="h-3 w-3" />
                <span>{result.retrievedDocs} documents retrieved</span>
              </div>
              <div className="flex items-center gap-1.5 text-slate-500">
                <Clock className="h-3 w-3" />
                <span>{result.totalTime.toFixed(2)}s total</span>
              </div>
              <div className="flex items-center gap-1.5 text-slate-500">
                <Calendar className="h-3 w-3" />
                <span>{formatTimestamp(result.timestamp)}</span>
              </div>
            </div>
          </div>

          {/* Main Results Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-3">
            {/* Clinical Report - Main Column */}
            <div className="lg:col-span-3 space-y-3">
              {/* Primary Findings */}
              {result.parsed.summary && (
                <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-sm">
                  <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-100 flex items-center gap-2">
                    <Stethoscope className="h-3.5 w-3.5 text-blue-600" />
                    <span className="text-xs font-semibold text-slate-700 uppercase tracking-wider">Clinical Findings</span>
                  </div>
                  <div className="px-4 py-3">
                    {renderFormattedText(result.parsed.summary)}
                  </div>
                </div>
              )}

              {/* Structured Sections */}
              {result.parsed.sections.map((section, idx) => {
                const SectionIcon = getSectionIcon(section.title);
                const isExpanded = expandedSections[idx] !== false; // default open
                return (
                  <div key={idx} className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-sm">
                    <button
                      onClick={() => toggleSection(idx)}
                      className="w-full px-4 py-2.5 bg-slate-50 border-b border-slate-100 flex items-center justify-between hover:bg-slate-100 transition-all"
                    >
                      <div className="flex items-center gap-2">
                        <SectionIcon className="h-3.5 w-3.5 text-blue-600" />
                        <span className="text-xs font-semibold text-slate-700 uppercase tracking-wider">{section.title}</span>
                      </div>
                      {isExpanded ? <ChevronUp className="h-3.5 w-3.5 text-slate-400" /> : <ChevronDown className="h-3.5 w-3.5 text-slate-400" />}
                    </button>
                    {isExpanded && (
                      <div className="px-4 py-3">
                        <ul className="space-y-0.5">
                          {renderFormattedText(section.content.join('\n'))}
                        </ul>
                      </div>
                    )}
                  </div>
                );
              })}

              {/* Full response fallback if no sections parsed */}
              {!result.parsed.summary && result.parsed.sections.length === 0 && (
                <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-sm">
                  <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-100 flex items-center gap-2">
                    <FileText className="h-3.5 w-3.5 text-blue-600" />
                    <span className="text-xs font-semibold text-slate-700 uppercase tracking-wider">Clinical Report</span>
                  </div>
                  <div className="px-4 py-3">
                    {renderFormattedText(result.answer)}
                  </div>
                </div>
              )}

              {/* Clinical Disclaimer */}
              <div className="bg-amber-50 border border-amber-200 rounded-lg px-4 py-2.5 flex items-start gap-2">
                <AlertTriangle className="h-3.5 w-3.5 text-amber-500 shrink-0 mt-0.5" />
                <p className="text-[11px] text-amber-800 leading-snug">
                  Results are generated using retrieval-augmented generation from indexed patient records.
                  Verify all critical medical information with primary clinical sources before making treatment decisions.
                </p>
              </div>
            </div>

            {/* Right Sidebar — Metadata & Sources */}
            <div className="space-y-3">
              {/* Referenced Records */}
              {result.docIds.length > 0 && (
                <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-sm">
                  <div className="px-3 py-2 bg-slate-50 border-b border-slate-100">
                    <span className="text-[11px] font-semibold text-slate-600 uppercase tracking-wider">Referenced Records</span>
                  </div>
                  <div className="divide-y divide-slate-100">
                    {result.docIds.map((id, i) => (
                      <button
                        key={i}
                        onClick={() => navigate(`/patients/${id}`)}
                        className="w-full text-left px-3 py-2 hover:bg-blue-50 transition-all flex items-center justify-between group"
                      >
                        <div className="flex items-center gap-2">
                          <User className="h-3 w-3 text-slate-400" />
                          <span className="text-xs font-mono font-medium text-blue-600">{id}</span>
                        </div>
                        <ExternalLink className="h-3 w-3 text-slate-300 group-hover:text-blue-500 transition-colors" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Query Metadata */}
              <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-sm">
                <div className="px-3 py-2 bg-slate-50 border-b border-slate-100">
                  <span className="text-[11px] font-semibold text-slate-600 uppercase tracking-wider">Search Metadata</span>
                </div>
                <div className="px-3 py-2 space-y-2">
                  <MetaRow label="Search ID" value={result.searchId} mono />
                  <MetaRow label="Documents" value={`${result.retrievedDocs} retrieved`} />
                  <MetaRow label="Retrieval" value={`${result.retrievalTime?.toFixed(3)}s`} />
                  <MetaRow label="Generation" value={`${result.generationTime?.toFixed(3)}s`} />
                  <MetaRow label="Total" value={`${result.totalTime.toFixed(3)}s`} />
                  <MetaRow label="Timestamp" value={formatTimestamp(result.timestamp)} />
                  <MetaRow label="Model" value="LM Studio (Local)" />
                  <MetaRow label="Method" value="RAG + ChromaDB" />
                </div>
              </div>

              {/* Source Status */}
              <div className="bg-white border border-slate-200 rounded-lg overflow-hidden shadow-sm">
                <div className="px-3 py-2 bg-slate-50 border-b border-slate-100">
                  <span className="text-[11px] font-semibold text-slate-600 uppercase tracking-wider">Source Status</span>
                </div>
                <div className="px-3 py-2 space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-500">Vector Index</span>
                    <span className="flex items-center gap-1 text-green-600 font-medium"><span className="w-1.5 h-1.5 rounded-full bg-green-500" />Active</span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-500">Patient Records</span>
                    <span className="flex items-center gap-1 text-green-600 font-medium"><span className="w-1.5 h-1.5 rounded-full bg-green-500" />Loaded</span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-500">LLM Server</span>
                    <span className="flex items-center gap-1 text-green-600 font-medium"><span className="w-1.5 h-1.5 rounded-full bg-green-500" />Connected</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function MetaRow({ label, value, mono = false }) {
  return (
    <div className="flex items-center justify-between text-xs">
      <span className="text-slate-400">{label}</span>
      <span className={`text-slate-700 font-medium ${mono ? 'font-mono text-[11px]' : ''}`}>{value}</span>
    </div>
  );
}

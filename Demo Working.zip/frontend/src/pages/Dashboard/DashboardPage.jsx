import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, Search, Activity, Zap, Clock, ArrowRight, TrendingUp, Database } from 'lucide-react';
import StatCard from '../../components/common/StatCard';
import InfoCard from '../../components/common/InfoCard';
import ErrorState from '../../components/common/ErrorState';
import Badge from '../../components/common/Badge';
import { fetchPatients } from '../../utils/api';
import { dashboardStats, recentActivity, quickActions, formatRelativeTime } from '../../utils/mockData';

export default function DashboardPage() {
  const navigate = useNavigate();
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => { loadPatients(); }, []);

  const loadPatients = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchPatients();
      setPatients(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const conditionStats = useMemo(() => {
    const counts = {};
    patients.forEach(p => p.conditions?.forEach(c => { counts[c] = (counts[c] || 0) + 1; }));
    return Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 6);
  }, [patients]);

  const activityIcons = { search: Search, user: Users, database: Database, system: Activity };
  const actionIcons = { users: Users, 'message-square': Search, activity: Activity };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div>
        <h1 className="text-lg font-bold text-slate-900 tracking-tight">Dashboard</h1>
        <p className="text-xs text-slate-500 mt-0.5">Patient records overview and system status</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard icon={Users} label="Total Patients" value={loading ? '—' : patients.length} trend="up" trendLabel="+3 this week" color="medical" />
        <StatCard icon={Search} label="Today's Queries" value={dashboardStats.todayQueries} trend="up" trendLabel="+8%" color="success" />
        <StatCard icon={Zap} label="AI Requests" value={dashboardStats.aiRequests} trendLabel="This month" color="warning" />
        <StatCard icon={Activity} label="System Status" value={dashboardStats.systemStatus === 'operational' ? 'Online' : 'Degraded'} color={dashboardStats.systemStatus === 'operational' ? 'success' : 'warning'} />
      </div>

      {error && <ErrorState message={error} onRetry={loadPatients} />}

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
        {/* Activity */}
        <div className="lg:col-span-2">
          <InfoCard title="Recent Activity" icon={Clock}>
            <div className="divide-y divide-slate-100">
              {recentActivity.map((item) => {
                const IconComp = activityIcons[item.icon] || Activity;
                return (
                  <div key={item.id} className="flex items-center gap-3 py-2 first:pt-0 last:pb-0">
                    <div className={`p-1.5 rounded shrink-0 ${
                      item.type === 'query' ? 'bg-blue-50 text-blue-600' :
                      item.type === 'patient_view' ? 'bg-emerald-50 text-emerald-600' :
                      'bg-slate-100 text-slate-500'
                    }`}>
                      <IconComp className="h-3.5 w-3.5" />
                    </div>
                    <p className="text-[13px] text-slate-700 flex-1 min-w-0 truncate">{item.description}</p>
                    <span className="text-[11px] text-slate-400 shrink-0">{formatRelativeTime(item.timestamp)}</span>
                  </div>
                );
              })}
            </div>
          </InfoCard>
        </div>

        {/* Quick Actions */}
        <InfoCard title="Quick Actions" icon={Zap}>
          <div className="space-y-2">
            {quickActions.map((action) => {
              const IconComp = actionIcons[action.icon] || Activity;
              return (
                <button
                  key={action.id}
                  onClick={() => navigate(action.path)}
                  className="w-full flex items-center gap-2.5 p-2.5 rounded border border-slate-200 hover:bg-slate-50 hover:border-slate-300 transition-all text-left group"
                >
                  <IconComp className="h-4 w-4 text-slate-400 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-[13px] font-medium text-slate-700">{action.title}</p>
                    <p className="text-[11px] text-slate-400">{action.description}</p>
                  </div>
                  <ArrowRight className="h-3.5 w-3.5 text-slate-300 group-hover:text-slate-500 transition-colors" />
                </button>
              );
            })}
          </div>
        </InfoCard>
      </div>

      {/* Condition Distribution */}
      {!loading && conditionStats.length > 0 && (
        <InfoCard title="Condition Distribution" icon={TrendingUp}>
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-2">
            {conditionStats.map(([condition, count]) => (
              <div key={condition} className="flex items-center justify-between p-2.5 bg-slate-50 rounded border border-slate-100">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="w-2 h-2 rounded-full bg-blue-500 shrink-0" />
                  <span className="text-[13px] text-slate-700 truncate">{condition}</span>
                </div>
                <Badge variant="neutral" size="xs">{count}</Badge>
              </div>
            ))}
          </div>
        </InfoCard>
      )}
    </div>
  );
}

/**
 * Mock data for UI placeholders.
 * TODO: Replace with real API calls when backend endpoints are available.
 */

export const dashboardStats = {
  totalPatients: 50,
  todayQueries: 12,
  aiRequests: 87,
  systemStatus: 'operational', // 'operational' | 'degraded' | 'offline'
};

export const recentActivity = [
  {
    id: 1,
    type: 'query',
    description: 'AI query: "Who has HbA1c above 7%?"',
    timestamp: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
    icon: 'search',
  },
  {
    id: 2,
    type: 'patient_view',
    description: 'Viewed patient P009 — Patient 9',
    timestamp: new Date(Date.now() - 1000 * 60 * 18).toISOString(),
    icon: 'user',
  },
  {
    id: 3,
    type: 'query',
    description: 'AI query: "Show cardiac patients"',
    timestamp: new Date(Date.now() - 1000 * 60 * 42).toISOString(),
    icon: 'search',
  },
  {
    id: 4,
    type: 'system',
    description: 'ChromaDB embeddings rebuilt successfully',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(),
    icon: 'database',
  },
  {
    id: 5,
    type: 'patient_view',
    description: 'Viewed patient P003 — Patient 3',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 3).toISOString(),
    icon: 'user',
  },
];

export const quickActions = [
  {
    id: 'search_patients',
    title: 'Search Patients',
    description: 'Browse and search the patient directory',
    icon: 'users',
    path: '/patients',
    color: 'medical',
  },
  {
    id: 'medical_inquiry',
    title: 'Medical Inquiry',
    description: 'Ask AI about patient records',
    icon: 'message-square',
    path: '/inquiry',
    color: 'success',
  },
  {
    id: 'system_health',
    title: 'System Health',
    description: 'Monitor system status',
    icon: 'activity',
    path: '/system',
    color: 'warning',
  },
];

export const systemMetrics = {
  storage: { used: 2.4, total: 10, unit: 'GB' },
  memory: { used: 4.1, total: 16, unit: 'GB' },
  gpu: { used: 65, total: 100, unit: '%' },
  responseTime: { avg: 1.2, unit: 's' },
  uptime: '99.9%',
  lastRestart: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString(),
};

/**
 * Format a timestamp into a relative time string (e.g., "5 min ago", "2 hours ago")
 */
export function formatRelativeTime(isoString) {
  const now = Date.now();
  const then = new Date(isoString).getTime();
  const diffMs = now - then;
  const diffMin = Math.floor(diffMs / 60000);
  const diffHour = Math.floor(diffMs / 3600000);
  const diffDay = Math.floor(diffMs / 86400000);

  if (diffMin < 1) return 'Just now';
  if (diffMin < 60) return `${diffMin} min ago`;
  if (diffHour < 24) return `${diffHour}h ago`;
  if (diffDay < 7) return `${diffDay}d ago`;
  return new Date(isoString).toLocaleDateString();
}

/**
 * Centralized API helper for the Patient Health Record Assistant.
 * Wraps fetch calls with error handling and dynamic Authentication headers.
 */

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://127.0.0.1:5000';

class ApiError extends Error {
  constructor(message, status, data) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.data = data;
  }
}

async function request(endpoint, options = {}) {
  const url = `${API_BASE_URL}${endpoint}`;
  
  const token = localStorage.getItem('access-token');
  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...options.headers,
  };

  const config = {
    headers,
    ...options,
  };

  try {
    const response = await fetch(url, config);
    const data = await response.json();

    if (!response.ok) {
      throw new ApiError(
        data.error || `Request failed with status ${response.status}`,
        response.status,
        data
      );
    }

    return data;
  } catch (error) {
    if (error instanceof ApiError) throw error;
    throw new ApiError(
      'Could not connect to the backend server. Please ensure it is running on http://127.0.0.1:5000',
      0,
      null
    );
  }
}

// --- Patient Endpoints ---

export async function login(username, password) {
  return request('/api/auth/login', { method: 'POST', body: JSON.stringify({ username, password }) });
}

export async function fetchCurrentUser() {
  return request('/api/auth/me');
}

export async function fetchPatients(search = '', condition = '') {
  const params = new URLSearchParams();
  if (search) params.set('search', search);
  if (condition) params.set('condition', condition);
  const query = params.toString();
  return request(`/api/patients${query ? `?${query}` : ''}`);
}

export async function fetchPatientById(patientId) {
  return request(`/api/patients/${patientId}`);
}

// --- RAG Query ---

export async function sendQuery(queryText) {
  return request('/api/query', {
    method: 'POST',
    body: JSON.stringify({ query: queryText }),
  });
}

// --- System ---

export async function fetchSystemHealth() {
  return request('/api/health');
}

export async function rebuildEmbeddings() {
  return request('/api/rebuild-embeddings', { method: 'POST' });
}

// --- Audit Trail Logs ---

export async function fetchAuditLogs() {
  return request('/api/audit-logs');
}

export { ApiError, API_BASE_URL };
export default { login, fetchCurrentUser, fetchPatients, fetchPatientById, sendQuery, fetchSystemHealth, rebuildEmbeddings, fetchAuditLogs };

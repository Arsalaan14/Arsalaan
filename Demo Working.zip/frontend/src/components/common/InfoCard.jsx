import React from 'react';

export default function InfoCard({ title, subtitle, icon: Icon, children, actions, className = '', noPadding = false }) {
  return (
    <div className={`bg-white border border-slate-200 rounded-lg shadow-card overflow-hidden ${className}`}>
      {(title || actions) && (
        <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-100 bg-slate-50/50">
          <div className="flex items-center gap-2">
            {Icon && <Icon className="h-3.5 w-3.5 text-slate-500" />}
            <div>
              {title && <h3 className="text-xs font-semibold text-slate-700 uppercase tracking-wider">{title}</h3>}
              {subtitle && <p className="text-[10px] text-slate-400 mt-0.5">{subtitle}</p>}
            </div>
          </div>
          {actions && <div className="flex items-center gap-1.5">{actions}</div>}
        </div>
      )}
      <div className={noPadding ? '' : 'p-4'}>
        {children}
      </div>
    </div>
  );
}

import React from 'react';
import { Inbox } from 'lucide-react';

/**
 * Empty state with icon, title, description, and optional action.
 */
export default function EmptyState({ icon: Icon = Inbox, title = 'No data found', description = '', actionLabel, onAction, className = '' }) {
  return (
    <div className={`flex flex-col items-center justify-center py-16 px-6 text-center ${className}`}>
      <div className="p-4 bg-clinical-50 rounded-2xl mb-4">
        <Icon className="h-10 w-10 text-clinical-400" />
      </div>
      <h3 className="text-base font-semibold text-text-primary mb-1">{title}</h3>
      {description && (
        <p className="text-sm text-text-muted max-w-sm mb-4">{description}</p>
      )}
      {actionLabel && onAction && (
        <button
          onClick={onAction}
          className="px-4 py-2 bg-medical-600 hover:bg-medical-700 text-white text-sm font-medium rounded-lg transition-smooth shadow-sm"
        >
          {actionLabel}
        </button>
      )}
    </div>
  );
}

import React, { useState } from 'react';

/**
 * Horizontal tab switcher.
 */
export default function Tabs({ tabs = [], activeTab, onTabChange, className = '' }) {
  return (
    <div className={`flex items-center border-b border-border ${className}`} role="tablist">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => onTabChange(tab.id)}
          role="tab"
          aria-selected={activeTab === tab.id}
          className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 -mb-px transition-smooth ${
            activeTab === tab.id
              ? 'border-medical-600 text-medical-700'
              : 'border-transparent text-text-muted hover:text-text-secondary hover:border-border'
          }`}
        >
          {tab.icon && <tab.icon className="h-4 w-4" />}
          {tab.label}
          {tab.count !== undefined && (
            <span className={`text-xs px-1.5 py-0.5 rounded-full ${
              activeTab === tab.id ? 'bg-medical-100 text-medical-700' : 'bg-slate-100 text-text-muted'
            }`}>
              {tab.count}
            </span>
          )}
        </button>
      ))}
    </div>
  );
}

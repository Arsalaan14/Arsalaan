import React from 'react';

export default function StatCard({ icon: Icon, label, value, trend, trendLabel, color = 'medical', className = '' }) {
  const iconColors = {
    medical: 'bg-blue-50 text-blue-600',
    success: 'bg-emerald-50 text-emerald-600',
    warning: 'bg-amber-50 text-amber-600',
    critical: 'bg-red-50 text-red-600',
  };
  const trendColor = trend === 'up' ? 'text-emerald-600' : trend === 'down' ? 'text-red-600' : 'text-slate-400';

  return (
    <div className={`bg-white border border-slate-200 rounded-lg p-3.5 shadow-card hover:shadow-card-hover transition-all ${className}`}>
      <div className="flex items-start justify-between mb-2">
        <div className={`p-1.5 rounded ${iconColors[color] || iconColors.medical}`}>
          {Icon && <Icon className="h-4 w-4" />}
        </div>
        {trend && (
          <span className={`text-[11px] font-medium ${trendColor}`}>
            {trend === 'up' ? '↑' : '↓'} {trendLabel}
          </span>
        )}
        {!trend && trendLabel && <span className="text-[11px] text-slate-400">{trendLabel}</span>}
      </div>
      <p className="text-xl font-bold text-slate-900 leading-tight">{value}</p>
      <p className="text-xs text-slate-500 mt-0.5">{label}</p>
    </div>
  );
}

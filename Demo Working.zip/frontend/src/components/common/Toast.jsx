import React, { useState, useEffect, useCallback, createContext, useContext } from 'react';
import { X, CheckCircle, AlertTriangle, Info, AlertOctagon } from 'lucide-react';

const ToastContext = createContext(null);

/**
 * Toast notification provider and hook.
 * Usage: const { addToast } = useToast();
 *        addToast({ type: 'success', message: 'Saved!' });
 */
export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);

  const addToast = useCallback((toast) => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev, { ...toast, id }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, toast.duration || 4000);
  }, []);

  const removeToast = useCallback((id) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  return (
    <ToastContext.Provider value={{ addToast }}>
      {children}
      {/* Toast Container */}
      <div className="fixed top-4 right-4 z-[100] space-y-2 max-w-sm" aria-live="polite">
        {toasts.map((toast) => (
          <ToastItem key={toast.id} toast={toast} onDismiss={() => removeToast(toast.id)} />
        ))}
      </div>
    </ToastContext.Provider>
  );
}

function ToastItem({ toast, onDismiss }) {
  const config = {
    success: { icon: CheckCircle, bg: 'bg-success-50 border-success-200', text: 'text-success-800', iconColor: 'text-success-600' },
    error: { icon: AlertOctagon, bg: 'bg-critical-50 border-critical-200', text: 'text-critical-800', iconColor: 'text-critical-600' },
    warning: { icon: AlertTriangle, bg: 'bg-warning-50 border-warning-200', text: 'text-warning-800', iconColor: 'text-warning-600' },
    info: { icon: Info, bg: 'bg-medical-50 border-medical-200', text: 'text-medical-800', iconColor: 'text-medical-600' },
  };

  const c = config[toast.type] || config.info;
  const IconComp = c.icon;

  return (
    <div className={`flex items-start gap-3 p-4 rounded-xl border shadow-card animate-slide-in-right ${c.bg}`}>
      <IconComp className={`h-5 w-5 shrink-0 mt-0.5 ${c.iconColor}`} />
      <div className="flex-1 min-w-0">
        {toast.title && <p className={`text-sm font-semibold ${c.text}`}>{toast.title}</p>}
        <p className={`text-sm ${c.text}`}>{toast.message}</p>
      </div>
      <button onClick={onDismiss} className={`shrink-0 p-0.5 rounded ${c.text} opacity-60 hover:opacity-100`}>
        <X className="h-4 w-4" />
      </button>
    </div>
  );
}

export function useToast() {
  const context = useContext(ToastContext);
  if (!context) throw new Error('useToast must be used within a ToastProvider');
  return context;
}

export default ToastProvider;

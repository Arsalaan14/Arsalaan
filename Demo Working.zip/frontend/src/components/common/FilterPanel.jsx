import React from 'react';
import { Filter } from 'lucide-react';

/**
 * Dropdown filter component.
 */
export default function FilterPanel({ label = 'Filter', value = '', options = [], onChange, className = '' }) {
  return (
    <div className={`relative ${className}`}>
      <Filter className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-text-muted pointer-events-none" />
      <select
        value={value}
        onChange={(e) => onChange?.(e.target.value)}
        aria-label={label}
        className="w-full pl-9 pr-8 py-2.5 bg-surface border border-border rounded-lg text-sm text-text-primary focus:outline-none focus:ring-2 focus:ring-medical-500/40 focus:border-medical-400 transition-smooth appearance-none cursor-pointer"
      >
        <option value="">{label}</option>
        {options.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
      <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
        <svg className="h-4 w-4 text-text-muted" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </div>
    </div>
  );
}

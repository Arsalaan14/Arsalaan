import React from 'react';
import { ChevronRight, Home } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Breadcrumb({ items = [], className = '' }) {
  return (
    <nav aria-label="Breadcrumb" className={`flex items-center gap-1 text-xs ${className}`}>
      <Link to="/" className="text-slate-400 hover:text-blue-600 transition-colors">
        <Home className="h-3.5 w-3.5" />
      </Link>
      {items.map((item, index) => (
        <React.Fragment key={index}>
          <ChevronRight className="h-3 w-3 text-slate-300" />
          {item.path ? (
            <Link to={item.path} className="text-slate-400 hover:text-blue-600 transition-colors text-xs">{item.label}</Link>
          ) : (
            <span className="text-slate-700 font-medium text-xs">{item.label}</span>
          )}
        </React.Fragment>
      ))}
    </nav>
  );
}

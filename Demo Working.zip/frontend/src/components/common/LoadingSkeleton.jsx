import React from 'react';

/**
 * Configurable skeleton loader shapes.
 * Types: 'text', 'title', 'card', 'table-row', 'avatar', 'stat', 'paragraph'
 */
export default function LoadingSkeleton({ type = 'text', count = 1, className = '' }) {
  const shapes = {
    text: 'h-4 rounded w-full',
    title: 'h-6 rounded w-2/3',
    card: 'h-32 rounded-xl w-full',
    'table-row': 'h-12 rounded w-full',
    avatar: 'h-10 w-10 rounded-full',
    stat: 'h-24 rounded-xl w-full',
    paragraph: 'space-y-2',
  };

  if (type === 'paragraph') {
    return (
      <div className={`space-y-2.5 ${className}`}>
        {[...Array(count)].map((_, i) => (
          <div key={i} className="space-y-2">
            <div className="skeleton h-4 rounded w-full" />
            <div className="skeleton h-4 rounded w-5/6" />
            <div className="skeleton h-4 rounded w-4/6" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className={`space-y-3 ${className}`}>
      {[...Array(count)].map((_, i) => (
        <div key={i} className={`skeleton ${shapes[type] || shapes.text}`} />
      ))}
    </div>
  );
}

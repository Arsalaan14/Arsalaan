import React from 'react';

/**
 * Vertical timeline with event nodes.
 */
export default function Timeline({ items = [], className = '' }) {
  if (!items.length) return null;

  return (
    <div className={`relative ${className}`}>
      {/* Vertical line */}
      <div className="absolute left-4 top-2 bottom-2 w-px bg-border" />

      <div className="space-y-4">
        {items.map((item, index) => (
          <div key={index} className="flex gap-4 relative">
            {/* Dot */}
            <div className={`relative z-10 mt-1 w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
              item.color === 'success' ? 'bg-success-100 text-success-600' :
              item.color === 'warning' ? 'bg-warning-100 text-warning-600' :
              item.color === 'critical' ? 'bg-critical-100 text-critical-600' :
              'bg-medical-100 text-medical-600'
            }`}>
              {item.icon ? <item.icon className="h-4 w-4" /> : (
                <div className={`w-2.5 h-2.5 rounded-full ${
                  item.color === 'success' ? 'bg-success-500' :
                  item.color === 'warning' ? 'bg-warning-500' :
                  item.color === 'critical' ? 'bg-critical-500' :
                  'bg-medical-500'
                }`} />
              )}
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0 pb-1">
              <p className="text-sm font-medium text-text-primary">{item.title}</p>
              {item.description && (
                <p className="text-xs text-text-muted mt-0.5">{item.description}</p>
              )}
              {item.timestamp && (
                <p className="text-[11px] text-text-muted font-mono mt-1">{item.timestamp}</p>
              )}
            </div>

            {/* Right label */}
            {item.badge && (
              <span className="text-xs font-medium text-medical-700 bg-medical-50 border border-medical-200 px-2.5 py-0.5 rounded-full shrink-0 self-start mt-0.5">
                {item.badge}
              </span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

import React from 'react';

export default function StatusChip({ status = 'online', label, className = '' }) {
  const config = {
    online: { dot: 'bg-emerald-500', text: 'text-emerald-700', bg: 'bg-emerald-50 border-emerald-200', defaultLabel: 'Online' },
    offline: { dot: 'bg-red-500', text: 'text-red-700', bg: 'bg-red-50 border-red-200', defaultLabel: 'Offline' },
    degraded: { dot: 'bg-amber-500', text: 'text-amber-700', bg: 'bg-amber-50 border-amber-200', defaultLabel: 'Degraded' },
    maintenance: { dot: 'bg-slate-400', text: 'text-slate-600', bg: 'bg-slate-50 border-slate-200', defaultLabel: 'Maintenance' },
  };
  const c = config[status] || config.online;

  return (
    <span className={`inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded border ${c.bg} ${c.text} ${className}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${c.dot}`} />
      {label || c.defaultLabel}
    </span>
  );
}

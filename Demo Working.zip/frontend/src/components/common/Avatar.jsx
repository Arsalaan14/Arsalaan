import React from 'react';

/**
 * Avatar with initials fallback.
 */
export default function Avatar({ name = '', size = 'md', className = '' }) {
  const sizes = {
    sm: 'h-8 w-8 text-xs',
    md: 'h-10 w-10 text-sm',
    lg: 'h-12 w-12 text-base',
    xl: 'h-16 w-16 text-lg',
  };

  const getInitials = (name) => {
    if (!name) return '?';
    const parts = name.trim().split(' ');
    if (parts.length >= 2) return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
    return parts[0][0]?.toUpperCase() || '?';
  };

  // Generate consistent color from name
  const getColor = (name) => {
    const colors = [
      'bg-medical-100 text-medical-700',
      'bg-success-100 text-success-700',
      'bg-warning-100 text-warning-700',
      'bg-clinical-100 text-clinical-700',
      'bg-purple-100 text-purple-700',
      'bg-indigo-100 text-indigo-700',
      'bg-teal-100 text-teal-700',
    ];
    let hash = 0;
    for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
    return colors[Math.abs(hash) % colors.length];
  };

  return (
    <div
      className={`inline-flex items-center justify-center rounded-full font-semibold shrink-0 ${sizes[size] || sizes.md} ${getColor(name)} ${className}`}
      aria-label={name}
      title={name}
    >
      {getInitials(name)}
    </div>
  );
}

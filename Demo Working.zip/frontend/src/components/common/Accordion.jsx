import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';

/**
 * Expandable/collapsible accordion section.
 */
export default function Accordion({ title, icon: Icon, children, defaultOpen = false, className = '' }) {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className={`border border-border rounded-xl overflow-hidden ${className}`}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center justify-between w-full px-5 py-3.5 bg-surface hover:bg-surface-secondary transition-smooth text-left"
        aria-expanded={isOpen}
      >
        <div className="flex items-center gap-2.5">
          {Icon && <Icon className="h-4 w-4 text-medical-600" />}
          <span className="text-sm font-semibold text-text-primary">{title}</span>
        </div>
        <ChevronDown className={`h-4 w-4 text-text-muted transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      <div
        className={`transition-all duration-200 ease-in-out overflow-hidden ${isOpen ? 'max-h-[2000px] opacity-100' : 'max-h-0 opacity-0'}`}
      >
        <div className="px-5 py-4 border-t border-border bg-surface">
          {children}
        </div>
      </div>
    </div>
  );
}

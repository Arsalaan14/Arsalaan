import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

/**
 * Pagination component with page numbers, prev/next, and item range display.
 */
export default function Pagination({ currentPage, totalPages, totalItems, itemsPerPage, onPageChange, className = '' }) {
  if (totalPages <= 1) return null;

  const start = (currentPage - 1) * itemsPerPage + 1;
  const end = Math.min(currentPage * itemsPerPage, totalItems);

  // Generate page numbers to show
  const getPageNumbers = () => {
    const pages = [];
    const maxVisible = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxVisible / 2));
    let endPage = Math.min(totalPages, startPage + maxVisible - 1);

    if (endPage - startPage < maxVisible - 1) {
      startPage = Math.max(1, endPage - maxVisible + 1);
    }

    for (let i = startPage; i <= endPage; i++) {
      pages.push(i);
    }
    return pages;
  };

  return (
    <div className={`flex items-center justify-between px-1 py-3 ${className}`}>
      <span className="text-xs text-text-muted">
        Showing <span className="font-medium text-text-secondary">{start}–{end}</span> of{' '}
        <span className="font-medium text-text-secondary">{totalItems}</span>
      </span>

      <div className="flex items-center gap-1">
        <button
          onClick={() => onPageChange(currentPage - 1)}
          disabled={currentPage === 1}
          className="p-1.5 border border-border rounded-lg hover:bg-surface-tertiary disabled:opacity-40 disabled:cursor-not-allowed transition-smooth"
          aria-label="Previous page"
        >
          <ChevronLeft className="h-4 w-4 text-text-secondary" />
        </button>

        {getPageNumbers().map((page) => (
          <button
            key={page}
            onClick={() => onPageChange(page)}
            className={`min-w-[32px] h-8 text-xs font-medium rounded-lg transition-smooth ${
              page === currentPage
                ? 'bg-medical-600 text-white shadow-sm'
                : 'text-text-secondary hover:bg-surface-tertiary border border-transparent'
            }`}
          >
            {page}
          </button>
        ))}

        <button
          onClick={() => onPageChange(currentPage + 1)}
          disabled={currentPage === totalPages}
          className="p-1.5 border border-border rounded-lg hover:bg-surface-tertiary disabled:opacity-40 disabled:cursor-not-allowed transition-smooth"
          aria-label="Next page"
        >
          <ChevronRight className="h-4 w-4 text-text-secondary" />
        </button>
      </div>
    </div>
  );
}

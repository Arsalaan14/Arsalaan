import React from 'react';
import { ChevronDown } from 'lucide-react';

export default function SectionCard({ title, icon: Icon, children, collapsible = false, defaultOpen = true, className = '' }) {
  const [isOpen, setIsOpen] = React.useState(defaultOpen);

  return (
    <div className={`bg-white border border-slate-200 rounded-lg overflow-hidden ${className}`}>
      <div
        className={`flex items-center justify-between px-4 py-2.5 bg-slate-50 border-b border-slate-100 ${collapsible ? 'cursor-pointer hover:bg-slate-100 transition-all' : ''}`}
        onClick={collapsible ? () => setIsOpen(!isOpen) : undefined}
      >
        <div className="flex items-center gap-2">
          {Icon && <Icon className="h-3.5 w-3.5 text-slate-500" />}
          <h3 className="text-xs font-semibold text-slate-700 uppercase tracking-wider">{title}</h3>
        </div>
        {collapsible && (
          <ChevronDown className={`h-3.5 w-3.5 text-slate-400 transition-transform duration-150 ${isOpen ? 'rotate-180' : ''}`} />
        )}
      </div>
      {(!collapsible || isOpen) && <div className="p-4">{children}</div>}
    </div>
  );
}

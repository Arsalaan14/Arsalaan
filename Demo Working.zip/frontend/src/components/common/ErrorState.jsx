import React from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

/**
 * Error state with retry action.
 */
export default function ErrorState({ title = 'Something went wrong', message = '', onRetry, className = '' }) {
  return (
    <div className={`bg-critical-50 border border-critical-200 rounded-xl p-5 ${className}`}>
      <div className="flex items-start gap-3">
        <div className="p-2 bg-critical-100 rounded-lg shrink-0">
          <AlertTriangle className="h-5 w-5 text-critical-600" />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="text-sm font-semibold text-critical-800">{title}</h3>
          {message && <p className="text-xs text-critical-700 mt-1">{message}</p>}
        </div>
        {onRetry && (
          <button
            onClick={onRetry}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-critical-100 hover:bg-critical-200 text-critical-800 text-xs font-medium rounded-lg transition-smooth shrink-0"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            Retry
          </button>
        )}
      </div>
    </div>
  );
}

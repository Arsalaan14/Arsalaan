import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Clock, Layers, FileText, Activity, AlertTriangle, ArrowRight } from 'lucide-react';

export default function AIChat() {
  const [query, setQuery] = useState('');
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: 'Hello! I am your AI Patient Health Record Assistant. Ask me any natural language question about the patient records (e.g., "Who has diabetes?", "What medications is Patient 3 taking?", or "Summarize Patient P002").',
    }
  ]);
  const [loading, setLoading] = useState(false);
  const [diagnostics, setDiagnostics] = useState(null);
  
  const messagesEndRef = useRef(null);

  const exampleQueries = [
    'Who has HbA1c above 7%?',
    'Show cardiac patients.',
    'Summarize Patient P009.',
    'What medications is Patient 5 taking?'
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = async (e, text = null) => {
    if (e) e.preventDefault();
    const queryText = text || query;
    if (!queryText.trim() || loading) return;

    // Append user message
    const userMessage = { role: 'user', content: queryText };
    setMessages(prev => [...prev, userMessage]);
    if (!text) setQuery('');
    setLoading(true);
    setDiagnostics(null);

    try {
      const response = await fetch('http://127.0.0.1:5000/api/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: queryText })
      });

      if (!response.ok) {
        throw new Error('API Request failed. Make sure the local backend server is running.');
      }

      const data = await response.json();
      
      // Append assistant response
      setMessages(prev => [...prev, { role: 'assistant', content: data.answer }]);
      
      // Set diagnostics
      setDiagnostics({
        retrievedDocs: data.retrieved_docs,
        docIds: data.doc_ids,
        retrievalTime: data.retrieval_time,
        generationTime: data.generation_time,
        totalTime: data.retrieval_time + data.generation_time
      });

    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: '⚠️ Error: Failed to connect to the backend server. Please verify the Flask server is running on port 5000 and that LM Studio is active.' 
      }]);
    } finally {
      setLoading(false);
    }
  };

  // Basic function to render simple markdown-like syntax (bolding, sections)
  const formatResponse = (text) => {
    if (!text) return '';
    return text.split('\n').map((line, i) => {
      // Headers
      if (line.startsWith('# ')) {
        return <h1 key={i} className="text-xl font-bold mt-4 mb-2 text-zinc-900 border-b border-zinc-200 pb-1">{line.replace('# ', '')}</h1>;
      }
      if (line.startsWith('## ')) {
        return <h2 key={i} className="text-lg font-bold mt-3 mb-1.5 text-zinc-800">{line.replace('## ', '')}</h2>;
      }
      if (line.startsWith('### ')) {
        return <h3 key={i} className="text-base font-semibold mt-2 mb-1 text-zinc-700">{line.replace('### ', '')}</h3>;
      }
      // Bullet points
      if (line.startsWith('* ') || line.startsWith('- ')) {
        const content = line.substring(2);
        return (
          <li key={i} className="list-disc ml-5 mb-1 text-zinc-650">
            {parseInlineFormatting(content)}
          </li>
        );
      }
      // Empty lines
      if (!line.trim()) {
        return <div key={i} className="h-2"></div>;
      }
      return <p key={i} className="mb-2 leading-relaxed text-zinc-750">{parseInlineFormatting(line)}</p>;
    });
  };

  const parseInlineFormatting = (text) => {
    // Basic bold parser **text**
    const parts = text.split(/(\*\*.*?\*\*)/g);
    return parts.map((part, idx) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={idx} className="font-bold text-zinc-900">{part.slice(2, -2)}</strong>;
      }
      return part;
    });
  };

  return (
    <div className="max-w-4xl mx-auto h-[calc(100vh-12rem)] min-h-[500px] flex flex-col bg-white border border-zinc-200 rounded-xl overflow-hidden shadow-sm">
      {/* Chat Message Window */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg, index) => (
          <div 
            key={index} 
            className={`flex gap-3 max-w-[85%] ${msg.role === 'user' ? 'ml-auto flex-row-reverse' : ''} animate-in fade-in duration-200`}
          >
            {/* Avatar */}
            <div className={`h-8 w-8 rounded-full flex items-center justify-center shrink-0 ${
              msg.role === 'user' 
                ? 'bg-blue-100 text-blue-700' 
                : 'bg-zinc-100 text-zinc-700'
            }`}>
              {msg.role === 'user' ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
            </div>

            {/* Bubble */}
            <div className={`p-4 rounded-2xl shadow-sm text-sm ${
              msg.role === 'user'
                ? 'bg-blue-600 text-white rounded-tr-none'
                : 'bg-zinc-50 border border-zinc-200 rounded-tl-none text-zinc-800'
            }`}>
              {msg.role === 'user' ? (
                <p className="whitespace-pre-wrap">{msg.content}</p>
              ) : (
                <div className="space-y-0.5">
                  {formatResponse(msg.content)}
                </div>
              )}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex gap-3 max-w-[80%] animate-pulse">
            <div className="h-8 w-8 rounded-full bg-zinc-200 flex items-center justify-center">
              <Bot className="h-4 w-4 text-zinc-400" />
            </div>
            <div className="p-4 bg-zinc-50 border border-zinc-200 rounded-2xl rounded-tl-none space-y-2 w-48">
              <div className="h-3 bg-zinc-300 rounded w-5/6"></div>
              <div className="h-3 bg-zinc-300 rounded w-full"></div>
              <div className="h-3 bg-zinc-300 rounded w-2/3"></div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Example Queries suggestions */}
      {messages.length === 1 && (
        <div className="px-4 py-3 border-t border-zinc-100 bg-zinc-50">
          <span className="text-xs font-semibold text-zinc-450 block mb-2">Try asking:</span>
          <div className="flex flex-wrap gap-2">
            {exampleQueries.map((ex, i) => (
              <button
                key={i}
                onClick={(e) => handleSubmit(e, ex)}
                className="text-xs bg-white border border-zinc-200 text-zinc-700 hover:border-blue-500 hover:text-blue-600 px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
              >
                {ex} <ArrowRight className="h-3 w-3" />
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input Bar */}
      <form onSubmit={handleSubmit} className="p-4 border-t border-zinc-200 flex gap-2 bg-zinc-50">
        <input
          type="text"
          placeholder="Type your question..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          disabled={loading}
          className="flex-1 px-4 py-2.5 bg-white border border-zinc-200 rounded-lg text-sm text-zinc-900 focus:outline-none focus:ring-2 focus:ring-blue-500/50 disabled:opacity-55"
        />
        <button
          type="submit"
          disabled={loading || !query.trim()}
          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors flex items-center justify-center disabled:bg-zinc-200 disabled:text-zinc-450 disabled:cursor-not-allowed shadow-sm"
        >
          <Send className="h-4 w-4" />
        </button>
      </form>
    </div>
  );
}

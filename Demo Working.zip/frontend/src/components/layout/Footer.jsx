import React from 'react';
import { Shield } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-white px-4 py-2">
      <div className="flex flex-col sm:flex-row items-center justify-between gap-1 text-[11px] text-slate-400">
        <div className="flex items-center gap-1.5">
          <Shield className="h-3 w-3" />
          <span>PHRA v1.0.0</span>
        </div>
        <div className="flex items-center gap-3">
          <span>Confidential Clinical Database</span>
          <span className="hidden sm:inline">•</span>
          <span className="hidden sm:inline">HIPAA Compliant</span>
        </div>
      </div>
    </footer>
  );
}

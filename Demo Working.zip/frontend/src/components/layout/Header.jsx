import React from 'react';
import { useLocation } from 'react-router-dom';
import { Bell, Menu } from 'lucide-react';
import Breadcrumb from '../common/Breadcrumb';
import StatusChip from '../common/StatusChip';

const routeLabels = {
  '/': 'Dashboard',
  '/patients': 'Patient Directory',
  '/inquiry': 'Clinical Information Retrieval',
  '/system': 'System Health',
  '/settings': 'Settings',
};

function getBreadcrumbs(pathname) {
  if (pathname === '/') return [{ label: 'Dashboard' }];
  const segments = pathname.split('/').filter(Boolean);
  const crumbs = [];
  if (segments[0] === 'patients') {
    crumbs.push({ label: 'Patient Directory', path: '/patients' });
    if (segments[1]) crumbs.push({ label: `${segments[1]}` });
  } else {
    crumbs.push({ label: routeLabels[`/${segments[0]}`] || segments[0] });
  }
  return crumbs;
}

export default function Header({ onMenuClick, systemStatus = 'operational' }) {
  const location = useLocation();
  const breadcrumbs = getBreadcrumbs(location.pathname);
  const statusMap = { operational: 'online', degraded: 'degraded', offline: 'offline' };

  const user = JSON.parse(localStorage.getItem('user') || '{}');
  const role = user.role || 'provider';

  const handleLogout = () => {
    localStorage.removeItem('access-token');
    localStorage.removeItem('user');
    window.location.href = '/login';
  };

  return (
    <header className="sticky top-0 z-30 bg-white border-b border-slate-200 shadow-header">
      <div className="flex items-center justify-between h-11 px-3 lg:px-4">
        <div className="flex items-center gap-3">
          <button
            onClick={onMenuClick}
            className="lg:hidden p-1.5 hover:bg-slate-100 rounded text-slate-500 transition-all"
            aria-label="Open navigation"
          >
            <Menu className="h-4 w-4" />
          </button>
          <Breadcrumb items={breadcrumbs} />
        </div>
        <div className="flex items-center gap-2">
          <StatusChip
            status={statusMap[systemStatus] || 'online'}
            label={systemStatus === 'operational' ? 'Online' : systemStatus}
            className="hidden sm:inline-flex"
          />
          <button className="relative p-1.5 hover:bg-slate-100 rounded text-slate-500 transition-all" aria-label="Notifications">
            <Bell className="h-4 w-4" />
            <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-red-500 rounded-full" />
          </button>
          <div className="flex items-center gap-2 pl-2 ml-1 border-l border-slate-200">
            <div className="text-right hidden sm:block">
              <div className="text-[11px] font-semibold text-slate-700">{user.name || role}</div>
              <div className="text-[9px] uppercase text-slate-400">{role}</div>
            </div>
            <button onClick={handleLogout} className="text-[10px] font-semibold text-slate-500 hover:text-red-600 px-2 py-1 rounded border border-slate-200">Logout</button>
            <div className="h-7 w-7 rounded-full bg-slate-700 flex items-center justify-center text-[10px] font-semibold text-white ml-1">
              {role.slice(0, 2).toUpperCase()}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

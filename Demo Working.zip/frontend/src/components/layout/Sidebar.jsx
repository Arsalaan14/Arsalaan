import React from 'react';
import { useLocation, NavLink } from 'react-router-dom';
import {
  LayoutDashboard, Users, Search, Activity, Settings,
  ChevronLeft, ChevronRight, Heart, ShieldCheck
} from 'lucide-react';

const navItems = [
  { path: '/', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/patients', label: 'Patients', icon: Users },
  { path: '/inquiry', label: 'Clinical Search', icon: Search },
  { path: '/system', label: 'System', icon: Activity },
  { path: '/settings', label: 'Settings', icon: Settings },
];

export default function Sidebar({ isCollapsed, onToggle, isMobileOpen, onMobileClose }) {
  const location = useLocation();
  const activeRole = JSON.parse(localStorage.getItem('user') || '{}').role || 'provider';
  const displayedItems = [...navItems];
  if (activeRole === 'admin') {
    displayedItems.push({ path: '/audit-logs', label: 'Audit Logs', icon: ShieldCheck });
  }

  return (
    <>
      {isMobileOpen && (
        <div className="fixed inset-0 bg-black/30 z-40 lg:hidden" onClick={onMobileClose} />
      )}
      <aside
        className={`fixed top-0 left-0 h-full z-40 flex flex-col bg-sidebar-bg transition-all duration-200
          ${isCollapsed ? 'w-[52px]' : 'w-52'}
          ${isMobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}
      >
        {/* Logo */}
        <div className={`flex items-center h-11 border-b border-white/8 px-3 ${isCollapsed ? 'justify-center' : 'gap-2.5'}`}>
          <div className="p-1.5 bg-blue-600 rounded shrink-0">
            <Heart className="h-3.5 w-3.5 text-white" />
          </div>
          {!isCollapsed && (
            <div className="overflow-hidden">
              <span className="text-[11px] font-bold text-white truncate block leading-tight">PHRA</span>
              <span className="text-[9px] text-slate-400 truncate block leading-tight">Clinical Platform</span>
            </div>
          )}
        </div>

        {/* Nav */}
        <nav className="flex-1 py-2 px-1.5 space-y-0.5 overflow-y-auto">
          {displayedItems.map((item) => {
            const isActive = item.path === '/' ? location.pathname === '/' : location.pathname.startsWith(item.path);
            return (
              <NavLink
                key={item.path}
                to={item.path}
                onClick={onMobileClose}
                className={`flex items-center gap-2 px-2.5 py-[7px] rounded text-[12px] font-medium transition-all group relative
                  ${isActive ? 'bg-blue-600/20 text-white' : 'text-slate-400 hover:bg-white/5 hover:text-slate-200'}
                  ${isCollapsed ? 'justify-center' : ''}
                `}
                title={isCollapsed ? item.label : undefined}
              >
                {isActive && <div className="absolute left-0 top-1/2 -translate-y-1/2 w-[2px] h-4 bg-blue-400 rounded-r" />}
                <item.icon className={`h-[15px] w-[15px] shrink-0 ${isActive ? 'text-blue-400' : ''}`} />
                {!isCollapsed && <span className="truncate">{item.label}</span>}
                {isCollapsed && (
                  <div className="absolute left-full ml-1.5 px-2 py-1 bg-slate-800 text-white text-[11px] font-medium rounded opacity-0 pointer-events-none group-hover:opacity-100 transition-opacity whitespace-nowrap z-50 shadow-lg">
                    {item.label}
                  </div>
                )}
              </NavLink>
            );
          })}
        </nav>

        {/* Collapse */}
        <div className="p-1.5 border-t border-white/8">
          <button
            onClick={onToggle}
            className="hidden lg:flex items-center justify-center w-full py-1.5 text-slate-500 hover:text-slate-300 hover:bg-white/5 rounded transition-all text-[11px]"
            aria-label={isCollapsed ? 'Expand' : 'Collapse'}
          >
            {isCollapsed ? <ChevronRight className="h-3.5 w-3.5" /> : (
              <span className="flex items-center gap-1.5"><ChevronLeft className="h-3.5 w-3.5" />Collapse</span>
            )}
          </button>
        </div>
      </aside>
    </>
  );
}

import React, { useState, useEffect } from 'react';
import { Search, Heart, User, Activity, ShieldAlert, X, Calendar, Clipboard, Check, Filter } from 'lucide-react';

export default function Dashboard() {
  const [patients, setPatients] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCondition, setSelectedCondition] = useState('');
  const [selectedPatientId, setSelectedPatientId] = useState(null);
  const [selectedPatientDetails, setSelectedPatientDetails] = useState(null);
  const [loadingList, setLoadingList] = useState(true);
  const [loadingDetails, setLoadingDetails] = useState(false);
  const [error, setError] = useState(null);

  // Pagination states
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 8;

  useEffect(() => {
    fetchPatients();
  }, []);

  useEffect(() => {
    if (selectedPatientId) {
      fetchPatientDetails(selectedPatientId);
    } else {
      setSelectedPatientDetails(null);
    }
  }, [selectedPatientId]);

  const fetchPatients = async () => {
    setLoadingList(true);
    setError(null);
    try {
      const res = await fetch('http://127.0.0.1:5000/api/patients');
      if (!res.ok) throw new Error('Failed to fetch patient list');
      const data = await res.json();
      setPatients(data);
    } catch (err) {
      console.error(err);
      setError('Could not connect to the API. Make sure the backend server is running on http://127.0.0.1:5000');
    } finally {
      setLoadingList(false);
    }
  };

  const fetchPatientDetails = async (id) => {
    setLoadingDetails(true);
    try {
      const res = await fetch(`http://127.0.0.1:5000/api/patients/${id}`);
      if (!res.ok) throw new Error('Failed to fetch patient details');
      const data = await res.json();
      setSelectedPatientDetails(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingDetails(false);
    }
  };

  // Filter patients
  const filteredPatients = patients.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          p.patient_id.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCondition = selectedCondition === '' || 
                             p.conditions.some(c => c.toLowerCase() === selectedCondition.toLowerCase());
                             
    return matchesSearch && matchesCondition;
  });

  // Calculate statistics
  const totalPatients = patients.length;
  const avgAge = totalPatients > 0 
    ? Math.round(patients.reduce((sum, p) => sum + (p.age || 0), 0) / totalPatients)
    : 0;

  // Find all unique conditions and count them
  const conditionCounts = {};
  patients.forEach(p => {
    p.conditions?.forEach(c => {
      conditionCounts[c] = (conditionCounts[c] || 0) + 1;
    });
  });
  const topCondition = Object.keys(conditionCounts).length > 0
    ? Object.entries(conditionCounts).sort((a, b) => b[1] - a[1])[0][0]
    : 'N/A';

  // Count high risk conditions (e.g., Hypertension, Coronary Artery Disease, chronic issues)
  const highRiskPatients = patients.filter(p => 
    p.conditions?.some(c => 
      c.toLowerCase().includes('heart') || 
      c.toLowerCase().includes('coronary') || 
      c.toLowerCase().includes('cardiac') ||
      c.toLowerCase().includes('kidney') ||
      c.toLowerCase().includes('diabetes')
    )
  ).length;

  // Pagination logic
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentPatients = filteredPatients.slice(indexOfFirstItem, indexOfLastItem);
  const totalPages = Math.ceil(filteredPatients.length / itemsPerPage);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  return (
    <div className="space-y-6">
      {/* Error Alert */}
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-800 rounded-xl p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <ShieldAlert className="h-5 w-5 text-red-600" />
            <span className="text-sm font-medium">{error}</span>
          </div>
          <button 
            onClick={fetchPatients} 
            className="text-xs bg-red-100 hover:bg-red-200 text-red-800 px-3 py-1.5 rounded-lg transition-colors font-medium"
          >
            Retry Connection
          </button>
        </div>
      )}

      {/* Main Content split */}
      <div className="flex flex-col lg:flex-row gap-6 items-start">
        {/* Left Side: Table of Patients */}
        <div className={`transition-all duration-300 w-full ${selectedPatientId ? 'lg:w-7/12' : 'lg:w-full'}`}>
          <div className="bg-white border border-zinc-200 rounded-xl overflow-hidden shadow-sm">
            {/* Table Header toolbar */}
            <div className="p-4 border-b border-zinc-200 flex flex-col md:flex-row gap-3 items-center justify-between">
              <div className="relative w-full md:max-w-xs">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-zinc-400" />
                <input
                  type="text"
                  placeholder="Search Patient Name or ID..."
                  value={searchTerm}
                  onChange={(e) => { setSearchTerm(e.target.value); setCurrentPage(1); }}
                  className="w-full pl-9 pr-4 py-2 bg-zinc-50 border border-zinc-200 rounded-lg text-sm text-zinc-900 placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-blue-500/50"
                />
              </div>

              {/* Conditions Dropdown Filter */}
              <div className="flex gap-2 w-full md:w-auto">
                <div className="relative w-full md:w-48">
                  <Filter className="absolute left-3 top-2.5 h-4 w-4 text-zinc-400" />
                  <select
                    value={selectedCondition}
                    onChange={(e) => { setSelectedCondition(e.target.value); setCurrentPage(1); }}
                    className="w-full pl-9 pr-8 py-2 bg-zinc-50 border border-zinc-200 rounded-lg text-sm text-zinc-900 focus:outline-none focus:ring-2 focus:ring-blue-500/50 appearance-none"
                  >
                    <option value="">All Conditions</option>
                    {Object.keys(conditionCounts).map(cond => (
                      <option key={cond} value={cond}>{cond} ({conditionCounts[cond]})</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-zinc-200 bg-zinc-50 text-zinc-500 text-xs font-semibold uppercase">
                    <th className="py-3.5 px-4">Patient ID</th>
                    <th className="py-3.5 px-4">Name</th>
                    <th className="py-3.5 px-4">Demographics</th>
                    <th className="py-3.5 px-4">Active Conditions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-200 text-sm">
                  {loadingList ? (
                    [...Array(5)].map((_, i) => (
                      <tr key={i} className="animate-pulse">
                        <td className="py-4 px-4"><div className="h-4 bg-zinc-200 rounded w-16"></div></td>
                        <td className="py-4 px-4"><div className="h-4 bg-zinc-200 rounded w-24"></div></td>
                        <td className="py-4 px-4"><div className="h-4 bg-zinc-200 rounded w-20"></div></td>
                        <td className="py-4 px-4"><div className="h-4 bg-zinc-200 rounded w-32"></div></td>
                      </tr>
                    ))
                  ) : currentPatients.length > 0 ? (
                    currentPatients.map((p) => (
                      <tr
                        key={p.patient_id}
                        onClick={() => setSelectedPatientId(selectedPatientId === p.patient_id ? null : p.patient_id)}
                        className={`hover:bg-zinc-50 cursor-pointer transition-colors ${
                          selectedPatientId === p.patient_id 
                            ? 'bg-blue-50/50 border-l-2 border-blue-600' 
                            : ''
                        }`}
                      >
                        <td className="py-3.5 px-4 font-mono font-medium text-blue-600">
                          {p.patient_id}
                        </td>
                        <td className="py-3.5 px-4 font-semibold text-zinc-900">
                          {p.name}
                        </td>
                        <td className="py-3.5 px-4 text-zinc-500">
                          {p.age} yrs • {p.gender} • {p.blood_group}
                        </td>
                        <td className="py-3.5 px-4">
                          <div className="flex flex-wrap gap-1">
                            {p.conditions?.map((c, i) => (
                              <span
                                key={i}
                                className="text-[10px] bg-zinc-100 border border-zinc-200 text-zinc-800 font-medium px-2 py-0.5 rounded"
                              >
                                {c}
                              </span>
                            ))}
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="4" className="py-8 px-4 text-center text-zinc-500">
                        No patients found matching the criteria.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination Controls */}
            {totalPages > 1 && (
              <div className="p-4 border-t border-zinc-200 flex items-center justify-between">
                <span className="text-xs text-zinc-500">
                  Showing {indexOfFirstItem + 1} - {Math.min(indexOfLastItem, filteredPatients.length)} of {filteredPatients.length} patients
                </span>
                <div className="flex gap-1">
                  <button
                    disabled={currentPage === 1}
                    onClick={() => handlePageChange(currentPage - 1)}
                    className="p-1.5 bg-white border border-zinc-200 rounded-lg hover:bg-zinc-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-zinc-600"
                  >
                    &larr; Prev
                  </button>
                  <span className="px-3 py-1 text-sm font-semibold flex items-center text-zinc-700">
                    {currentPage} / {totalPages}
                  </span>
                  <button
                    disabled={currentPage === totalPages}
                    onClick={() => handlePageChange(currentPage + 1)}
                    className="p-1.5 bg-white border border-zinc-200 rounded-lg hover:bg-zinc-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-zinc-600"
                  >
                    Next &rarr;
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Side: Detailed Patient Panel */}
        {selectedPatientId && (
          <div className="w-full lg:w-5/12 bg-white border border-zinc-200 rounded-xl shadow-sm overflow-hidden transition-all duration-300 animate-in fade-in slide-in-from-right duration-200">
            {loadingDetails ? (
              <div className="p-6 space-y-4">
                <div className="flex justify-between items-center">
                  <div className="h-6 bg-zinc-200 rounded w-1/3 animate-pulse"></div>
                  <div className="h-6 bg-zinc-200 rounded w-6 animate-pulse"></div>
                </div>
                <div className="space-y-2">
                  <div className="h-4 bg-zinc-200 rounded w-full animate-pulse"></div>
                  <div className="h-4 bg-zinc-200 rounded w-5/6 animate-pulse"></div>
                </div>
                <div className="h-40 bg-zinc-100 rounded animate-pulse"></div>
              </div>
            ) : selectedPatientDetails ? (
              <div className="p-6 space-y-6">
                {/* Header */}
                <div className="flex justify-between items-start">
                  <div>
                    <h2 className="text-xl font-bold text-zinc-900">
                      {selectedPatientDetails.name}
                    </h2>
                    <span className="text-xs font-mono text-zinc-500 bg-zinc-100 rounded px-1.5 py-0.5">
                      ID: {selectedPatientDetails.patient_id}
                    </span>
                  </div>
                  <button
                    onClick={() => setSelectedPatientId(null)}
                    className="p-1 bg-zinc-100 hover:bg-zinc-200 rounded-full transition-colors text-zinc-500 hover:text-zinc-700"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>

                {/* Details list */}
                <div className="grid grid-cols-2 gap-4 bg-zinc-50 border border-zinc-200 rounded-xl p-4 text-sm">
                  <div>
                    <span className="block text-zinc-500 text-xs uppercase font-semibold tracking-wider">Age</span>
                    <span className="font-semibold text-zinc-900">{selectedPatientDetails.age} yrs</span>
                  </div>
                  <div>
                    <span className="block text-zinc-500 text-xs uppercase font-semibold tracking-wider">Gender</span>
                    <span className="font-semibold text-zinc-900">{selectedPatientDetails.gender}</span>
                  </div>
                  <div>
                    <span className="block text-zinc-500 text-xs uppercase font-semibold tracking-wider">Blood Group</span>
                    <span className="font-semibold text-zinc-900">{selectedPatientDetails.blood_group}</span>
                  </div>
                  <div>
                    <span className="block text-zinc-500 text-xs uppercase font-semibold tracking-wider">Contact Phone</span>
                    <span className="font-semibold text-zinc-900 text-xs">{selectedPatientDetails.contact?.phone || 'N/A'}</span>
                  </div>
                  <div className="col-span-2 border-t border-zinc-200 pt-2">
                    <span className="block text-zinc-500 text-xs uppercase font-semibold tracking-wider">Email</span>
                    <span className="font-semibold text-zinc-900 text-xs">{selectedPatientDetails.contact?.email || 'N/A'}</span>
                  </div>
                  <div className="col-span-2">
                    <span className="block text-zinc-500 text-xs uppercase font-semibold tracking-wider">Address</span>
                    <span className="font-semibold text-zinc-900 text-xs">{selectedPatientDetails.address || 'N/A'}</span>
                  </div>
                </div>

                {/* Conditions & Allergies */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <span className="text-xs font-semibold text-zinc-500 uppercase tracking-wider flex items-center gap-1.5 mb-2">
                      <Heart className="h-3.5 w-3.5 text-blue-600" /> Active Conditions
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {selectedPatientDetails.conditions?.length > 0 ? (
                        selectedPatientDetails.conditions.map((c, i) => (
                          <span key={i} className="text-xs bg-zinc-100 text-zinc-800 border border-zinc-200 font-medium px-2 py-0.5 rounded">
                            {c}
                          </span>
                        ))
                      ) : (
                        <span className="text-xs text-zinc-400 italic">None</span>
                      )}
                    </div>
                  </div>

                  <div>
                    <span className="text-xs font-semibold text-zinc-500 uppercase tracking-wider flex items-center gap-1.5 mb-2">
                      <ShieldAlert className="h-3.5 w-3.5 text-blue-600" /> Allergies
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {selectedPatientDetails.allergies?.length > 0 ? (
                        selectedPatientDetails.allergies.map((a, i) => (
                          <span key={i} className="text-xs bg-zinc-100 text-zinc-800 border border-zinc-200 font-medium px-2 py-0.5 rounded">
                            {a}
                          </span>
                        ))
                      ) : (
                        <span className="text-xs text-zinc-400 italic">None</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Medications Table */}
                <div className="border border-zinc-200 rounded-xl overflow-hidden">
                  <div className="bg-zinc-50 px-4 py-2.5 border-b border-zinc-200">
                    <span className="text-xs font-bold text-zinc-650 uppercase tracking-wider">
                      Current Medications
                    </span>
                  </div>
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-zinc-200 text-zinc-500">
                        <th className="py-2 px-4 font-semibold">Medication</th>
                        <th className="py-2 px-4 font-semibold">Dosage</th>
                        <th className="py-2 px-4 font-semibold">Frequency</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-zinc-200">
                      {selectedPatientDetails.medications?.length > 0 ? (
                        selectedPatientDetails.medications.map((m, i) => (
                          <tr key={i} className="text-zinc-800">
                            <td className="py-2 px-4 font-medium">{m.name}</td>
                            <td className="py-2 px-4 font-mono">{m.dosage}</td>
                            <td className="py-2 px-4 text-zinc-500">{m.frequency}</td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan="3" className="py-4 px-4 text-center text-zinc-400 italic">
                            No active medications.
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>

                {/* Lab Reports Timeline */}
                <div>
                  <span className="text-xs font-bold text-zinc-500 uppercase tracking-wider flex items-center gap-1.5 mb-3">
                    <Clipboard className="h-4 w-4 text-blue-600" /> Lab Reports & Timeline
                  </span>
                  <div className="space-y-2">
                    {selectedPatientDetails.lab_reports?.length > 0 ? (
                      selectedPatientDetails.lab_reports.map((r, i) => (
                        <div key={i} className="flex justify-between items-center text-xs p-2.5 bg-zinc-50 border border-zinc-200 rounded-lg">
                          <div>
                            <span className="font-semibold text-zinc-900">{r.test_name}</span>
                            <span className="block text-[10px] text-zinc-500 font-mono mt-0.5">{r.date}</span>
                          </div>
                          <span className="font-mono text-xs font-bold bg-blue-50 text-blue-700 border border-blue-100 px-2 py-0.5 rounded">
                            {r.value}
                          </span>
                        </div>
                      ))
                    ) : (
                      <span className="text-xs text-zinc-400 italic">No lab reports on file.</span>
                    )}
                  </div>
                </div>

                {/* Doctor Visits */}
                <div>
                  <span className="text-xs font-bold text-zinc-500 uppercase tracking-wider flex items-center gap-1.5 mb-3">
                    <Calendar className="h-4 w-4 text-blue-600" /> Recent Consultations
                  </span>
                  <div className="space-y-2">
                    {selectedPatientDetails.visits?.length > 0 ? (
                      selectedPatientDetails.visits.map((v, i) => (
                        <div key={i} className="flex justify-between items-start text-xs p-2.5 bg-zinc-50 border border-zinc-200 rounded-lg">
                          <div>
                            <span className="font-semibold text-zinc-900 block">{v.reason}</span>
                            <span className="text-[10px] text-zinc-500 block font-mono mt-0.5">{v.date}</span>
                          </div>
                          <span className="text-xs font-medium text-blue-700 bg-blue-50 border border-blue-100 px-2.5 py-0.5 rounded-full">
                            {v.doctor}
                          </span>
                        </div>
                      ))
                    ) : (
                      <span className="text-xs text-zinc-400 italic">No doctor visits recorded.</span>
                    )}
                  </div>
                </div>
              </div>
            ) : null}
          </div>
        )}
      </div>
    </div>
  );
}

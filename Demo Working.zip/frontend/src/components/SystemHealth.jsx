import React, { useState, useEffect } from 'react';
import { ShieldCheck, ShieldAlert, Cpu, Database, RefreshCw, Server, AlertTriangle } from 'lucide-react';

export default function SystemHealth() {
  const [healthData, setHealthData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [rebuilding, setRebuilding] = useState(false);
  const [rebuildMsg, setRebuildMsg] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchHealth();
  }, []);

  const fetchHealth = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('http://127.0.0.1:5000/api/health');
      if (!res.ok) throw new Error('Failed to fetch system health');
      const data = await res.json();
      setHealthData(data);
    } catch (err) {
      console.error(err);
      setError('Could not fetch system health. Please ensure the backend is running.');
    } finally {
      setLoading(false);
    }
  };

  const handleRebuild = async () => {
    if (rebuilding) return;
    setRebuilding(true);
    setRebuildMsg(null);
    try {
      const res = await fetch('http://127.0.0.1:5000/api/rebuild-embeddings', {
        method: 'POST'
      });
      const data = await res.json();
      if (res.ok) {
        setRebuildMsg({ type: 'success', text: data.message || 'ChromaDB embeddings successfully rebuilt!' });
        fetchHealth();
      } else {
        setRebuildMsg({ type: 'error', text: data.error || 'Failed to rebuild embeddings.' });
      }
    } catch (err) {
      setRebuildMsg({ type: 'error', text: 'Error connecting to backend server.' });
    } finally {
      setRebuilding(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="bg-white dark:bg-[#0c0c0f] border border-zinc-200 dark:border-zinc-800 rounded-xl p-6 shadow-sm space-y-6">
        <div className="flex justify-between items-center border-b border-zinc-200 dark:border-zinc-800 pb-4">
          <div>
            <h2 className="text-lg font-bold text-zinc-950 dark:text-zinc-50">System Configuration & Health</h2>
            <p className="text-xs text-zinc-500 mt-0.5">Status of the local indexing pipeline, database, and LLM servers.</p>
          </div>
          <button
            onClick={fetchHealth}
            disabled={loading}
            className="p-2 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg text-zinc-500 hover:text-zinc-700 transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {error ? (
          <div className="bg-rose-50 dark:bg-rose-955/20 border border-rose-200 dark:border-rose-900/30 text-rose-800 dark:text-rose-455 p-4 rounded-xl flex items-center gap-3">
            <ShieldAlert className="h-6 w-6 text-rose-500 shrink-0" />
            <div className="text-xs font-semibold">{error}</div>
          </div>
        ) : loading ? (
          <div className="space-y-4 py-4">
            <div className="h-10 bg-zinc-100 dark:bg-zinc-900 rounded animate-pulse"></div>
            <div className="h-10 bg-zinc-100 dark:bg-zinc-900 rounded animate-pulse"></div>
            <div className="h-10 bg-zinc-100 dark:bg-zinc-900 rounded animate-pulse"></div>
          </div>
        ) : healthData ? (
          <div className="space-y-4">
            {/* Database Status */}
            <div className="flex items-center justify-between p-3.5 bg-zinc-50 dark:bg-[#09090b]/50 border border-zinc-200 dark:border-zinc-800 rounded-xl">
              <div className="flex items-center gap-3">
                <Database className="h-5 w-5 text-blue-500" />
                <div>
                  <span className="font-semibold text-sm text-zinc-900 dark:text-zinc-100 block">Vector Index (ChromaDB)</span>
                  <span className="text-[10px] text-zinc-500 block font-mono">{healthData.database?.path}</span>
                </div>
              </div>
              {healthData.database?.exists ? (
                <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 dark:bg-emerald-950/20 dark:text-emerald-400 px-2.5 py-0.5 rounded-full flex items-center gap-1.5 border border-emerald-100 dark:border-emerald-900/30">
                  <ShieldCheck className="h-3.5 w-3.5" /> Ready
                </span>
              ) : (
                <span className="text-xs font-semibold text-rose-700 bg-rose-50 dark:bg-rose-950/20 dark:text-rose-400 px-2.5 py-0.5 rounded-full flex items-center gap-1.5 border border-rose-100 dark:border-rose-900/30">
                  <ShieldAlert className="h-3.5 w-3.5" /> Missing
                </span>
              )}
            </div>

            {/* Dataset Status */}
            <div className="flex items-center justify-between p-3.5 bg-zinc-50 dark:bg-[#09090b]/50 border border-zinc-200 dark:border-zinc-800 rounded-xl">
              <div className="flex items-center gap-3">
                <Server className="h-5 w-5 text-indigo-500" />
                <div>
                  <span className="font-semibold text-sm text-zinc-900 dark:text-zinc-100 block">Patient Records (JSON)</span>
                  <span className="text-[10px] text-zinc-500 block font-mono">{healthData.dataset?.path}</span>
                </div>
              </div>
              {healthData.dataset?.exists ? (
                <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 dark:bg-emerald-950/20 dark:text-emerald-400 px-2.5 py-0.5 rounded-full flex items-center gap-1.5 border border-emerald-100 dark:border-emerald-900/30">
                  <ShieldCheck className="h-3.5 w-3.5" /> Loaded
                </span>
              ) : (
                <span className="text-xs font-semibold text-rose-700 bg-rose-50 dark:bg-rose-950/20 dark:text-rose-400 px-2.5 py-0.5 rounded-full flex items-center gap-1.5 border border-rose-100 dark:border-rose-900/30">
                  <ShieldAlert className="h-3.5 w-3.5" /> Missing
                </span>
              )}
            </div>

            {/* LLM Connection */}
            <div className="flex flex-col gap-3 p-3.5 bg-zinc-50 dark:bg-[#09090b]/50 border border-zinc-200 dark:border-zinc-800 rounded-xl">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Cpu className="h-5 w-5 text-purple-500" />
                  <div>
                    <span className="font-semibold text-sm text-zinc-900 dark:text-zinc-100 block">LM Studio LLM Server</span>
                    <span className="text-[10px] text-zinc-500 block font-mono">{healthData.llm?.url}</span>
                  </div>
                </div>
                {healthData.llm?.connected ? (
                  <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 dark:bg-emerald-950/20 dark:text-emerald-400 px-2.5 py-0.5 rounded-full flex items-center gap-1.5 border border-emerald-100 dark:border-emerald-900/30">
                    <ShieldCheck className="h-3.5 w-3.5" /> Connected
                  </span>
                ) : (
                  <span className="text-xs font-semibold text-amber-700 bg-amber-50 dark:bg-amber-950/20 dark:text-amber-400 px-2.5 py-0.5 rounded-full flex items-center gap-1.5 border border-amber-100 dark:border-amber-900/30">
                    <ShieldAlert className="h-3.5 w-3.5" /> Offline
                  </span>
                )}
              </div>

              {!healthData.llm?.connected && (
                <div className="bg-amber-50 dark:bg-amber-955/15 border border-amber-200/50 dark:border-amber-900/20 rounded-lg p-3 text-xs text-amber-800 dark:text-amber-400 flex items-start gap-2.5 mt-1">
                  <AlertTriangle className="h-4 w-4 shrink-0 text-amber-600 dark:text-amber-500" />
                  <div>
                    <span className="font-bold block">LLM Connection Issue:</span>
                    Please start LM Studio, load model <code className="bg-white dark:bg-zinc-800 rounded px-1 font-mono text-[10px]">{healthData.llm?.model}</code>, and make sure the developer server is running locally.
                  </div>
                </div>
              )}
            </div>
          </div>
        ) : null}
      </div>

      {/* Database Operations */}
      <div className="bg-white dark:bg-[#0c0c0f] border border-zinc-200 dark:border-zinc-800 rounded-xl p-6 shadow-sm space-y-4">
        <div>
          <h3 className="text-sm font-bold text-zinc-950 dark:text-zinc-50">Database Operations</h3>
          <p className="text-xs text-zinc-500 mt-0.5">Force the vector index pipeline to rebuild and synchronize embeddings with the source JSON file.</p>
        </div>

        {rebuildMsg && (
          <div className={`p-3 rounded-lg text-xs font-semibold border ${
            rebuildMsg.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-900/30 text-emerald-800 dark:text-emerald-350'
              : 'bg-rose-50 dark:bg-rose-955/20 border-rose-200 dark:border-rose-900/30 text-rose-800 dark:text-rose-350'
          }`}>
            {rebuildMsg.text}
          </div>
        )}

        <button
          onClick={handleRebuild}
          disabled={rebuilding || loading || error}
          className="bg-blue-600 hover:bg-blue-700 text-white font-medium text-xs px-4 py-2.5 rounded-lg transition-colors flex items-center gap-2 shadow-sm disabled:opacity-55 disabled:cursor-not-allowed"
        >
          <RefreshCw className={`h-3.5 w-3.5 ${rebuilding ? 'animate-spin' : ''}`} />
          {rebuilding ? 'Rebuilding Chromadb Vector Database...' : 'Rebuild ChromaDB Embeddings'}
        </button>
      </div>
    </div>
  );
}

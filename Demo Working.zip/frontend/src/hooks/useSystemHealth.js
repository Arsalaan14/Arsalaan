import { useState, useEffect, useCallback } from 'react';
import { fetchSystemHealth } from '../utils/api';

/**
 * Custom hook for fetching system health status.
 * Preserves exact API contract with GET /api/health.
 */
export default function useSystemHealth() {
  const [health, setHealth] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchSystemHealth();
      setHealth(data);
    } catch (err) {
      console.error(err);
      setError(err.message || 'Could not fetch system health.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { health, loading, error, refetch: load };
}

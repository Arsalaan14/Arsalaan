import { useState, useEffect, useCallback } from 'react';
import { fetchPatients } from '../utils/api';

/**
 * Custom hook for fetching and managing the patient list.
 * Preserves exact API contract with GET /api/patients.
 */
export default function usePatients() {
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async (search = '', condition = '') => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchPatients(search, condition);
      setPatients(data);
    } catch (err) {
      console.error(err);
      setError(err.message || 'Could not connect to the API. Make sure the backend server is running on http://127.0.0.1:5000');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { patients, loading, error, refetch: load };
}

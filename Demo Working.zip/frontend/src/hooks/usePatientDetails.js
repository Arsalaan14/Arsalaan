import { useState, useEffect, useCallback } from 'react';
import { fetchPatientById } from '../utils/api';

/**
 * Custom hook for fetching single patient details.
 * Preserves exact API contract with GET /api/patients/:id.
 */
export default function usePatientDetails(patientId) {
  const [patient, setPatient] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    if (!patientId) {
      setPatient(null);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const data = await fetchPatientById(patientId);
      setPatient(data);
    } catch (err) {
      console.error(err);
      setError(err.message || 'Failed to fetch patient details');
    } finally {
      setLoading(false);
    }
  }, [patientId]);

  useEffect(() => {
    load();
  }, [load]);

  return { patient, loading, error, refetch: load };
}

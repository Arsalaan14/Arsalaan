# Tests

Run:

```bash
pytest -q
```

The security/query tests do not require an LLM. Full RAG tests require the embedding dependencies and an initialized vector index.

import os
os.environ["JWT_SECRET"]="test-secret"
from backend.auth import authenticate, require_auth, redact_patient_data

def test_demo_login_and_jwt():
    result = authenticate("provider", "Provider@123")
    assert result and result["user"]["role"] == "provider"
    claims = require_auth({"Authorization": "Bearer " + result["access_token"]})
    assert claims["role"] == "provider"

def test_patient_identity_is_bound_to_token():
    result = authenticate("patient9", "Patient@123")
    claims = require_auth({"Authorization": "Bearer " + result["access_token"]})
    assert claims["role"] == "patient"
    assert claims["patient_id"] == "P009"

def test_insurer_redaction():
    record = {"patient_id":"P001","name":"A","contact":{"phone":"123","email":"a@b.com"},"address":"secret"}
    masked = redact_patient_data(record, "insurer")
    assert masked["name"] == "Patient P001"
    assert masked["contact"]["phone"].startswith("[REDACTED")
    assert masked["address"].startswith("[REDACTED")

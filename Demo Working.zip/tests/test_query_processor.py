from retrieval.query_processor import process_query, extract_filters

def test_query_normalization():
    assert process_query("  HbA1c   above 7% \n") == "HbA1c above 7%"

def test_structured_filters():
    f = extract_filters("Show P009 with diabetes taking metformin and HbA1c above 7%")
    assert f["patient_id"] == "P009"
    assert "Diabetes" in f["conditions"]
    assert "Metformin" in f["medications"]
    assert f["labs"][0]["field"] == "hba1c"
    assert f["labs"][0]["op"] == ">"

def test_patient_id_normalization():
    assert extract_filters("Patient 5 medications")["patient_id"] == "P005"

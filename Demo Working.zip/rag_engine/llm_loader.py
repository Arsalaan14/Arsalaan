"""LLM adapters for MediQueryNow."""
import json, logging, os, urllib.request
import boto3
from botocore.exceptions import BotoCoreError, ClientError
import config
logger = logging.getLogger(__name__)

class BedrockClient:
    def __init__(self, model_id=None, region_name=None):
        self.model_id = model_id or config.BEDROCK_MODEL_ID
        self.client = boto3.client("bedrock-runtime", region_name=region_name or config.AWS_REGION)
    def __call__(self, prompt, max_new_tokens=config.MAX_NEW_TOKENS, temperature=config.TEMPERATURE, top_p=config.TOP_P, return_full_text=False):
        payload = {"prompt": "<|begin_of_text|><|start_header_id|>user<|end_header_id|>\n\n"+prompt+"<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n",
                   "max_gen_len": max_new_tokens, "temperature": temperature, "top_p": top_p}
        try:
            r = self.client.invoke_model(modelId=self.model_id, contentType="application/json", accept="application/json", body=json.dumps(payload))
            body=json.loads(r["body"].read().decode())
            return [{"generated_text": body["generation"].strip()}]
        except (ClientError, BotoCoreError, KeyError, json.JSONDecodeError) as e:
            raise RuntimeError(f"Bedrock generation failed: {e}") from e

class LMStudioClient:
    def __init__(self, base_url=None, model=None):
        self.base_url=(base_url or config.LM_STUDIO_BASE_URL).rstrip("/")
        self.model=model or config.LM_STUDIO_MODEL_NAME
    def __call__(self, prompt, max_new_tokens=config.MAX_NEW_TOKENS, temperature=config.TEMPERATURE, top_p=config.TOP_P, return_full_text=False):
        payload={"model":self.model,"messages":[{"role":"user","content":prompt}],
                 "max_tokens":max_new_tokens,"temperature":temperature,"top_p":top_p}
        req=urllib.request.Request(self.base_url+"/chat/completions", data=json.dumps(payload).encode(),
                                   headers={"Content-Type":"application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                body=json.loads(r.read().decode())
            return [{"generated_text": body["choices"][0]["message"]["content"].strip()}]
        except Exception as e:
            raise RuntimeError(f"LM Studio generation failed: {e}") from e

class LLMLoader:
    def __init__(self, model_id=None):
        self.provider=config.LLM_PROVIDER
        self.model_id=model_id
        self.pipeline=None
        if self.provider=="bedrock": self.pipeline=BedrockClient(model_id)
        elif self.provider=="lmstudio": self.pipeline=LMStudioClient()
    def get_pipeline(self):
        return self.pipeline

def get_llm(model_id=None):
    return LLMLoader(model_id)

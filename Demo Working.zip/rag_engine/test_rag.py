import logging
import sys
import os

# Ensure the root project directory is in the path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from rag_engine.rag_pipeline import RAGPipeline

# Configure logging for the test execution
logging.basicConfig(
    level=logging.INFO, 
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

def main():
    queries = [
        "Who has HbA1c above 7%?",
        "Show cardiac patients.",
        "Summarize Patient P009.",
        "What medications is Patient 5 taking?",
        "Which patients are taking Metformin?",
        "Show all diabetic patients."
    ]
    
    print("\n" + "*"*80)
    print("INITIALIZING RAG PIPELINE")
    print("This will load the LLM into memory, which may take some time...")
    print("*"*80)
    
    # Initialize pipeline with top_k=3 to keep context concise for tests
    try:
        pipeline = RAGPipeline(top_k=3)
        
        for q in queries:
            print("\n" + "="*80)
            print(f"QUERY: '{q}'")
            print("-" * 80)
            
            response_dict = pipeline.run(q)
            
            print("\nRESPONSE:\n")
            print(response_dict["answer"])
            print("="*80)
            
    except Exception as e:
        print(f"\nFailed to run RAG tests. Ensure LM Studio is running and the configured model name matches a loaded local model. Error: {e}")

if __name__ == "__main__":
    main()

import logging
import time
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import TOP_K_RETRIEVAL

from retrieval.query_processor import process_query
from retrieval.retriever import get_retriever
from retrieval.retrieval_utils import build_context
from rag_engine.response_generator import ResponseGenerator

logger = logging.getLogger(__name__)

class RAGPipeline:
    """
    Orchestrates the entire Retrieval-Augmented Generation flow.
    Query -> Retriever -> Context Builder -> Prompt Builder -> LLM -> Final Answer
    """
    def __init__(self, top_k: int = TOP_K_RETRIEVAL, model_id: str = None):
        logger.info("Initializing complete RAG Pipeline...")
        self.default_top_k = top_k
        self.retriever = get_retriever(top_k=top_k)
        
        # If model_id not provided, the ResponseGenerator will use config.py default
        if model_id:
            self.generator = ResponseGenerator(model_id=model_id)
        else:
            self.generator = ResponseGenerator()
            
        self.history = []

    def _get_dynamic_top_k(self, query: str) -> int:
        lower_q = query.lower()
        if "all" in lower_q:
            return 10
        elif "summarize patient" in lower_q:
            return 1
        return self.default_top_k

    def run(self, raw_query: str, role: str = "provider", auth_patient_id: str | None = None) -> dict:
        """
        Executes the RAG pipeline end-to-end and returns a dict with response and diagnostics.
        """
        logger.info(f"Starting pipeline for query: '{raw_query}' (role={role}, auth_id={auth_patient_id})")
        
        # 1. Process Query
        query = process_query(raw_query)
        
        # Determine dynamic Top-K
        k = self._get_dynamic_top_k(query)
        
        # 2. Retrieve Documents
        t0 = time.perf_counter()
        results = self.retriever.retrieve_documents(query, top_k=k, role=role, auth_patient_id=auth_patient_id)
        retrieval_time = time.perf_counter() - t0
        
        # Extract doc IDs for diagnostics and source references
        doc_ids = results.get('ids', [[]])[0]
        metadatas = results.get('metadatas', [[]])[0]
        
        # Build Source References
        sources = []
        for i, meta in enumerate(metadatas):
            if meta:
                pid = meta.get('patient_id', 'Unknown')
                sources.append(f"Patient ID {pid}")
        
        source_text = "\n\nSources:\n" + "\n".join(set(sources)) if sources else ""
        
        # 3. Build Context (Source Grounding)
        context = build_context(results)
        
        # 4. Check retrieval confidence / empty context
        if not context or "No relevant patient records found" in context:
            logger.warning("No context retrieved. Bypassing LLM generation.")
            final_answer = "The requested information is not available in the retrieved patient records.\n\n# Clinical Disclaimer\nThis response is generated from retrieved patient records and is intended for informational purposes only. Clinical decisions should be made by qualified healthcare professionals."
            generation_time = 0.0
        else:
            # 5. Generate Response
            t1 = time.perf_counter()
            final_answer = self.generator.generate(query, context, role=role)
            generation_time = time.perf_counter() - t1
            
            # Append Source References
            final_answer += source_text

        # Update History
        self.history.append((raw_query, final_answer))

        return {
            "answer": final_answer,
            "retrieved_docs": len(doc_ids),
            "doc_ids": doc_ids,
            "retrieval_time": retrieval_time,
            "generation_time": generation_time
        }


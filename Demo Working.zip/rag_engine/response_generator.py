import logging
import os
import sys
import re

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import BEDROCK_MODEL_ID
from rag_engine.llm_loader import get_llm
from rag_engine.prompt_builder import build_prompt

logger = logging.getLogger(__name__)

class ResponseGenerator:
    """
    Handles generating responses from the LLM (AWS Bedrock) based on prompts,
    and applies post-processing / safety guardrails.
    """
    def __init__(self, model_id: str = BEDROCK_MODEL_ID):
        self.llm = get_llm(model_id)
        self.pipeline = self.llm.get_pipeline()

    def generate(self, query: str, context: str, role: str = "provider") -> str:
        """
        Generate an answer, clean the output, and format sections.
        """
        prompt = build_prompt(query, context, role=role)
        logger.info(f"Generating response from LLM for role: {role}...")
        
        try:
            outputs = self.pipeline(
                prompt,
                max_new_tokens=4096,
                temperature=0.1,
                top_p=0.9,
                return_full_text=False # Only return the newly generated tokens
            )
            
            response_text = outputs[0]['generated_text'].strip()
            return self._post_process(response_text)
            
        except Exception as e:
            logger.error(f"Error during response generation: {e}. Falling back to rule-based engine.")
            return self._generate_fallback_response(query, context, str(e), role=role)

    def _generate_fallback_response(self, query: str, context: str, error_msg: str, role: str = "provider") -> str:
        """
        Parse context to extract patient information and build a meaningful response offline.
        """
        # Parse patients out of the context
        records = re.split(r'--- Record \d+.*? ---\n', context)
        patients = []
        
        def clean_val(val_str: str) -> str:
            """Strips citation brackets for narrative usage."""
            return re.sub(r'\s*\[.*?\]', '', val_str).strip()

        for record in records:
            if not record.strip():
                continue
            
            p_data = {}
            # Regex extracts (value [+ citation path in brackets])
            pid_match = re.search(r'Patient ID:\s*([^\n]+)', record)
            name_match = re.search(r'Name:\s*([^\n]+)', record)
            age_match = re.search(r'Age:\s*([^\n]+)', record)
            gender_match = re.search(r'Gender:\s*([^\n]+)', record)
            blood_match = re.search(r'Blood Group:\s*([^\n]+)', record)
            phone_match = re.search(r'Phone:\s*([^\n]+)', record)
            email_match = re.search(r'Email:\s*([^\n]+)', record)
            address_match = re.search(r'Address:\s*([^\n]+)', record)
            
            if not pid_match:
                continue
                
            p_data['patient_id'] = pid_match.group(1).strip()
            p_data['name'] = name_match.group(1).strip() if name_match else "Unknown"
            p_data['age'] = age_match.group(1).strip() if age_match else "N/A"
            p_data['gender'] = gender_match.group(1).strip() if gender_match else "N/A"
            p_data['blood_group'] = blood_match.group(1).strip() if blood_match else "N/A"
            p_data['phone'] = phone_match.group(1).strip() if phone_match else "Not Available"
            p_data['email'] = email_match.group(1).strip() if email_match else "Not Available"
            p_data['address'] = address_match.group(1).strip() if address_match else "Not Available"
            
            # Value versions without citations for raw computations
            p_data['patient_id_val'] = clean_val(p_data['patient_id'])
            p_data['name_val'] = clean_val(p_data['name'])
            
            # Conditions
            cond_match = re.search(r'Conditions:\s*([^\n]+)', record)
            p_data['conditions'] = [c.strip() for c in cond_match.group(1).split(',')] if cond_match else []
            
            # Medications list
            meds = []
            med_section = re.search(r'Medications:\n((?:\s*-\s*[^\n]+\n*)+)', record)
            if med_section:
                for line in med_section.group(1).strip().split('\n'):
                    meds.append(line.replace('-', '').strip())
            p_data['medications'] = meds
            
            # Lab reports list
            labs = []
            lab_section = re.search(r'Lab Reports:\n((?:\s*-\s*[^\n]+\n*)+)', record)
            if lab_section:
                for line in lab_section.group(1).strip().split('\n'):
                    labs.append(line.replace('-', '').strip())
            p_data['lab_reports'] = labs
            
            # Visits list
            visits = []
            visit_section = re.search(r'Doctor Visits:\n((?:\s*-\s*[^\n]+\n*)+)', record)
            if visit_section:
                for line in visit_section.group(1).strip().split('\n'):
                    visits.append(line.replace('-', '').strip())
            p_data['visits'] = visits
            
            patients.append(p_data)
            
        # Build answer based on query type
        lower_q = query.lower()
        answer = ""
        
        # Heading Warning
        answer += "# SYSTEM STATUS: OFFLINE MODE\n"
        answer += f"> [!NOTE]\n"
        answer += f"> **Offline Clinical Retrieval Mode (Role: {role.upper()})** - Local inference server is offline. Serving facts directly from indexing data with provenance mappings.\n\n"

        if not patients:
            answer += "No relevant patient records were found in the database matching your query."
            return self._post_process(answer)
            
        # Enforce Insurer redaction on patients dict
        if role == "insurer":
            for p in patients:
                # Mask identities and contact parameters
                p['name'] = f"Patient {p['patient_id_val']} [patients.name redacted]"
                p['phone'] = "[REDACTED FOR INSURER]"
                p['email'] = "[REDACTED FOR INSURER]"
                p['address'] = "[REDACTED FOR INSURER]"
                p['name_val'] = f"Patient {p['patient_id_val']}"

        # 1. Specific Patient Query (e.g. P001, Patient 1)
        patient_target = None
        for p in patients:
            if p['patient_id_val'].lower() in lower_q or p['name_val'].lower() in lower_q:
                patient_target = p
                break
                
        if patient_target:
            p = patient_target
            conds_raw = [clean_val(c) for c in p['conditions']]
            meds_raw = [clean_val(m) for m in p['medications']]
            
            conds_str = ", ".join(conds_raw) if conds_raw else "no active chronic conditions"
            meds_str = ", ".join(meds_raw) if meds_raw else "no active medications"
            
            p_name = p['name_val']
            p_age = clean_val(p['age'])
            p_gender = clean_val(p['gender'])
            
            if role == "patient":
                # Translate patient terminology
                narrative = f"You ({p_name}) are a {p_age}-year-old {p_gender.lower()} with active conditions including {conds_str.replace('hypertension', 'high blood pressure')}. Your current prescription list includes {meds_str}."
            else:
                narrative = f"Patient {p_name} ({p['patient_id']}) is a {p_age}-year-old {p_gender} with a history of {conds_str}, currently managed with {meds_str}."
            
            answer += f"{narrative}\n\n"
            answer += f"# Patient Profile\n"
            answer += f"- Patient ID: {p['patient_id']}\n"
            answer += f"- Name: {p['name']}\n"
            answer += f"- Gender: {p['gender']}\n"
            answer += f"- Age: {p['age']}\n"
            answer += f"- Date of Birth: Not Available\n"
            answer += f"- Blood Group: {p['blood_group']}\n"
            answer += f"- Contact: Email: {p['email']}, Phone: {p['phone']}\n"
            answer += f"- Primary Physician: Not Available\n\n"
            
            answer += "# Clinical Conditions & Allergies\n"
            if p['conditions']:
                answer += f"- Active Conditions: {', '.join(p['conditions'])}\n"
            else:
                answer += "- Active Conditions: None Recorded\n"
            answer += "- Allergies & Reactions: No Known Allergies Recorded\n\n"
                
            answer += "# Current Medication Regimen\n"
            if p['medications']:
                for med in p['medications']:
                    answer += f"- {med}\n"
                answer += "\n"
            else:
                answer += "None Recorded\n\n"
                
            answer += "# Lab Investigations & Vitals\n"
            if p['lab_reports']:
                for lab in p['lab_reports']:
                    answer += f"- Lab Results: {lab}\n"
            else:
                answer += "- Lab Results: None Recorded\n"
            answer += "- Vital Signs: None Recorded\n\n"
                
            answer += "# Clinical Encounters & Timeline\n"
            if p['visits']:
                for visit in p['visits']:
                    answer += f"- {visit}\n"
            else:
                answer += "None Recorded\n\n"

            answer += "# Data Quality & Missing Fields\n"
            answer += "- Date of Birth not available\n"
            if role == "insurer":
                answer += "- Contact details masked under Insurer policy rules\n"
            else:
                answer += "- Vital signs not recorded\n"

        # 2. Condition-based queries (e.g. diabetes, hypertension, cardiac)
        elif any(term in lower_q for term in ['diabetes', 'diabetic', 'hypertension', 'asthma', 'cardiac', 'heart', 'coronary']):
            target_cond = ""
            for term in ['diabetes', 'hypertension', 'asthma', 'coronary']:
                if term in lower_q:
                    target_cond = term
                    break
            
            matched_patients = []
            for p in patients:
                for c in p['conditions']:
                    c_clean = clean_val(c).lower()
                    if target_cond in c_clean or (target_cond == 'coronary' and 'cardiac' in c_clean):
                        matched_patients.append(p)
                        break
                        
            answer += f"# Clinical Conditions & Allergies\n"
            if matched_patients:
                label = target_cond.capitalize()
                if role == "patient":
                     label = label.replace("Hypertension", "High Blood Pressure")
                answer += f"Found **{len(matched_patients)}** patient(s) with matching condition '{label}' in the offline database context:\n\n"
                for p in matched_patients:
                    p_gender = clean_val(p['gender'])
                    p_age = clean_val(p['age'])
                    answer += f"### {p['name']} ({p['patient_id']})\n"
                    answer += f"- **Age/Gender:** {p_age} yrs, {p_gender}\n"
                    answer += f"- **Conditions:** {', '.join(p['conditions'])}\n"
                    if p['medications']:
                        answer += f"- **Medications:** {', '.join(p['medications'])}\n"
                    if p['lab_reports']:
                        relevant_labs = [l for l in p['lab_reports'] if 'hba1c' in l.lower() or 'pressure' in l.lower() or 'bp' in l.lower()]
                        if relevant_labs:
                            answer += f"- **Relevant Labs:** {'; '.join(relevant_labs)}\n"
                    answer += "\n"
            else:
                answer += f"No patients with **{target_cond}** were found in the retrieved documents."

        # 3. Lab value specific query (e.g. hba1c)
        elif 'hba1c' in lower_q:
            answer += "# Lab Investigations & Vitals\n"
            answer += "Retrieved Patient records containing HbA1c lab values:\n\n"
            
            found = False
            for p in patients:
                hba1c_reports = [r for r in p['lab_reports'] if 'hba1c' in r.lower()]
                if hba1c_reports:
                    found = True
                    p_gender = clean_val(p['gender'])
                    p_age = clean_val(p['age'])
                    answer += f"### {p['name']} ({p['patient_id']})\n"
                    answer += f"- **Age/Gender:** {p_age} yrs, {p_gender}\n"
                    for rep in hba1c_reports:
                        answer += f"- **HbA1c Value:** {rep}\n"
                    answer += "\n"
            if not found:
                answer += "No HbA1c records found in the retrieved patient profiles."
                
        # 4. Fallback Table Summary
        else:
            answer += "# Patient Profile\n"
            answer += "Here is a summary of the retrieved records from ChromaDB:\n\n"
            answer += "| Patient ID | Name | Age/Gender | Conditions | Key Medications |\n"
            answer += "|---|---|---|---|---|\n"
            for p in patients:
                conds = ", ".join(p['conditions']) if p['conditions'] else "None"
                med_names = [clean_val(m).split()[0] for m in p['medications']]
                meds = ", ".join(med_names[:2]) if med_names else "None"
                
                gender_str = clean_val(p['gender'])
                g_char = gender_str[0] if gender_str else "?"
                p_age = clean_val(p['age'])
                answer += f"| {p['patient_id']} | {p['name']} | {p_age}/{g_char} | {conds} | {meds} |\n"
            
            answer += "\n# Clinical Encounters & Timeline\n"
            for p in patients:
                p_age = clean_val(p['age'])
                p_gender = clean_val(p['gender'])
                p_blood = clean_val(p['blood_group'])
                conds = ", ".join(p['conditions']) if p['conditions'] else "None"
                answer += f"- **{p['name']} ({p['patient_id']}):** {p_age}y {p_gender}, blood group {p_blood}. Active conditions: {conds}.\n"

        return self._post_process(answer)

    def _post_process(self, text: str) -> str:
        """
        Clean output and ensure required structured sections are present (Hallucination/Safety net).
        """
        # Strip LLM thinking block (commonly enclosed in <think>...</think> by reasoning models)
        text = re.sub(r'<think>.*?</think>', '', text, flags=re.DOTALL)
        text = re.sub(r'<think>.*$', '', text, flags=re.DOTALL).strip()

        # Ensure disclaimer is present
        disclaimer_text = "This response is generated from retrieved patient records and is intended for informational purposes only. Clinical decisions, diagnoses, and treatment recommendations should be made by qualified healthcare professionals."
        
        if "SECTION 6" not in text and "Disclaimer" not in text and disclaimer_text not in text:
            text += f"\n\n# Clinical Disclaimer\n\n{disclaimer_text}"
            
        return text

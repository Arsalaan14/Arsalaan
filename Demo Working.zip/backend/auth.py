"""Authentication, authorization, redaction and audit logging."""
import copy, datetime, json, logging, os
from threading import Lock
from typing import Dict, Any, List, Tuple, Optional
import jwt
from werkzeug.security import check_password_hash, generate_password_hash
import config

logger = logging.getLogger(__name__)
log_lock = Lock()
AUDIT_LOG_PATH = config.AUDIT_LOG_PATH

PERSONAS = {
    "provider": {"name": "Dr. Olivia", "role": "provider"},
    "patient": {"name": "Patient 9", "role": "patient", "auth_patient_id": "P009"},
    "insurer": {"name": "INS Mutual Agent", "role": "insurer"},
    "admin": {"name": "System Administrator", "role": "admin"},
}
_PASSWORD_HASHES = {
    username: generate_password_hash(info["password"])
    for username, info in config.DEMO_USERS.items()
}

def authenticate(username: str, password: str) -> Optional[dict]:
    info = config.DEMO_USERS.get(username)
    if not info or not check_password_hash(_PASSWORD_HASHES[username], password):
        return None
    now = datetime.datetime.now(datetime.timezone.utc)
    payload = {
        "sub": username, "name": info["name"], "role": info["role"],
        "patient_id": info.get("patient_id"), "iat": now,
        "exp": now + datetime.timedelta(hours=config.JWT_EXPIRY_HOURS),
    }
    token = jwt.encode(payload, config.JWT_SECRET, algorithm="HS256")
    return {"access_token": token, "token_type": "Bearer", "user": {
        "username": username, "name": info["name"], "role": info["role"],
        "patient_id": info.get("patient_id")
    }}

def _decode_token(headers) -> Optional[dict]:
    auth_header = headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        return None
    token = auth_header[7:].strip()
    try:
        return jwt.decode(token, config.JWT_SECRET, algorithms=["HS256"])
    except jwt.PyJWTError:
        return None

def get_auth_context(headers: Dict[str, str]) -> Tuple[str, str, Optional[str]]:
    claims = _decode_token(headers)
    if claims:
        return claims.get("name", claims.get("sub", "User")), claims.get("role", "provider"), claims.get("patient_id")
    # Legacy role headers are disabled by default. Enable explicitly only for local debugging.
    if os.getenv("ALLOW_LEGACY_DEMO_HEADERS", "false").lower() != "true":
        return "", "", None
    role = headers.get("X-User-Role", "provider").lower()
    if role not in PERSONAS: role = "provider"
    pid = headers.get("X-Patient-Id") if role == "patient" else None
    return (f"Patient {pid or 'P009'}" if role == "patient" else PERSONAS[role]["name"]), role, (pid or "P009" if role == "patient" else None)

def require_auth(headers) -> Optional[dict]:
    return _decode_token(headers)

def redact_patient_data(patient_dict: Dict[str, Any], role: str) -> Dict[str, Any]:
    if role != "insurer": return patient_dict
    p = copy.deepcopy(patient_dict)
    p["name"] = f"Patient {p.get('patient_id', 'Unknown')}"
    if isinstance(p.get("contact"), dict):
        p["contact"]["phone"] = "[REDACTED FOR INSURER]"
        p["contact"]["email"] = "[REDACTED FOR INSURER]"
    for key in ("phone", "email", "address"):
        if key in p: p[key] = "[REDACTED FOR INSURER]"
    return p

def audit_log_action(user: str, role: str, action: str, details: str,
                     status: str = "SUCCESS", patients_accessed: Optional[List[str]] = None) -> None:
    entry = {
        "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "user": user, "role": role, "action": action, "details": details,
        "status": status, "patients_accessed": patients_accessed or []
    }
    with log_lock:
        logs = []
        os.makedirs(os.path.dirname(AUDIT_LOG_PATH), exist_ok=True)
        if os.path.exists(AUDIT_LOG_PATH):
            try:
                with open(AUDIT_LOG_PATH, encoding="utf8") as f: logs = json.load(f) or []
            except (OSError, json.JSONDecodeError): logs = []
        logs.append(entry)
        with open(AUDIT_LOG_PATH, "w", encoding="utf8") as f:
            json.dump(logs[-5000:], f, indent=2)

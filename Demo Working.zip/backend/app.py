import os
import sys
import logging
import json
from flask import Flask, request, jsonify
from flask_cors import CORS

# Add root folder to sys.path to import config and modules
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.append(ROOT_DIR)

import config
from vector_embedding.embedding_utils import load_patient_data
from vector_embedding.embed_patients import build_embeddings
from backend.auth import get_auth_context, redact_patient_data, audit_log_action, AUDIT_LOG_PATH, authenticate, require_auth

# Initialize Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("backend_api")

app = Flask(__name__)
CORS(app, origins=config.CORS_ORIGINS.split(",") if config.CORS_ORIGINS != "*" else "*")

# Global RAG Pipeline instance
pipeline = None

def get_pipeline():
    global pipeline
    if pipeline is None:
        try:
            logger.info("Initializing RAG Pipeline...")
            from rag_engine.rag_pipeline import RAGPipeline
            pipeline = RAGPipeline()
            # Warm up
            try:
                pipeline.generator.generate("Hello", "Context: None")
            except Exception as wue:
                logger.warning(f"LLM warm-up failed: {wue}")
        except Exception as e:
            logger.error(f"Failed to load RAG Pipeline: {e}")
    return pipeline

@app.route("/api/auth/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or {}
    username, password = str(data.get("username", "")).strip(), str(data.get("password", ""))
    result = authenticate(username, password)
    if not result:
        audit_log_action(username or "anonymous", "unknown", "LOGIN", "Invalid credentials", status="UNAUTHORIZED")
        return jsonify({"error": "Invalid username or password"}), 401
    audit_log_action(username, result["user"]["role"], "LOGIN", "Successful authentication")
    return jsonify(result)

@app.route("/api/auth/me", methods=["GET"])
def me():
    claims = require_auth(request.headers)
    if not claims:
        return jsonify({"error": "Authentication required"}), 401
    return jsonify({"user": {"username": claims.get("sub"), "name": claims.get("name"),
                             "role": claims.get("role"), "patient_id": claims.get("patient_id")}})

def authenticated_context():
    claims = require_auth(request.headers)
    if not claims:
        return None, None, None, jsonify({"error": "Authentication required"}), 401
    return claims.get("name", claims.get("sub", "User")), claims.get("role", "provider"), claims.get("patient_id"), None, None

@app.route("/api/health", methods=["GET"])
def health():
    db_ok = os.path.isdir(config.CHROMA_DB_DIR)
    json_ok = os.path.isfile(config.JSON_DATA_PATH)
    
    llm_ok = config.LLM_PROVIDER == "offline"
    llm_error = None
    if config.LLM_PROVIDER == "lmstudio":
        try:
            import urllib.request
            req = urllib.request.Request(config.LM_STUDIO_BASE_URL.rstrip("/") + "/models")
            with urllib.request.urlopen(req, timeout=3) as response:
                llm_ok = response.status == 200
        except Exception as e:
            llm_error = str(e)
    elif config.LLM_PROVIDER == "bedrock":
        try:
            import boto3
            boto3.client("bedrock-runtime", region_name=config.AWS_REGION)
            llm_ok = True
        except Exception as e:
            llm_error = str(e)

    return jsonify({
        "status": "healthy" if (db_ok and json_ok and llm_ok) else "degraded",
        "database": {
            "exists": db_ok,
            "path": config.CHROMA_DB_DIR
        },
        "dataset": {
            "exists": json_ok,
            "path": config.JSON_DATA_PATH
        },
        "llm": {
            "connected": llm_ok,
            "error": llm_error,
            "provider": config.LLM_PROVIDER,
            "model": (config.BEDROCK_MODEL_ID if config.LLM_PROVIDER == "bedrock" else config.LM_STUDIO_MODEL_NAME)
        }
    })

@app.route("/api/patients", methods=["GET"])
def get_patients():
    user_name, role, auth_pid, auth_error, auth_status = authenticated_context()
    if auth_error:
        return auth_error, auth_status
    try:
        patients = load_patient_data(config.JSON_DATA_PATH)
        search_query = request.args.get("search", "").lower()
        condition_filter = request.args.get("condition", "").lower()
        
        filtered = []
        for p in patients:
            pid = p.get("patient_id", "")
            
            # Enforce Patient Role Boundary
            if role == "patient" and auth_pid and pid != auth_pid:
                continue
                
            name = p.get("name", "")
            conditions = [c.lower() for c in p.get("conditions", [])]
            
            # Filters
            if search_query and (search_query not in name.lower() and search_query not in pid.lower()):
                continue
            if condition_filter and all(condition_filter not in c for c in conditions):
                continue
                
            # Render summarized items (masking check for Insurer)
            p_masked = redact_patient_data(p, role)
            
            filtered.append({
                "patient_id": pid,
                "name": p_masked.get("name"),
                "age": p.get("age"),
                "gender": p.get("gender"),
                "blood_group": p.get("blood_group"),
                "conditions": p.get("conditions", [])
            })
            
        # Log action to audit logs
        p_ids = [item["patient_id"] for item in filtered]
        audit_log_action(
            user=user_name,
            role=role,
            action="LIST_PATIENTS",
            details=f"Retrieved list of patient summary profiles (Search='{search_query}', Condition='{condition_filter}')",
            patients_accessed=p_ids
        )
        return jsonify(filtered)
    except Exception as e:
        logger.error(f"Error loading patients: {e}")
        audit_log_action(
            user=user_name,
            role=role,
            action="LIST_PATIENTS",
            details=f"Failed to retrieve list of patients: {str(e)}",
            status="ERROR"
        )
        return jsonify({"error": str(e)}), 500

@app.route("/api/patients/<patient_id>", methods=["GET"])
def get_patient_details(patient_id):
    user_name, role, auth_pid, auth_error, auth_status = authenticated_context()
    if auth_error:
        return auth_error, auth_status
    try:
        # Strip 'doc_' prefix if present
        if patient_id.startswith("doc_"):
            patient_id = patient_id[4:]
            
        # Enforce patient role boundary
        if role == "patient" and auth_pid and patient_id != auth_pid:
            audit_log_action(
                user=user_name,
                role=role,
                action="VIEW_PATIENT_DETAILS",
                details=f"Unauthorized attempt to access details of patient ID: {patient_id}",
                status="UNAUTHORIZED",
                patients_accessed=[patient_id]
            )
            return jsonify({"error": "Forbidden: You are not authorized to view this patient record."}), 403
            
        patients = load_patient_data(config.JSON_DATA_PATH)
        for p in patients:
            if p.get("patient_id") == patient_id:
                p_redacted = redact_patient_data(p, role)
                audit_log_action(
                    user=user_name,
                    role=role,
                    action="VIEW_PATIENT_DETAILS",
                    details=f"Successfully viewed clinical details of patient ID: {patient_id}",
                    patients_accessed=[patient_id]
                )
                return jsonify(p_redacted)
                
        audit_log_action(
            user=user_name,
            role=role,
            action="VIEW_PATIENT_DETAILS",
            details=f"Attempted to view patient ID {patient_id} but record was not found.",
            status="ERROR"
        )
        return jsonify({"error": "Patient not found"}), 404
        
    except Exception as e:
        logger.error(f"Error getting patient detail: {e}")
        audit_log_action(
            user=user_name,
            role=role,
            action="VIEW_PATIENT_DETAILS",
            details=f"Failed to view patient details for ID {patient_id}: {str(e)}",
            status="ERROR" if role != "patient" else "UNAUTHORIZED"
        )
        return jsonify({"error": str(e)}), 500

@app.route("/api/query", methods=["POST"])
def query_rag():
    user_name, role, auth_pid, auth_error, auth_status = authenticated_context()
    if auth_error:
        return auth_error, auth_status
    data = request.json or {}
    query_text = data.get("query", "").strip()
    
    if not query_text:
        return jsonify({"error": "Query cannot be empty"}), 400
        
    p = get_pipeline()
    if p is None:
        audit_log_action(
            user=user_name,
            role=role,
            action="QUERY_PATIENTS",
            details=f"RAG search execution failed to initialize: pipeline offline. User query: '{query_text}'",
            status="ERROR"
        )
        return jsonify({
            "answer": "The RAG pipeline failed to initialize. Please check if the local LM Studio server is running and configured correctly.",
            "retrieved_docs": 0,
            "doc_ids": [],
            "retrieval_time": 0.0,
            "generation_time": 0.0,
            "error": "Pipeline initialization failed"
        }), 503
        
    try:
        result = p.run(query_text, role=role, auth_patient_id=auth_pid)
        
        # Parse patient IDs accessed from result
        doc_ids = result.get("doc_ids", [])
        accessed_pids = [d.replace("doc_", "") for d in doc_ids]
        
        audit_log_action(
            user=user_name,
            role=role,
            action="QUERY_PATIENTS",
            details=f"Submitted natural-language query: '{query_text}'",
            status="SUCCESS",
            patients_accessed=accessed_pids
        )
        return jsonify(result)
    except Exception as e:
        logger.error(f"Error processing query: {e}")
        audit_log_action(
            user=user_name,
            role=role,
            action="QUERY_PATIENTS",
            details=f"Query failed to execute: {str(e)}. User query: '{query_text}'",
            status="ERROR"
        )
        return jsonify({"error": str(e)}), 500

@app.route("/api/rebuild-embeddings", methods=["POST"])
def rebuild():
    user_name, role, auth_pid, auth_error, auth_status = authenticated_context()
    if auth_error:
        return auth_error, auth_status
    # Only allow Admin and Provider roles to rebuild index
    if role not in ["admin", "provider"]:
        audit_log_action(
            user=user_name,
            role=role,
            action="REBUILD_INDEX",
            details="Unauthorized attempt to rebuild database embedding index",
            status="UNAUTHORIZED"
        )
        return jsonify({"error": "Forbidden: You are not authorized to rebuild embeddings."}), 403
        
    try:
        logger.info("Rebuilding embeddings...")
        build_embeddings(config.JSON_DATA_PATH, config.CHROMA_DB_DIR)
        audit_log_action(
            user=user_name,
            role=role,
            action="REBUILD_INDEX",
            details="Database embedding indices successfully rebuilt from raw json source."
        )
        return jsonify({"message": "Embeddings rebuilt successfully"})
    except Exception as e:
        logger.error(f"Error rebuilding embeddings: {e}")
        audit_log_action(
            user=user_name,
            role=role,
            action="REBUILD_INDEX",
            details=f"Failed to rebuild embedding database: {str(e)}",
            status="ERROR"
        )
        return jsonify({"error": str(e)}), 500

@app.route("/api/audit-logs", methods=["GET"])
def get_audit_logs():
    user_name, role, auth_pid, auth_error, auth_status = authenticated_context()
    if auth_error:
        return auth_error, auth_status
    # Only Admin role can access system audit trail logs
    if role != "admin":
        audit_log_action(
            user=user_name,
            role=role,
            action="VIEW_AUDIT_LOGS",
            details="Unauthorized attempt to retrieve system audit logs",
            status="UNAUTHORIZED"
        )
        return jsonify({"error": "Forbidden: Only administrators can view audit logs."}), 403
        
    try:
        logs = []
        if os.path.exists(AUDIT_LOG_PATH):
            with open(AUDIT_LOG_PATH, "r", encoding="utf-8") as f:
                content = f.read().strip()
                if content:
                    logs = json.loads(content)
                    
        # Log the success access
        audit_log_action(
            user=user_name,
            role=role,
            action="VIEW_AUDIT_LOGS",
            details=f"Successfully extracted {len(logs)} audit trail trace entries"
        )
        return jsonify(logs)
    except Exception as e:
        logger.error(f"Error fetching audit logs: {e}")
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    # Check if embeddings database exists; if not, build it.
    if not os.path.isdir(config.CHROMA_DB_DIR):
        logger.info("ChromaDB directory not found. Building embeddings...")
        try:
            build_embeddings(config.JSON_DATA_PATH, config.CHROMA_DB_DIR)
        except Exception as e:
            logger.error(f"Auto-building embeddings failed: {e}")
            
    port = int(os.getenv("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=False)

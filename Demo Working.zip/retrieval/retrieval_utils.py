import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)

def build_context(results: Dict[str, Any]) -> str:
    """
    Format retrieved documents and metadata into a single context string
    suitable for injection into an LLM prompt.
    
    Args:
        results (Dict[str, Any]): The raw results dictionary from ChromaDB.
        
    Returns:
        str: A formatted string containing the retrieved context.
    """
    if not results or not results.get('ids') or not results['ids'][0]:
        logger.warning("No results provided to build_context.")
        return "No relevant patient records found."

    context_parts = []
    
    # Results from ChromaDB are nested lists (outer list per query)
    documents = results['documents'][0]
    metadatas = results['metadatas'][0]
    distances = results['distances'][0]
    
    for i in range(len(documents)):
        doc = documents[i]
        meta = metadatas[i]
        dist = distances[i]
        
        # Calculate a pseudo relevance score (lower distance = higher relevance)
        # Assuming L2 distance or cosine distance, smaller is better.
        # We display the distance directly for clarity in testing.
        
        part = f"--- Record {i+1} (Distance: {dist:.4f}) ---\n"
        part += f"Metadata: [Patient ID: {meta.get('patient_id', 'N/A')} | Name: {meta.get('patient_name', 'N/A')} | Age: {meta.get('age', 'N/A')} | Gender: {meta.get('gender', 'N/A')}]\n"
        part += f"Details:\n{doc}\n"
        
        context_parts.append(part)
        
    context = "\n".join(context_parts)
    logger.debug(f"Successfully built context from {len(documents)} retrieved documents.")
    
    return context

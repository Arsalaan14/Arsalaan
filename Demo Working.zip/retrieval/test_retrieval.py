import logging
import sys
import os

# Ensure the root project directory is in the path so imports work correctly
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from retrieval.query_processor import process_query
from retrieval.retriever import get_retriever
from retrieval.retrieval_utils import build_context

# Configure logging for the test execution
logging.basicConfig(
    level=logging.INFO, 
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

def main():
    queries = [
        "What medications is Patient 4 taking?",
        "Which patient has diabetes?",
        "Show patients taking Metformin.",
        "Who has HbA1c above 7%?",
        "Show cardiac patients."
    ]
    
    print("\n" + "*"*80)
    print("INITIALIZING RETRIEVAL MODULE")
    print("*"*80)
    
    # Initialize retriever to fetch top 3 results for testing
    retriever = get_retriever(top_k=3)
    
    for q in queries:
        print("\n" + "="*80)
        print(f"Original Query: '{q}'")
        
        # 1. Process Query
        processed_q = process_query(q)
        print(f"Processed Query: '{processed_q}'")
        
        # 2. Retrieve Documents
        print("Retrieving documents...")
        results = retriever.retrieve_documents(query=processed_q)
        
        # 3. Build Context
        context = build_context(results)
        
        print("\n=== Retrieved Context ===")
        print(context)
        print("=========================")

if __name__ == "__main__":
    main()

import logging
import sys
import os
import json
from typing import Dict, Any, Optional

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from vector_embedding.embedding_utils import load_vector_db, get_embedding_model
from config import TOP_K_RETRIEVAL, JSON_DATA_PATH, NORMALIZED_DATA_PATH

logger = logging.getLogger(__name__)

class PatientRetriever:
    """
    Handles connection to ChromaDB and performs hybrid searches (exact filtering + semantic matching) for patient records.
    """
    def __init__(self, top_k: int = TOP_K_RETRIEVAL):
        """
        Initialize the retriever with a default top_k value.
        Loads the ChromaDB collection and the embedding model.
        """
        self.top_k = top_k
        try:
            self.collection = load_vector_db()
            self.model = get_embedding_model()
            logger.info("PatientRetriever initialized successfully.")
        except Exception as e:
            logger.error(f"Failed to initialize PatientRetriever: {e}")
            raise

    def retrieve_documents(self, query: str, top_k: Optional[int] = None, role: str = "provider", auth_patient_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Retrieves the most relevant patient records for a given query, supporting roles and hybrid constraints.
        
        Args:
            query (str): The processed query string.
            top_k (int, optional): Number of documents to retrieve. Overrides default if provided.
            role (str): Active user role: provider, patient, insurer, admin.
            auth_patient_id (str, optional): Enforced target patient ID for patient role.
            
        Returns:
            Dict[str, Any]: Results from ChromaDB including documents, metadatas, and distances.
        """
        k = top_k if top_k is not None else self.top_k
        logger.info(f"Retrieving top {k} documents for query '{query}' (role={role}, auth_id={auth_patient_id})")
        
        from retrieval.query_processor import extract_filters
        filters = extract_filters(query)
        
        # Enforce patient role constraint
        if role == "patient" and auth_patient_id:
            filters["patient_id"] = auth_patient_id
            
        # 1. Calculate matching IDs based on exact filters if present
        matched_ids = []
        has_active_filters = any(filters.values())
        
        if has_active_filters:
            patients = []
            normalized_path = str(NORMALIZED_DATA_PATH)
            try:
                if not os.path.exists(normalized_path):
                    from vector_embedding.normalization import normalize_dataset
                    normalize_dataset(str(JSON_DATA_PATH), normalized_path)
                with open(normalized_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                patients = data.get("patients", [])
            except Exception as e:
                logger.error(f"Failed to load normalized JSON in retriever: {e}")
            
            for p in patients:
                if self._patient_matches_filters(p, filters):
                    matched_ids.append(f"doc_{p['patient']['patient_id']['value']}")
                    
        # 2. Query DB
        final_ids = []
        final_docs = []
        final_metas = []
        final_dists = []
        
        if matched_ids:
            try:
                fetched = self.collection.get(
                    ids=matched_ids,
                    include=["documents", "metadatas"]
                )
                if fetched and fetched.get("ids"):
                    ids_list = fetched["ids"]
                    docs_list = fetched["documents"]
                    metas_list = fetched["metadatas"]
                    dists_list = [0.0] * len(ids_list) # 0.0 is perfect constraint match
                    
                    final_ids.extend(ids_list)
                    final_docs.extend(docs_list)
                    final_metas.extend(metas_list)
                    final_dists.extend(dists_list)
            except Exception as e:
                logger.error(f"Error fetching exact matches: {e}")
                
        # Semantic search if needed to fill top_k
        if len(final_ids) < k:
            semantic_k = k - len(final_ids)
            try:
                query_embedding = self.model.encode([query])[0].tolist()
                
                # Apply metadata filter for patient_id if present
                where_filter = None
                if role == "patient" and auth_patient_id:
                    where_filter = {"patient_id": auth_patient_id}
                elif filters.get("patient_id"):
                    where_filter = {"patient_id": filters["patient_id"]}
                    
                results = self.collection.query(
                    query_embeddings=[query_embedding],
                    n_results=semantic_k + len(final_ids),
                    where=where_filter,
                    include=["documents", "metadatas", "distances"]
                )
                
                if results and results.get("ids") and results["ids"][0]:
                    for i in range(len(results["ids"][0])):
                        doc_id = results["ids"][0][i]
                        if doc_id not in final_ids:
                            final_ids.append(doc_id)
                            final_docs.append(results["documents"][0][i])
                            final_metas.append(results["metadatas"][0][i])
                            final_dists.append(results["distances"][0][i])
                            if len(final_ids) >= k:
                                break
            except Exception as e:
                logger.error(f"Error in semantic search step: {e}")
                if not final_ids:
                    raise
                    
        # Apply role-based redactor for Insurer
        if role == "insurer":
            final_docs = [self._redact_document_text(d) for d in final_docs]
            
        # Format back to expected ChromaDB structure with double list nesting
        return {
            "ids": [final_ids[:k]],
            "documents": [final_docs[:k]],
            "metadatas": [final_metas[:k]],
            "distances": [final_dists[:k]]
        }

    def _patient_matches_filters(self, p: Dict[str, Any], filters: Dict[str, Any]) -> bool:
        """Helper to check if a patient record satisfies exact filter conditions."""
        # Patient ID check
        if filters.get("patient_id") and p["patient"]["patient_id"]["value"] != filters["patient_id"]:
            return False
            
        # Conditions check (any matching conditions)
        if filters.get("conditions"):
            p_conds = [c["value"].lower() for c in p.get("conditions", [])]
            for cond in filters["conditions"]:
                if not any(cond.lower() in pc for pc in p_conds):
                    return False
                    
        # Medications check
        if filters.get("medications"):
            p_meds = [m["name"]["value"].lower() for m in p.get("medications", [])]
            for med in filters["medications"]:
                if not any(med.lower() in pm for pm in p_meds):
                    return False
                    
        # Labs check
        if filters.get("labs"):
            for lf in filters["labs"]:
                field = lf["field"]
                op = lf["op"]
                target_val = lf["value"]
                
                lab_matched = False
                for lr in p.get("lab_results", []):
                    tname = lr["test_name"]["value"].lower()
                    
                    if field == "hba1c" and "hba1c" in tname:
                        try:
                            # Extract number
                            num_str = "".join(c for c in lr["value"]["value"] if c.isdigit() or c in ".-")
                            if num_str:
                                val = float(num_str)
                                if op == ">" and val > target_val:
                                    lab_matched = True
                                elif op == "<" and val < target_val:
                                    lab_matched = True
                        except Exception:
                            pass
                    elif field == "blood pressure" and ("pressure" in tname or "bp" in tname):
                        try:
                            # Parse "140/90" -> systolic is 140
                            parts = lr["value"]["value"].split("/")
                            if parts:
                                val_str = "".join(c for c in parts[0] if c.isdigit())
                                if val_str:
                                    systolic = float(val_str)
                                    if op == ">" and systolic > target_val:
                                        lab_matched = True
                                    elif op == "<" and systolic < target_val:
                                        lab_matched = True
                        except Exception:
                            pass
                if not lab_matched:
                    return False
        return True

    def _redact_document_text(self, text: str) -> str:
        """Censors contact fields and address lines in documents before processing."""
        import re
        text = re.sub(r'Phone:\s*[^\n]+', 'Phone: [REDACTED FOR INSURER]', text)
        text = re.sub(r'Email:\s*[^\n]+', 'Email: [REDACTED FOR INSURER]', text)
        text = re.sub(r'Address:\s*[^\n]+', 'Address: [REDACTED FOR INSURER]', text)
        return text

def get_retriever(top_k: int = TOP_K_RETRIEVAL) -> PatientRetriever:
    """
    Reusable function to get a configured retriever instance.
    """
    return PatientRetriever(top_k=top_k)


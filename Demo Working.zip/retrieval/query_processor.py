import re
import logging
from typing import Dict, Any, List

logger = logging.getLogger(__name__)

def process_query(query: str) -> str:
    """
    Clean and normalize the user query for better retrieval.
    Removes unnecessary spaces and handles basic healthcare-specific query normalization.
    """
    if not query:
        return ""
    
    # Remove extra whitespace, newlines, and tabs
    query = " ".join(query.split())
    query = query.strip()
    
    logger.debug(f"Processed query: '{query}'")
    return query

def extract_filters(query: str) -> Dict[str, Any]:
    """
    Extract structured filter parameters from the user's natural language query.
    Used for constraint-based precise retrieval.
    """
    query_lower = query.lower()
    
    # 1. Patient ID extraction (e.g. P009, Patient 5)
    patient_id = None
    pid_match = re.search(r'\b[pP](\d+)\b', query)
    name_match = re.search(r'\b[pP]atient\s*(\d+)\b', query, re.IGNORECASE)
    if pid_match:
        patient_id = f"P{int(pid_match.group(1)):03d}"
    elif name_match:
        patient_id = f"P{int(name_match.group(1)):03d}"
        
    # 2. Condition detection
    conditions = []
    condition_keywords = {
        "Diabetes": ["diabetes", "diabetic"],
        "Hypertension": ["hypertension", "high blood pressure", "bp"],
        "Cardiac": ["cardiac", "heart", "coronary", "cardiovascular", "myocardial"]
    }
    for cond_key, synonyms in condition_keywords.items():
        if any(syn in query_lower for syn in synonyms):
            conditions.append(cond_key)
            
    # 3. Medication detection
    medications = []
    medication_keywords = {
        "Metformin": ["metformin"],
        "Glimepiride": ["glimepiride"],
        "Losartan": ["losartan"],
        "Amlodipine": ["amlodipine"]
    }
    for med_key, synonyms in medication_keywords.items():
        if any(syn in query_lower for syn in synonyms):
            medications.append(med_key)
            
    # 4. Lab report filters (numerical operator extractions)
    labs = []
    # Check HbA1c
    hba1c_matches = re.findall(r'hba1c\s*(?:above|greater than|>|over|higher than)?\s*(\d+(?:\.\d+)?)\s*%', query_lower)
    if not hba1c_matches:
        hba1c_matches = re.findall(r'hba1c\s*(?:above|greater than|>|over|higher than)?\s*(\d+(?:\.\d+)?)\b', query_lower)
        
    if hba1c_matches:
        val = float(hba1c_matches[0])
        op = ">"  # default
        if "below" in query_lower or "less" in query_lower or "<" in query_lower:
            op = "<"
        labs.append({"field": "hba1c", "op": op, "value": val})
        
    # Check BP
    bp_matches = re.findall(r'(?:blood pressure|bp)\s*(?:above|greater than|>|over)?\s*(\d+)\b', query_lower)
    if bp_matches:
        val = float(bp_matches[0])
        op = ">"
        if "below" in query_lower or "less" in query_lower or "<" in query_lower:
            op = "<"
        labs.append({"field": "blood pressure", "op": op, "value": val})
        
    return {
        "patient_id": patient_id,
        "conditions": conditions,
        "medications": medications,
        "labs": labs
    }


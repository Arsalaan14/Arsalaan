import json
import logging
from pathlib import Path
from typing import Any, Dict, List
import ijson

logger = logging.getLogger(__name__)

# Key normalization map
KEY_MAP = {
    "patient_id": ["pat_id", "pid", "id", "patientId", "patient_id"],
    "name": ["patient_name", "full_name", "nm", "name"],
    "age": ["patient_age", "years", "ag", "age"],
    "gender": ["sex", "patient_gender", "gen", "gender"],
    "blood_group": ["blood_type", "bg", "b_group", "blood_group"],
    "address": ["addr", "location", "residence", "address"],
    "phone": ["ph", "tel", "telephone", "phone"],
    "email": ["mail", "email_address", "email"],
    
    "allergies": ["allergy", "allergies_list", "alrg", "all", "allergies"],
    "careplans": ["care_plan", "cplan", "plans", "cp", "careplans"],
    "claims": ["claim_info", "clms", "insurance_claims", "claims"],
    "claims_transactions": ["transactions", "claim_tx", "ctx", "claims_transactions"],
    "conditions": ["condition", "cond", "con", "dx", "conditions"],
    "devices": ["device", "dev", "equipment", "devices"],
    "encounters": ["encounter", "visits", "visit_history", "enc", "encounters"],
    "imaging_studies": ["imaging", "scans", "img_std", "radiology", "imaging_studies"],
    "immunizations": ["immunization", "vaccines", "imm", "vax", "immunizations"],
    "medications": ["medication", "meds", "rx", "drugs", "medications"],
    "observations": ["observation", "obs", "vitals", "measurements", "observations"],
    "organizations": ["org", "hospital_org", "facility", "organizations"],
    "payer_transitions": ["insurance_transitions", "pyr_tx", "payer_transitions"],
    "payers": ["insurance", "payer_info", "health_plan", "payers"],
    "procedures": ["procedure", "surgery", "proc", "surg", "procedures"],
    "providers": ["provider", "doctors", "prov", "clinician", "providers"],
    "supplies": ["supply", "medical_supplies", "spl", "supplies"],
    "lab_reports": ["lab_reports", "labs", "lab_results", "test_results"]
}

# Invert for O(1) lookup
REVERSE_KEY_MAP = {}
for std_key, variations in KEY_MAP.items():
    for var in variations:
        REVERSE_KEY_MAP[var.lower()] = std_key

import decimal

def standardize_key(key: str) -> str:
    """Standardize a messy key using the mapping."""
    return REVERSE_KEY_MAP.get(str(key).lower(), str(key))

def make_field(value: Any, path: str) -> Dict[str, Any]:
    """Helper to structure normalized fields with value and source path provenance."""
    if isinstance(value, decimal.Decimal):
        value = int(value) if value % 1 == 0 else float(value)
        
    return {
        "value": value if value is not None else "Not Available",
        "source_path": path
    }

def normalize_single_patient(p: Dict[str, Any], p_idx: int) -> Dict[str, Any]:
    """Normalize a single patient dict into structured sub-entities dynamically."""
    
    # Initialize groups
    normalized = {
        "patient": {},
        "medications": [],
        "encounters": [],
        "lab_results": [],
        "allergies": [],
        "notes": [],
        "conditions": [],
        "observations": [],
        "procedures": [],
        "immunizations": [],
        "claims": [],
        "careplans": [],
        "imaging_studies": [],
        "devices": [],
        "supplies": [],
        "organizations": [],
        "providers": [],
        "payers": []
    }
    
    def add_to_group(group_name: str, item: Any, path: str):
        """Intelligently adds an item to a specific group, parsing it if it's a dict."""
        if isinstance(item, dict):
            entity = {}
            for k, v in item.items():
                std_k = standardize_key(k)
                if std_k in normalized and std_k != "patient":
                    # Nested group inside this entity! (e.g. condition inside medication)
                    process_value(v, f"{path}.{k}", std_k)
                elif std_k in ["name", "age", "gender", "blood_group", "address", "phone", "email", "patient_id"] and group_name == "patient":
                     normalized["patient"][std_k] = make_field(v, f"{path}.{k}")
                else:
                    if not isinstance(v, (dict, list)):
                        entity[std_k] = make_field(v, f"{path}.{k}")
                    else:
                        # Deep traversal for unknown structures
                        process_value(v, f"{path}.{k}")
            if entity and group_name != "patient":
                normalized[group_name].append(entity)
        elif isinstance(item, list):
            for i, v in enumerate(item):
                add_to_group(group_name, v, f"{path}[{i}]")
        else:
            # Scalar value
            if group_name == "conditions":
                normalized["conditions"].append(make_field(item, path))
            elif group_name == "allergies":
                normalized["allergies"].append({"allergen": make_field(item, path)})
            elif group_name == "devices":
                normalized["devices"].append({"device": make_field(item, path)})
            elif group_name == "supplies":
                normalized["supplies"].append({"supply": make_field(item, path)})
            elif group_name == "immunizations":
                normalized["immunizations"].append({"vaccine": make_field(item, path)})
            elif group_name != "patient":
                # generic fallback for other lists
                normalized[group_name].append({"value": make_field(item, path)})

    def process_value(obj: Any, path: str, target_group: str = None):
        if isinstance(obj, dict):
            for k, v in obj.items():
                std_key = standardize_key(k)
                new_path = f"{path}.{k}"
                
                if std_key in normalized:
                    # Found a known group! Parse its contents into that group.
                    add_to_group(std_key, v, new_path)
                elif std_key in ["name", "age", "gender", "blood_group", "address", "phone", "email", "patient_id"] and (target_group is None or target_group == "patient"):
                    normalized["patient"][std_key] = make_field(v, new_path)
                else:
                    # Unknown key, keep traversing
                    process_value(v, new_path, target_group)
        elif isinstance(obj, list):
            for i, item in enumerate(obj):
                process_value(item, f"{path}[{i}]", target_group)

    # Start processing the entire patient object
    process_value(p, f"patients[{p_idx}]")
    
    # Post-process specific fields to ensure embedding_utils gets what it expects
    pid = normalized["patient"].get("patient_id", make_field("UNKNOWN", f"patients[{p_idx}]"))
    normalized["patient"]["patient_id"] = pid
    
    return normalized

def normalize_dataset(json_path: str, output_path: str) -> List[Dict[str, Any]]:
    """Load, normalize and save the patient database using streaming (ijson) for multi-GB support."""
    json_path_obj = Path(json_path).resolve()
    output_path_obj = Path(output_path).resolve()

    logger.info(f"Normalizing dataset from {json_path_obj}")
    
    # Instead of json.load() which loads everything into memory, we use ijson to stream patients.
    normalized_list = []
    
    with open(json_path_obj, "rb") as f_in, open(output_path_obj, "w", encoding="utf-8") as f_out:
        f_out.write('{\n  "patients": [\n')
        
        parser = ijson.items(f_in, 'patients.item')
        first = True
        p_idx = 0
        
        for p in parser:
            normalized_p = normalize_single_patient(p, p_idx)
            
            # We keep the in-memory return for backward compatibility if it's small, 
            # but ideally in a real GB setup we would yield it. 
            # Since the function signature expects List[Dict], we will append for now, 
            # but we are at least writing it incrementally.
            normalized_list.append(normalized_p)
            
            if not first:
                f_out.write(',\n')
            first = False
            
            json.dump(normalized_p, f_out, indent=4)
            p_idx += 1
            
        f_out.write('\n  ]\n}\n')

    return normalized_list

def stream_normalized_dataset(json_path: str):
    """Load and normalize the patient database using streaming (ijson). Yields one patient at a time."""
    json_path_obj = Path(json_path).resolve()
    logger.info(f"Streaming dataset from {json_path_obj}")
    
    with open(json_path_obj, "rb") as f_in:
        parser = ijson.items(f_in, 'patients.item')
        p_idx = 0
        for p in parser:
            yield normalize_single_patient(p, p_idx)
            p_idx += 1


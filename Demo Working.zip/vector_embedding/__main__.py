"""Allow running ``python -m vector_embedding`` to invoke the embedding pipeline."""

from .embed_patients import main

if __name__ == "__main__":
    main()

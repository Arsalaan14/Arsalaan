"""
Patient Embedding Pipeline — Main Entry Point.

Reads patient records from a JSON file, converts each record into a
structured medical document, generates vector embeddings using
SentenceTransformers (all-MiniLM-L6-v2), and persists them in a
ChromaDB collection for downstream RAG retrieval.

Usage:
    python -m vector_embedding.embed_patients          # uses default path
    python -m vector_embedding.embed_patients --json path/to/data.json
"""

import argparse
import logging
import os
import sys
import time
from pathlib import Path

from .embedding_utils import (
    CHROMA_DB_PATH,
    COLLECTION_NAME,
    _get_chroma_client,
    get_embedding_model,
    load_patient_data,
    patient_to_document,
    normalized_patient_to_document,
)
from .normalization import normalize_dataset

# ---------------------------------------------------------------------------
# Logging Configuration
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Core Pipeline
# ---------------------------------------------------------------------------
def build_embeddings(
    json_path: str,
    db_path: str | None = None,
    collection_name: str = COLLECTION_NAME,
    batch_size: int = 32,
) -> None:
    """Run the full embedding pipeline using memory-efficient streaming.

    1. Stream raw patient records JSON.
    2. Normalize records on the fly.
    3. Generate documents with citation tags.
    4. Generate embeddings and upsert into ChromaDB in batches.
    """
    start = time.perf_counter()
    db_path = db_path or CHROMA_DB_PATH

    from .normalization import stream_normalized_dataset

    client = _get_chroma_client(db_path)
    try:
        client.delete_collection(name=collection_name)
        logger.info("Deleted old ChromaDB collection to prevent ghost records.")
    except Exception:
        pass
    collection = client.create_collection(name=collection_name)
    model = get_embedding_model()

    logger.info("Starting streaming pipeline from %s", json_path)

    batch_docs = []
    batch_ids = []
    batch_metadatas = []
    patients_processed = 0

    for patient in stream_normalized_dataset(json_path):
        pat_details = patient.get("patient", {})
        pid = pat_details.get("patient_id", {}).get("value", "UNKNOWN")
        doc = normalized_patient_to_document(patient)
        
        batch_docs.append(doc)
        batch_ids.append(f"doc_{pid}")
        
        cond_list = [c.get("value", "") for c in patient.get("conditions", [])]
        med_list = [m.get("name", {}).get("value", "") for m in patient.get("medications", [])]
        lab_list = [l.get("test_name", {}).get("value", "") for l in patient.get("lab_results", [])]
        
        batch_metadatas.append(
            {
                "patient_id": pid,
                "patient_name": pat_details.get("name", {}).get("value", "N/A"),
                "age": int(pat_details.get("age", {}).get("value", 0)),
                "gender": pat_details.get("gender", {}).get("value", "N/A"),
                "conditions": ", ".join(filter(None, cond_list)),
                "medications": ", ".join(filter(None, med_list)),
                "lab_tests": ", ".join(filter(None, lab_list)),
            },
        )

        if len(batch_docs) >= batch_size:
            embeddings = model.encode(
                batch_docs,
                batch_size=batch_size,
                show_progress_bar=False,
                normalize_embeddings=True,
            )
            embeddings_list = [emb.tolist() for emb in embeddings]
            
            collection.upsert(
                ids=batch_ids,
                documents=batch_docs,
                metadatas=batch_metadatas,
                embeddings=embeddings_list,
            )
            patients_processed += len(batch_docs)
            logger.info("Upserted batch, total patients processed: %d", patients_processed)
            
            batch_docs.clear()
            batch_ids.clear()
            batch_metadatas.clear()

    # Process remaining records in the final batch
    if batch_docs:
        embeddings = model.encode(
            batch_docs,
            batch_size=len(batch_docs),
            show_progress_bar=False,
            normalize_embeddings=True,
        )
        embeddings_list = [emb.tolist() for emb in embeddings]
        collection.upsert(
            ids=batch_ids,
            documents=batch_docs,
            metadatas=batch_metadatas,
            embeddings=embeddings_list,
        )
        patients_processed += len(batch_docs)
        logger.info("Upserted final batch, total patients processed: %d", patients_processed)

    elapsed = time.perf_counter() - start

    # --- Summary ------------------------------------------------------
    print("\n" + "=" * 60)
    print("  PATIENT EMBEDDING PIPELINE — SUMMARY")
    print("=" * 60)
    print(f"  Patients processed  : {patients_processed}")
    print(f"  Vectors stored      : {collection.count()}")
    print(f"  ChromaDB location   : {os.path.abspath(db_path)}")
    print(f"  Collection name     : {collection_name}")
    print(f"  Embedding model     : all-MiniLM-L6-v2")
    if patients_processed > 0:
        print(f"  Embedding dimension : {len(embeddings_list[0])}")
    print(f"  Time elapsed        : {elapsed:.2f}s")
    print("=" * 60 + "\n")

    logger.info("Pipeline completed successfully in %.2fs", elapsed)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main() -> None:
    """Parse CLI arguments and run the embedding pipeline."""
    parser = argparse.ArgumentParser(
        description="Generate patient record embeddings and store in ChromaDB.",
    )
    import sys
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from config import JSON_DATA_PATH

    parser.add_argument(
        "--json",
        type=str,
        default=JSON_DATA_PATH,
        help=f"Path to the patient JSON file (default: {JSON_DATA_PATH}).",
    )
    parser.add_argument(
        "--db-path",
        type=str,
        default=None,
        help=f"ChromaDB storage directory (default: {CHROMA_DB_PATH}).",
    )
    parser.add_argument(
        "--collection",
        type=str,
        default=COLLECTION_NAME,
        help=f"ChromaDB collection name (default: {COLLECTION_NAME}).",
    )
    parser.add_argument(
        "--batch-size",
        type=int,
        default=32,
        help="Embedding / upsert batch size (default: 32).",
    )
    args = parser.parse_args()

    build_embeddings(
        json_path=args.json,
        db_path=args.db_path,
        collection_name=args.collection,
        batch_size=args.batch_size,
    )


if __name__ == "__main__":
    main()

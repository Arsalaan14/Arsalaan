"""
Embedding Utilities for Patient Health Records.

Provides reusable functions for:
  - Loading patient data from JSON
  - Converting patient records to readable medical documents
  - Loading the SentenceTransformer embedding model
  - Loading/connecting to the persisted ChromaDB vector store
"""

import json
import logging
import os
from pathlib import Path
from typing import Any

import chromadb
from sentence_transformers import SentenceTransformer

# ---------------------------------------------------------------------------
# Logger
# ---------------------------------------------------------------------------
logger = logging.getLogger(__name__)

import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config import CHROMA_DB_DIR as CHROMA_DB_PATH, COLLECTION_NAME, EMBEDDING_MODEL

# Constants
MODEL_NAME: str = EMBEDDING_MODEL

# Module-level cache so the model is only loaded once per process
_model_cache: SentenceTransformer | None = None


# ---------------------------------------------------------------------------
# Data Loading
# ---------------------------------------------------------------------------
def load_patient_data(json_path: str) -> list[dict[str, Any]]:
    """Load patient records from a JSON file.

    Args:
        json_path: Absolute or relative path to the JSON file.

    Returns:
        A list of patient record dictionaries.

    Raises:
        FileNotFoundError: If the JSON file does not exist.
        json.JSONDecodeError: If the file contains invalid JSON.
    """
    path = Path(json_path).resolve()
    if not path.exists():
        raise FileNotFoundError(f"Patient data file not found: {path}")

    logger.info("Loading patient data from %s", path)
    with open(path, "r", encoding="utf-8") as fh:
        data = json.load(fh)

    # If the file contains a dict with "patients", return that list
    if isinstance(data, dict) and "patients" in data:
        patients = data["patients"]
    elif isinstance(data, list):
        patients = data
    else:
        patients = []

    logger.info("Loaded %d patient records", len(patients))
    return patients


# ---------------------------------------------------------------------------
# Document Conversion
# ---------------------------------------------------------------------------
def patient_to_document(patient: dict[str, Any]) -> str:
    """Convert a single patient JSON record into a human-readable medical document.

    The output is a structured text block suitable for embedding and
    semantic search.

    Args:
        patient: A dictionary representing one patient record.

    Returns:
        A multi-line string containing the formatted patient document.
    """
    lines: list[str] = []

    # --- Basic demographics ---
    lines.append(f"Patient ID: {patient.get('patient_id', 'N/A')}")
    lines.append(f"Name: {patient.get('name', 'N/A')}")
    lines.append(f"Age: {patient.get('age', 'N/A')}")
    lines.append(f"Gender: {patient.get('gender', 'N/A')}")
    lines.append(f"Blood Group: {patient.get('blood_group', 'N/A')}")

    # --- Contact ---
    contact = patient.get("contact", {})
    if contact:
        lines.append(f"Phone: {contact.get('phone', 'N/A')}")
        lines.append(f"Email: {contact.get('email', 'N/A')}")

    # --- Address ---
    address = patient.get("address")
    if address:
        lines.append(f"Address: {address}")

    # --- Conditions ---
    conditions = patient.get("conditions", [])
    if conditions:
        lines.append(f"Conditions: {', '.join(conditions)}")

    # --- Allergies ---
    allergies = patient.get("allergies", [])
    if allergies:
        lines.append(f"Allergies: {', '.join(allergies)}")

    # --- Medications ---
    medications = patient.get("medications", [])
    if medications:
        lines.append("Medications:")
        for med in medications:
            name = med.get("name", "Unknown")
            dosage = med.get("dosage", "")
            freq = med.get("frequency", "")
            lines.append(f"  - {name} {dosage} {freq}".strip())

    # --- Lab Reports ---
    lab_reports = patient.get("lab_reports", [])
    if lab_reports:
        lines.append("Lab Reports:")
        for report in lab_reports:
            test = report.get("test_name", "Unknown")
            value = report.get("value", "N/A")
            date = report.get("date", "N/A")
            lines.append(f"  - {test}: {value} (Date: {date})")

    # --- Doctor Visits ---
    visits = patient.get("visits", [])
    if visits:
        lines.append("Doctor Visits:")
        for visit in visits:
            reason = visit.get("reason", "General")
            date = visit.get("date", "N/A")
            doctor = visit.get("doctor", "N/A")
            lines.append(f"  - {reason} on {date} with {doctor}")

    return "\n".join(lines)


def normalized_patient_to_document(p: dict[str, Any]) -> str:
    """Convert a normalized patient record into a document string with provenance tags."""
    lines: list[str] = []
    pat = p.get("patient", {})
    
    # helper for field printing
    def fmt(fld):
        val = fld.get("value", "N/A")
        src = fld.get("source_path", "")
        return fld.get("value", "N/A") if not src else f"{val} [{src}]"

    lines.append(f"Patient ID: {fmt(pat.get('patient_id', {}))}")
    lines.append(f"Name: {fmt(pat.get('name', {}))}")
    lines.append(f"Age: {fmt(pat.get('age', {}))}")
    lines.append(f"Gender: {fmt(pat.get('gender', {}))}")
    lines.append(f"Blood Group: {fmt(pat.get('blood_group', {}))}")
    lines.append(f"Phone: {fmt(pat.get('phone', {}))}")
    lines.append(f"Email: {fmt(pat.get('email', {}))}")
    lines.append(f"Address: {fmt(pat.get('address', {}))}")
    
    conds = p.get("conditions", [])
    if conds:
        lines.append(f"Conditions: {', '.join(fmt(c) for c in conds)}")
        
    meds = p.get("medications", [])
    if meds:
        lines.append("Medications:")
        for m in meds:
            n = fmt(m.get("name", {}))
            d = fmt(m.get("dosage", {}))
            f = fmt(m.get("frequency", {}))
            lines.append(f"  - {n}: {d}, {f}")
            
    labs = p.get("lab_results", [])
    if labs:
        lines.append("Lab Reports:")
        for l in labs:
            t = fmt(l.get("test_name", {}))
            v = fmt(l.get("value", {}))
            dt = fmt(l.get("date", {}))
            lines.append(f"  - {t}: {v} (Date: {dt})")

    encounters = p.get("encounters", [])
    if encounters:
        lines.append("Doctor Visits:")
        for e in encounters:
            dt = fmt(e.get("date", {}))
            doc = fmt(e.get("doctor", {}))
            reas = fmt(e.get("reason", {}))
            lines.append(f"  - {reas} on {dt} with {doc}")

    return "\n".join(lines)



# ---------------------------------------------------------------------------
# Embedding Model
# ---------------------------------------------------------------------------
def get_embedding_model() -> SentenceTransformer:
    """Return (and cache) the SentenceTransformer model.

    The model is loaded once and reused for subsequent calls within the
    same process.

    Returns:
        A SentenceTransformer model instance.
    """
    global _model_cache  # noqa: PLW0603
    if _model_cache is None:
        logger.info("Loading SentenceTransformer model: %s", MODEL_NAME)
        _model_cache = SentenceTransformer(MODEL_NAME)
        logger.info("Model loaded successfully")
    return _model_cache


# ---------------------------------------------------------------------------
# ChromaDB Helpers
# ---------------------------------------------------------------------------
def _get_chroma_client(db_path: str | None = None) -> chromadb.PersistentClient:
    """Create a ChromaDB PersistentClient.

    Args:
        db_path: Optional override for the database directory.

    Returns:
        A chromadb.PersistentClient instance.
    """
    path = db_path or CHROMA_DB_PATH
    os.makedirs(path, exist_ok=True)
    logger.info("Connecting to ChromaDB at %s", path)
    return chromadb.PersistentClient(path=path)


def load_vector_db(
    db_path: str | None = None,
    collection_name: str = COLLECTION_NAME,
) -> chromadb.Collection:
    """Load and return the persisted ChromaDB collection.

    This is the **reusable entry-point** that downstream RAG retrieval
    pipelines should call to get a ready-to-query collection.

    Args:
        db_path: Optional override for the database directory.
                 Defaults to ``vector_embedding/chroma_db``.
        collection_name: Name of the collection to retrieve.

    Returns:
        A chromadb.Collection object backed by persistent storage.
    """
    client = _get_chroma_client(db_path)
    collection = client.get_or_create_collection(name=collection_name)
    logger.info(
        "Collection '%s' loaded — %d vectors stored",
        collection_name,
        collection.count(),
    )
    return collection

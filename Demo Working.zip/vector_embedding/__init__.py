"""
Vector Embedding Module for Patient Health Record Assistant.

This module provides utilities for converting patient JSON records into
vector embeddings and storing them in ChromaDB for RAG-based retrieval.
"""

from .embedding_utils import (
    load_patient_data,
    patient_to_document,
    get_embedding_model,
    load_vector_db,
)

__all__ = [
    "load_patient_data",
    "patient_to_document",
    "get_embedding_model",
    "load_vector_db",
]

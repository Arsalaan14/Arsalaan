# MediQueryNow API Reference

Base URL: `/api`

## Authentication

### POST `/auth/login`

Request:
```json
{"username":"provider","password":"Provider@123"}
```

Response:
```json
{
  "access_token":"...",
  "token_type":"Bearer",
  "user":{"username":"provider","name":"Dr. Olivia","role":"provider","patient_id":null}
}
```

### GET `/auth/me`

Requires Bearer JWT.

## Patients

### GET `/patients`

Query parameters: `search`, `condition`.

### GET `/patients/{patient_id}`

Returns the authorized clinical record.

## RAG

### POST `/query`

Request:
```json
{"query":"Summarize Patient P009"}
```

Response includes:
- `answer`
- `retrieved_docs`
- `doc_ids`
- `retrieval_time`
- `generation_time`

## Administration

### POST `/rebuild-embeddings`

Provider/Admin only.

### GET `/audit-logs`

Admin only.

## Health

### GET `/health`

Returns database, dataset and LLM-provider readiness.

# MediQueryNow — Final Year Project Report

## Abstract

MediQueryNow is a web-based clinical information retrieval platform designed to help authorized users locate and summarize information contained in patient health records. The system combines structured filtering with semantic vector retrieval and a Retrieval-Augmented Generation (RAG) pipeline. Role-based authorization limits access to patient records, insurer views redact personally identifying contact information, and an audit trail records sensitive operations.

## Problem Statement

Clinical records contain heterogeneous information such as demographics, diagnoses, medications, allergies, laboratory observations and encounters. Conventional keyword search can require users to know the exact terminology and structure of the source data. MediQueryNow provides a natural-language retrieval interface that maps user questions to structured filters and semantic retrieval while preserving record provenance.

## Objectives

- Build a usable clinical information retrieval interface.
- Normalize heterogeneous patient records.
- Generate semantic embeddings for retrieval.
- Store vectors in a persistent vector database.
- Implement natural-language query processing.
- Ground generated answers in retrieved records.
- Enforce role-based access boundaries.
- Mask sensitive fields for insurer users.
- Maintain an auditable activity trail.
- Package the application for reproducible deployment.

## Methodology

The application follows a Retrieval-Augmented Generation architecture:

1. Patient JSON records are normalized into a canonical structure.
2. Records are converted into provenance-aware clinical text.
3. SentenceTransformers generates embeddings.
4. ChromaDB stores the vectors and metadata.
5. User queries are normalized and parsed for structured filters.
6. Exact constraints are applied where possible.
7. Semantic search fills remaining retrieval slots.
8. Retrieved records become the grounded context.
9. The configured LLM generates a response, or the offline fallback produces a deterministic summary.
10. API responses are returned with retrieval diagnostics and source identifiers.
11. Sensitive operations are written to the audit trail.

## Security Design

The application uses signed JWT access tokens. Patient accounts carry a fixed patient identifier in the token, preventing a browser user from changing a patient ID through client-side state. Authorization checks are repeated at the backend API boundary. Administrative audit logs and index rebuilding are restricted to appropriate roles.

## Privacy Design

The demonstration dataset is synthetic. Insurer responses mask patient names, phone numbers, email addresses and addresses. The system is intentionally documented as an academic information-retrieval application rather than a clinical decision-making system.

## Functional Requirements

| ID | Requirement |
|---|---|
| FR1 | Authenticate users |
| FR2 | Support multiple user roles |
| FR3 | Browse patient records |
| FR4 | Search records using natural language |
| FR5 | Retrieve semantically relevant records |
| FR6 | Display structured clinical summaries |
| FR7 | Restrict patient accounts to their own record |
| FR8 | Redact sensitive fields for insurer role |
| FR9 | Record audit events |
| FR10 | Monitor application/index/LLM health |
| FR11 | Rebuild the vector index |
| FR12 | Run through Docker |

## Non-Functional Requirements

- Maintainable modular architecture
- Responsive web interface
- Clear API boundaries
- Graceful LLM failure handling
- Reproducible deployment
- Testable authorization logic
- Persistent vector index
- Human-readable documentation

## Testing Strategy

Unit tests cover JWT creation/verification, patient identity binding, insurer redaction and query filter extraction. Full integration testing should additionally cover browser/API interaction, vector retrieval, index rebuild and configured external LLM providers.

## Future Enhancements

- PostgreSQL for transactional application data
- Redis for rate limiting and caching
- Managed vector database
- OpenID Connect / institutional SSO
- Fine-grained permissions and consent management
- FHIR resource ingestion
- Explainable retrieval scoring
- Evaluation dataset and retrieval precision/recall benchmarks
- Human review workflow
- Production-grade observability

## Conclusion

MediQueryNow demonstrates how modern retrieval, vector databases, natural-language interfaces, authorization and auditability can be combined into a deployable healthcare information-retrieval application. Its modular architecture allows the academic prototype to be extended toward more advanced retrieval evaluation, interoperability and security research.

# UML / Architecture Diagrams

## Use Case Diagram

```mermaid
flowchart LR
    Provider((Provider))
    Patient((Patient))
    Insurer((Insurer))
    Admin((Admin))
    System[MediQueryNow]

    Provider --> System
    Patient --> System
    Insurer --> System
    Admin --> System

    System --> A[Authenticate]
    System --> B[Search Patient Records]
    System --> C[View Patient Details]
    System --> D[Submit Natural Language Query]
    System --> E[View System Health]
    Admin --> F[View Audit Logs]
    Provider --> G[Rebuild Vector Index]
    Admin --> G
```

## Sequence — Clinical Query

```mermaid
sequenceDiagram
    actor User
    participant UI as React UI
    participant API as Flask API
    participant Auth as JWT/RBAC
    participant R as Retriever
    participant DB as ChromaDB
    participant LLM as LLM/Fallback

    User->>UI: Enter clinical query
    UI->>API: POST /api/query + JWT
    API->>Auth: Verify token and role
    Auth-->>API: Authorized identity
    API->>R: retrieve(query, role)
    R->>DB: semantic + structured retrieval
    DB-->>R: relevant records
    R-->>API: grounded context
    API->>LLM: generate grounded response
    LLM-->>API: answer
    API-->>UI: answer + sources + timings
    UI-->>User: Structured clinical result
```

## Component Diagram

```mermaid
flowchart TB
    FE[React Frontend]
    BE[Flask API]
    AUTH[JWT Auth]
    RET[Retrieval Layer]
    EMB[Embedding Layer]
    CHROMA[(ChromaDB)]
    LLM[LLM Adapter]
    AUDIT[(Audit JSON)]

    FE --> BE
    BE --> AUTH
    BE --> RET
    RET --> CHROMA
    RET --> EMB
    BE --> LLM
    BE --> AUDIT
```
